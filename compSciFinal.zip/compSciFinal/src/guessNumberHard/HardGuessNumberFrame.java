package guessNumberHard;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import guessNumber.GuessNumberFrame;

/** Handles the actual features of the game including adding the entire game toi a frame so it 
 * can be seen, guessing the number, and declaring hen the game is eithr won or lost * 
 * 
 * @author Shivika Varshney
 * @author Britney Yang ( comments )
 * 
 */
public class HardGuessNumberFrame extends JFrame implements ActionListener {
	/** the solid color background*/
	private Color background = new Color(70, 140, 185);
	/** number the player has to guess */
	private int number;
	/** correct label that pops up when the player guesses right */
	private JLabel correct;
	/** number of guesse sthe player has left */
	private int numGuesses;
	/** label for when the player beats the game*/
	private JLabel gameFinished = new JLabel("You ");
	/** label for hen the player beats the game form the person*/
	private JButton choice = new JButton("Yay!");
	/** button to play the game again*/
	private JButton playAgain = new JButton("I'll play again.");
	
	/** if the game is won, will be set to true*/
	private boolean gameWon = false;
	
	/** Creates the JFrame in which the game will be played and sets up the 
	 * information needed like the range of numbers and whether or not the player 
	 * was close to guess. Whether or not the player has guessed right within 
	 * the given number of turns or guessed incorrectly is also determined and 
	 * illustrated onto the screen, prompting the player to exit the screen
	 * 
	 */
	public HardGuessNumberFrame() {
		this.setBounds(100, 100, 700, 200);
		this.setLayout(null);
		this.setLocationRelativeTo(null);
		this.setTitle("Guess the Number");
		
		this.getContentPane().setBackground(background);

		gameWon = false;

		JLabel label = new JLabel("I'm thinking of a number between 1-100. You have 5 guesses to guess what I'm thinking of!");
		label.setBounds(25,0,1000,100);
		label.setFont(new Font("Monospaced Plain", Font.PLAIN, 15));
		label.setForeground(Color.WHITE);
		this.add(label);
		
		numGuesses = 5;
		
//		person = new HardGuessNumberPerson(150,100);
//		person.generateNumber();
		number = (int)(Math.random()*100 +1);
//		this.add(person)
		
		JButton guess = new JButton("Guess"); //JButton class has lots of capabilities like changing color
		guess.setBounds(25,100,100,25);
		this.add(guess);
		
//		JLabel answer = new JLabel(number + "");
//		answer.setBounds(200,80,150,25);
//		this.add(answer);
		
		JTextField textField = new JTextField();
		textField.setBounds(25,70,100,25); 
		textField.setEnabled(true);
		this.add(textField);
		
		correct = new JLabel(); 
		correct.setBounds(200,100,600,25);
		correct.setForeground(Color.WHITE);
		this.add(correct);
		
		
		guess.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) { 
				if(textField.getText().equals(number + "")) {
					gameWon = true;
					correct.setText("Correct! Please exit the game");
				} else if(Integer.parseInt(textField.getText()) > number) {
					gameWon = false;
					numGuesses--;
					correct.setText("Incorrect, the number is smaller. You have " + numGuesses + " guesses left");
				} else {
					gameWon = false;
					numGuesses--;
					correct.setText("Incorrect, the number is greater. You have " + numGuesses + " guesses left");
				} 
				
				if(numGuesses == 0) {
					gameWon = false;
					correct.setText("You ran out of guesses! The correct number was " + number + ". Please exit the game.");
//					try
//				      {
//						correct.setText("You ran out of guesses! The correct number was " + number);
//						//delays the timer for 10 seconds so that the player can see what the correct number was, and then the frame will dispose on its own
//				        Thread.sleep(1000);   
//				        dispose();
//				      }
//				      catch(InterruptedException ex)
//				      {
//				          ex.printStackTrace();
//				      }
				}
				
			}
		});
		
		
		
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setVisible(true);
		
		/** Adds the resulting game into the main system, triggering the minigame to pop up
		 * 
		 */	
	}
	public static void main(String[] args) {
		new HardGuessNumberFrame();
	}
	/** generates an entirely new game that is reset for the player to play in
	 * 
	 */
	public void reset()
	{
		new HardGuessNumberFrame();
	
	}
	
	public boolean isGameWon() {
		return gameWon;
	}
	
	public void setGameWon(boolean won) {
		gameWon = won;
	}
	
	/** ensures that once the player runs out of turns, the number of guesses is at 0
	 * 
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if(numGuesses < 0)
		{
			numGuesses = 0;
		}
		
	
	}
}
