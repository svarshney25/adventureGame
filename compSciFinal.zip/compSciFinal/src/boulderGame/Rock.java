package boulderGame;

import java.awt.Image;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/** Sets up the rock game assets to be used and methods to trigger 
 * certain events such as ending the minigame
 * 
 * @author Britney Yang
 *
 */
public class Rock extends JPanel
{
	
	/** number of times the spacebar has been pressed by the player */
	private int spaceCount;
	
	/**	Label for the rock to be added into the game's frame */
	private JLabel rock;
	/* Image to be assigned to the rock label */
	private Image rockimg;
	/**	Label for the background of the minigame to be added into the game's frame */
	private JLabel rockBG;
	/** Image to be assigned to the background label */
	private Image rockBGimg;
	 
	/**		Instantiate the fields used within this class to store information
	 * 
	 */
	public Rock()
	{
		spaceCount = 0;
		
		try
		{
			
			rockimg = ImageIO.read((getClass().getResourceAsStream("/pngs/rock.png")));
			rockBGimg = ImageIO.read((getClass().getResourceAsStream("/pngs/boulderBackground.png")));
			
		} 
		catch (IOException e) 
		{
			
			e.printStackTrace();
			
		}
		
		//assigning labels
		
		rock = new JLabel();
		rock.setBounds(0,-100,1000,1000);
		rock.setIcon(new ImageIcon(rockimg));
		
		rockBG = new JLabel();
		rockBG.setBounds(0,0,1000,1000);
		rockBG.setIcon(new ImageIcon(rockBGimg));
		
	}
	
	//getters
	
	public int getSpaceCount()
	{
		return spaceCount;
	}
	
	public JLabel getRock()
	{
		return rock;
	}
	
	public JLabel getRockBG()
	{
		return rockBG;
	}
	
	//setters
	
	public void addSpaceCount()
	{
		spaceCount++;
	}
	
	public void moveRock()
	{
		rock.setBounds(-(spaceCount*10), -100, 1000, 1000);
	}
	
	//other
	/** Returns the boolean representation of whether or not the player has moved the rock out of the way enough
	 * 
	 * @return	true if the player has reached the target number of spaces and false to continue the game
	 */
	public boolean ifWin()
	{
		if ( spaceCount == 50 )
		{
			return true;
		}
		else
			return false;
	}
	
}
