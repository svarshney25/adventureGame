package boulderGame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.Timer;

/** Class is meant to create the GUI on which the entire move rock minigame will appear
 * 
 * @author Britney Yang
 *
 */
public class RockFrame extends JFrame implements ActionListener
{
	/** Stores the game panel assets*/
	private Rock game;
	private Timer timer;
	private boolean gameWon;
	
	/** Constructor to add all the visuals of the game onto a gui frame 
	 * as well as the interactions with the keyboard to progress the minigame. 
	 * 
	 */
	public RockFrame()
	{
		game = new Rock();
		timer = new Timer(25, this);
				
		gameWon = false;
		
		this.getContentPane();
		this.setBounds(0,0,896,768);
		this.setTitle("Move The Rock!");
		this.setLocationRelativeTo(null);
		
		this.add(game);
		this.add(game.getRock());
		this.add(game.getRockBG());
		timer.start();
		
		this.addKeyListener(
				new KeyListener()
				{

					@Override
					public void keyTyped(KeyEvent e) {
						// TODO Auto-generated method stub
						
					}

					/** WHen the space bar is pressed, the number of spaces should 
					 * increase and the rock should slowly unblock the path
					 * 
					 */
					@Override
					public void keyPressed(KeyEvent e) 
					{
						if (e.getKeyCode() == KeyEvent.VK_SPACE)
						{
							gameWon = false;
							game.addSpaceCount();
							game.moveRock();
						}
						
					}

					@Override
					public void keyReleased(KeyEvent e) {
						// TODO Auto-generated method stub
						
					}
					
				});
		
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE );
	}
	
	/** adds the created frame to the game
	 * 
	 */
	public static void main(String[] args) 
	{
		new RockFrame();
	}

	/** After the spacebar is pressed, this method should check if the 
	 * number of spaces has been met to return the game back to the main frame
	 * 
	 */

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if (game.ifWin())
		{
			gameWon = true;
			timer.stop();
			dispose();
		}
		
	}

	public boolean isGameWon() {
		return gameWon;
	}
	public void setGameWon(boolean val) {
		gameWon = val;
	}
}
