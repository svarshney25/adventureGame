package platformerHard;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;

import javax.swing.JComponent;

/** Creates the coins that will appear
 * 
 * @author Shivika Varshney
 * @author Britney Yang ( comments )
 *
 */
public class CoinsHard extends JComponent {
	/** the shape for the coins*/
	private Ellipse2D.Double coin;
	/** color of the coin*/
	private Color background = new Color(74, 185, 70);
	
	/**Creates a coin on a certain location of the frame
	 * 
	 * @param x		The x locaiton where the coin will be located
	 * @param y		The y location where the coin will be located
	 */
	public CoinsHard(int x, int y) {
		coin = new Ellipse2D.Double(0,0,15,15);
		this.setBounds(x,y,16,16);
	}
	
	/** allows for the coin to be vsiisble on the JFrame*/
	@Override
	public void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.draw(coin);
		 
        g2.setColor(Color.YELLOW);
        g2.fill(coin);
       
	}
}