package platformerHard;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import javax.swing.JComponent;

/** Creates parts that the player has to try and avoid
 * 
 * @author Shivika Varshney
 * @author Britney Yang ( comments )
 */
public class Avoid extends JComponent {
	/** shaope of the area to avoid*/
	private Rectangle goal;
	/** color of the area*/
	private Color background = new Color(255, 0, 48);
	
	/** Creates the area to avoid on the JFRame with the given location and dimensions
	 * 
	 * @param x		x location of the avoid area
	 * @param y		y location of the avoid area
	 * @param width		width of the area
	 * @param height	height of the area
	 */
	public Avoid(int x, int y, int width, int height) {
		goal = new Rectangle(0,0,width,height);
		this.setBounds(x,y,width+1,height+1);
	}
	
	@Override
	/** allows for the area to be visisble on the JFrame
	 * 
	 */
	public void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;

        g2.setColor(background);
        g2.fill(goal);
        
	}
}