/** description of BeachBoss
 * 
 * creates the frame used for all beach boss functions
 * connects all JComponents, images, JLabels, and other important variables to be used across classes
 * adds everything to a JLayered Panel, allowing for overlay of pngs
 * adds a keylistener to check user input on the keys and update player location
 * keylistener also used for attacking (enter key) after checking if player is in specific region
 * 
 * @author Shivani Chhaya
 */


package BeachBoss;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.Timer;

import BeachBoss.Bullet;
//import BeachBoss.Bullet;

public class BeachBossFrame extends JFrame implements ActionListener, KeyListener
{
	/** fields
	 * default values that are used across classes
	 * 
	 * skyImage- image used for background 
	 * bullets- list of Bullet objects
	 * __pressed/___released- keyListener booleans for player movement
	 * 
	 * moveOnClicked- move on button clicked, player can advance
	 * 
	 */
	private BufferedImage skyImage = null;
	private ArrayList<Bullet> bullets;
	
	private boolean leftPressed;
	private boolean leftReleased;
	private boolean rightPressed;
	private boolean rightReleased;
	private boolean spacePressed;
	private boolean spaceReleased;
	
	private boolean gameDone = false;
	private boolean gameWon = false;
	private boolean moveOnClicked = false;
	
	private boolean gameActivated = false;
	
//	private JLabel ground = new JLabel();
	private JLabel sky = new JLabel();
	
	/** 
	 * objects added to the layered pane
	 * crab- boss
	 * ground- the ground the player walks on
	 * player- component moves by user
	 * pane- the content pane of the frame
	 */
	private BeachBossCrab crab;
	private BeachBossGround ground;
	private BeachBossPlayer player;
	private JLayeredPane pane;
	
	private Timer timer;
	
	private int playerHealth = 30;
	private int crabHealth = 50;
	
	private JLabel playerHealthLabel = new JLabel("PLAYER HEALTH: " + playerHealth);
	private JLabel crabHealthLabel = new JLabel("BOSS HEALTH: " + crabHealth);
	
	private JLabel finished = new JLabel("YOU WIN!");
	
//	private JLabel crab = new JLabel();
	
	/** description of BeachBossFrame()
	 *  creates a new frame for the beach boss to be fought on
	 *  adds a panel to the frame with multiple components
	 *  keylistener used to move player around with A and D
	 */
	public BeachBossFrame()
	{
		this.setBounds(400,400,896,768);
		this.setLocationRelativeTo(null);
		this.setTitle("Mini Boss");
		this.setResizable(false);
		
//		background = new BeachBossBackground(this);
		
		bullets = new ArrayList<Bullet>();
		
		pane = new JLayeredPane();
		
		crab = new BeachBossCrab(this);
		ground = new BeachBossGround();
		player = new BeachBossPlayer(448,700,this);
		
		timer = new Timer(20, this);
		timer.start();
		
		this.setContentPane(pane);
		
	
		pane.setLayout(new LayeredPaneLayout(pane));
		
		
		
		try
		{
//			crabImage = ImageIO.read(getClass().getResourceAsStream("/beachBossImages/crabboss_crab.png"));
			skyImage = ImageIO.read(getClass().getResourceAsStream("/beachBossImages/crabboss_bg.png"));

		}
		/** 
		 * @exception IOException
		 * catches error with Image reading
		 */
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		sky.setIcon(new ImageIcon(skyImage));
//		ground.setIcon(new ImageIcon(sandImage));

//		crab.setIcon(new ImageIcon(crabImage));
		
//		ground.setBounds(0,0,896,768);
//		sky.setBounds(0,0,0,0);
		
//		crab.setBounds(-500,-500,1000,1000);
//		
//		pane.setLayer(sky,0);
//		pane.setLayer(crab,1);
		
		crab.setOpaque(false);
		sky.setOpaque(false);
		pane.setOpaque(false);
		
		pane.add(sky,JLayeredPane.DEFAULT_LAYER,0);
		pane.add(crab, JLayeredPane.PALETTE_LAYER,1);
		pane.add(ground, JLayeredPane.MODAL_LAYER,2);
		pane.add(player, JLayeredPane.POPUP_LAYER, 3);
		
		
		
		this.addKeyListener(new KeyListener() 
		{

			@Override
			public void keyTyped(KeyEvent e) 
			{
				
			}

			@Override
			public void keyPressed(KeyEvent e) 
			{
				int code = e.getKeyCode();
				
					switch(code)
					{
					case KeyEvent.VK_A:
						gameActivated = true;
						leftPressed = true;
						leftReleased = false;
						player.setDirection("left");
						player.setDx(-7);
						break;
					case KeyEvent.VK_D:
						gameActivated = true;
						rightPressed = true;
						rightReleased = false;
						player.setDirection("right");
						player.setDx(+7);
						break;
					case KeyEvent.VK_SPACE:
						break;
					case KeyEvent.VK_ENTER:
						gameActivated = true;
						if(player.getPlayerX() > crab.getCrabLeftLeg() && player.getPlayerX() < crab.getCrabLeftLeg() + crab.getCrabLegWidth() )
						{
							if(crabHealth >= 2)
							{
								crabHealth-= 2;
								System.out.println("hit");
								crabHealthLabel.setForeground(Color.red);
							}
						}
						if(player.getPlayerX() > crab.getCrabRightLeg() && player.getPlayerX() < crab.getCrabRightLeg() + crab.getCrabLegWidth() )
						{
							if(crabHealth >= 2)
							{
								crabHealth-= 2;
								System.out.println("hit");
								crabHealthLabel.setForeground(Color.red);
							}
						}
						
//						
//						if(player.getPlayerX() > 200 && player.getPlayerX() < 400 )
//						{
//							crabHealth-= 3;
//							System.out.println("hit");
//						}

						break;
					}
				
				
					
			}

			@Override
			public void keyReleased(KeyEvent e) {
				
				int code = e.getKeyCode();
					switch(code)
					{
					case KeyEvent.VK_A:
						leftPressed = false;
						leftReleased = true;
						player.setDx(0);
						break;
					case KeyEvent.VK_D:
						rightPressed = false;
						rightReleased = true;
						player.setDx(0);
						break;
					case KeyEvent.VK_SPACE:
						break;
					case KeyEvent.VK_ENTER:
						crabHealthLabel.setForeground(Color.white);

					}
				}
			
		});

		playerHealthLabel.setForeground(Color.green);
		playerHealthLabel.setFont(new Font("Monospaced Plain", Font.PLAIN, 20));
		playerHealthLabel.setOpaque(false);
		playerHealthLabel.setBounds(0,693,200,50);
		
		
//		pane.add(playerHealthLabel);
		
		crabHealthLabel.setForeground(Color.white);
		crabHealthLabel.setFont(new Font("Monospaced Plain", Font.PLAIN, 20));
		crabHealthLabel.setOpaque(false);
		crabHealthLabel.setBounds(700, 693, 200, 50);
		

//		pane.add(crabHealthLabel);
		
//		pane.add(crabHealthLabel, JLayeredPane.TOP_ALIGNMENT);
//		pane.add(playerHealthLabel, JLayeredPane.BOTTOM_ALIGNMENT);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
	
	}
	
	/** description of actionPerformed(ActionEvent e)
	 * 
	 * updates the player and boss locations accordingly
	 * adds bullets to the frame and moves them accordingly
	 * keeps the character from exiting the frame bounds
	 * ends the game by checking if the player won or lost, then adds a button to either progress or move back
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(!gameDone)
		{
			if(gameActivated)
			{
				crab.update();
				crab.repaint();
				player.update();
				
				if(crab.isFire())
				{
					
						for(int i = 0; i < 1; i++)
						{
							Bullet temp1 = new Bullet(crab.getCrabMiddleX(),400, 7);
							add(temp1);
							bullets.add(temp1);
						}
				}
				
		//		crab.setCrabX(crab.getCrabX()+crab.getDx());
		//		crab.setLocation(crab.getCrabX(), crab.getY());
				
				
				if(crab.getCrabX() < -400)
				{
					crab.setDx(crab.getDx()*-1);
				}
				if(crab.getCrabX()+crab.getWidth() > 1296)
				{
					crab.setDx(crab.getDx()*-1);
				}
				
				if(player.getX() + player.getDx() < -100)
				{
					player.setLocation(-100,player.getY());
				}
				
				if(player.getPlayerX() + player.getDx() > 768)
				{
					player.setLocation(650, player.getY());
				}
			
		//		for(int i = 0; i < bullets.size(); i++)
		//		{
		//			
		//			Bullet b = bullets.get(i);
		//			pane.add(b, JLayeredPane.POPUP_LAYER, 3);
		//			b.update();
		//			
		//			
		//			if(b.getY() + b.getHeight() > 700)
		//			{
		//				this.remove(b);
		//				bullets.remove(i); 
		//				i--;
		//				crab.setAmmoCount(1);
		//			}
		//			
		//		}
				
				for(int i = 0; i < bullets.size(); i++)
				{
					
					Bullet b = bullets.get(i);
					pane.add(b, JLayeredPane.POPUP_LAYER, 0);
					b.update();
					b.repaint();
					
					if(b.getBounds().intersects(player.getPlayerX(), player.getPlayerY() + 150, 100,  100))
					{
		//				System.out.println("ouch!");
						this.remove(b);
						bullets.remove(i);
						i--;
						crab.setAmmoCount(1);
						playerHealth-=3;
					}
		
					else if(b.getY() + b.getHeight() + b.getHeight() > 770 )
					{
						this.remove(b);
						bullets.remove(i); 
						i--;
						crab.setAmmoCount(1);
					}
					
				}
				if(playerHealth == 0)
				{
					gameDone = true;
					
					finished.setForeground(Color.red);
					finished.setFont(new Font("Verdana", Font.PLAIN, 60));
					finished.setText("YOU DIED!");
					
					JButton playLater = new JButton("You died! Play later?");
					pane.setLayer(playLater, JLayeredPane.POPUP_LAYER, 0);
					playLater.setFont(new Font("Verdana", Font.PLAIN, 30));
					playLater.setBackground(Color.white);
					playLater.setForeground(Color.black);
					playLater.setBounds(200,300,500,100);
					
					pane.add(finished, BorderLayout.CENTER, 0);
					finished.setVisible(true);
					
					pane.add(playLater,BorderLayout.NORTH, 0);
					playLater.setVisible(true);
					
					playLater.addActionListener(new ActionListener() {
		
						@Override
						public void actionPerformed(ActionEvent e) {
						
		//					reset();
		//					bckgrd.remove(playAgain);
		//					playAgain.setVisible(false);
							dispose();
							
							
						}
						});	
				}
				if(crabHealth == 0)
				{
					gameWon = true;
					gameDone = true;
					
					finished.setForeground(Color.green);
					finished.setFont(new Font("Verdana", Font.PLAIN, 60));
					finished.setText("YOU WIN!");
					
	//				bckgrd.add(finished, BorderLayout.PAGE_START, 0);
					
					
					JButton moveOn = new JButton("You won! Move on!");
					pane.setLayer(moveOn, JLayeredPane.POPUP_LAYER, 0);
					moveOn.setFont(new Font("Verdana", Font.PLAIN, 30));
					moveOn.setBackground(Color.white);
					moveOn.setForeground(Color.black);
					moveOn.setBounds(200,300,500,100);
					
					pane.add(moveOn, BorderLayout.CENTER, 0);
					moveOn.setFocusable(true);
					moveOn.setVisible(true);
					
					moveOn.addActionListener(new ActionListener() {
	
						@Override
						public void actionPerformed(ActionEvent e) {
	//						reset();
	//						bckgrd.remove(playAgain);
	//						playAgain.setVisible(false);
							dispose();
							setMoveOnClicked(true);
							
							
						}
						});	
				}
				
					
				playerHealthLabel.setText("PLAYER HEALTH: " + playerHealth);
				crabHealthLabel.setText("BOSS HEALTH: " + crabHealth);
			}
		}
		
	}
		
		
			
//			if(b.getBounds().intersects(player.getPlayerX(), player.getPlayerY() + 100, 100,  100))
//			{
//				if(healthNum >= 2)
//				{
//					healthNum-=2;
//				}
//				System.out.println("ouch!");
//				this.remove(b);
//				bullets.remove(i);
//				i--;
//				player.setAmmoCount(1);
//			}
			
	
			
//			if(b.getY() + b.getHeight() > player.getPlayerY() -100 && b.getY() < player.getPlayerY())
//			{
//				if(b.getX() < player.getPlayerX() + 100 && b.getX() + b.getWidth() > player.getPlayerX() )
//				{
//					System.out.println("ouch!");
//					this.remove(b);
//					bullets.remove(i);
//					i--;
//					player.setAmmoCount(1);
//				}
//			}
			
		

	
	
	/** description of main(String[] args)
	 * creates a main method for testing purposes
	 * @param args
	 * 
	 */
	public static void main (String[] args)
	{
		new BeachBossFrame();
	}



	public JLayeredPane getPane() {
		return pane;
	}



	public void setPane(JLayeredPane pane) {
		this.pane = pane;
	}

	/**
	 * @return the crab
	 */
	public BeachBossCrab getCrab() {
		return crab;
	}

	/**
	 * @param crab the crab to set
	 */
	public void setCrab(BeachBossCrab crab) {
		this.crab = crab;
	}


	/**
	 * @return the leftPressed
	 */
	public boolean isLeftPressed() {
		return leftPressed;
	}


	/**
	 * @param leftPressed the leftPressed to set
	 */
	public void setLeftPressed(boolean leftPressed) {
		this.leftPressed = leftPressed;
	}


	/**
	 * @return the leftReleased
	 */
	public boolean isLeftReleased() {
		return leftReleased;
	}


	/**
	 * @param leftReleased the leftReleased to set
	 */
	public void setLeftReleased(boolean leftReleased) {
		this.leftReleased = leftReleased;
	}


	/**
	 * @return the rightPressed
	 */
	public boolean isRightPressed() {
		return rightPressed;
	}


	/**
	 * @param rightPressed the rightPressed to set
	 */
	public void setRightPressed(boolean rightPressed) {
		this.rightPressed = rightPressed;
	}


	/**
	 * @return the rightReleased
	 */
	public boolean isRightReleased() {
		return rightReleased;
	}


	/**
	 * @param rightReleased the rightReleased to set
	 */
	public void setRightReleased(boolean rightReleased) {
		this.rightReleased = rightReleased;
	}


	/**
	 * @return the spacePressed
	 */
	public boolean isSpacePressed() {
		return spacePressed;
	}


	/**
	 * @param spacePressed the spacePressed to set
	 */
	public void setSpacePressed(boolean spacePressed) {
		this.spacePressed = spacePressed;
	}


	/**
	 * @return the spaceReleased
	 */
	public boolean isSpaceReleased() {
		return spaceReleased;
	}


	/**
	 * @param spaceReleased the spaceReleased to set
	 */
	public void setSpaceReleased(boolean spaceReleased) {
		this.spaceReleased = spaceReleased;
	}


	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}


	/**
	 * @return the playerHealth
	 */
	public int getPlayerHealth() {
		return playerHealth;
	}


	/**
	 * @param playerHealth the playerHealth to set
	 */
	public void setPlayerHealth(int playerHealth) {
		this.playerHealth = playerHealth;
	}


	/**
	 * @return the crabHealth
	 */
	public int getCrabHealth() {
		return crabHealth;
	}


	/**
	 * @param crabHealth the crabHealth to set
	 */
	public void setCrabHealth(int crabHealth) {
		this.crabHealth = crabHealth;
	}


	/**
	 * @return the moveOnClicked
	 */
	public boolean isMoveOnClicked() {
		return moveOnClicked;
	}


	/**
	 * @param moveOnClicked the moveOnClicked to set
	 */
	public void setMoveOnClicked(boolean moveOnClicked) {
		this.moveOnClicked = moveOnClicked;
	}


	/**
	 * @return the gameActivated
	 */
	public boolean isGameActivated() {
		return gameActivated;
	}


	/**
	 * @param gameActivated the gameActivated to set
	 */
	public void setGameActivated(boolean gameActivated) {
		this.gameActivated = gameActivated;
	}



}
