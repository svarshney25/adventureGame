/** description of BeachBossCrab
 * creates a JComponent crab that moves and attacks the player
 * 
 * @author Shivani Chhaya
 */


package BeachBoss;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JComponent;

import pong.Updatable;

public class BeachBossCrab extends JComponent implements Updatable
{
	
	/** fields
	 * sets default values of the crab boss component
	 * 
	 * crabX- the starting X position of the crab
	 * crabY- the starting Y position of the crab
	 * crabLeftLeg- the starting X position of the crab's left leg(used for attacking)
	 * crabRightLeg- the starting X position of the crab's right leg(used for attacking)
	 * crabLegWidth- the width of each crab leg
	 * 
	 */
	private BufferedImage crabImage = null;
	private BeachBossFrame frame;
	private int dx;
	private int dy;
	
	private int crabX = -15;
	private int crabY = -45;
	private int crabMiddleX = 420;
	private int crabLeftLeg = 0;
	private int crabRightLeg = 475;
	private int crabLegWidth = 270;
	
	private int ammoCount = 1;
	private boolean fire;
	
	/** description of BeachBossCrab
	 * 
	 * sets default values for the crab boss component
	 * @param frame
	 * taken to get/set important values
	 */
	public BeachBossCrab(BeachBossFrame frame)
	{
		this.frame = frame;
		dx = -5;
		this.setOpaque(false);
		try
		{
			crabImage = ImageIO.read(getClass().getResourceAsStream("/beachBossImages/crabboss_crab.png"));

		}
		/**
		 * @exception IOException
		 * error with image observer and reading
		 */
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
	/** description of paintComponent(Graphics g)
	 * draws the crab image component
	 */
	public void paintComponent(Graphics g)
	{
		Graphics2D g2 = (Graphics2D)g;
		
		g2.drawImage(crabImage, crabX, crabY, 896, 768, null);
	}


	/** description of update()
	 * updates the crab position accordingly
	 */
	@Override
	public void update() 
	{
		crabX += dx;
		crabMiddleX += dx;
		crabLeftLeg += dx;
		crabRightLeg += dx;
//		frame.getContentPane().getComponentAt(-15, -45).setLocation(getX() + dx, getY());
	}


	/**
	 * @return the dx
	 */
	public int getDx() {
		return dx;
	}

	/**
	 * @param dx the dx to set
	 */
	public void setDx(int dx) {
		this.dx = dx;
	}

	public BufferedImage getCrabImage() {
		return crabImage;
	}



	public void setCrabImage(BufferedImage crabImage) {
		this.crabImage = crabImage;
	}

	public int getCrabX() {
		return crabX;
	}

	public void setCrabX(int crabX) {
		this.crabX = crabX;
	}

	public int getCrabY() {
		return crabY;
	}

	public void setCrabY(int crabY) {
		this.crabY = crabY;
	}

	public int getCrabMiddleX() {
		return crabMiddleX;
	}

	public void setCrabMiddle(int crabMiddleX) {
		this.crabMiddleX = crabMiddleX;
	}

	/** description of isFire()
	 * checks if a projectile can be shot from the crab
	 * @return
	 * returns true if ammo can still be shot
	 */
	public boolean isFire() {
		if(ammoCount > 0)
		{
			ammoCount--;
			return true;
		}
		fire = false;
		return false;
	}

	public void setFire(boolean fire) {
		this.fire = fire;
	}

	/**
	 * @return the ammoCount
	 */
	public int getAmmoCount() {
		return ammoCount;
	}

	/**
	 * @param ammoCount the ammoCount to set
	 */
	public void setAmmoCount(int ammoCount) {
		this.ammoCount = ammoCount;
	}

	/**
	 * @return the crabLeftLeg
	 */
	public int getCrabLeftLeg() {
		return crabLeftLeg;
	}

	/**
	 * @param crabLeftLeg the crabLeftLeg to set
	 */
	public void setCrabLeftLeg(int crabLeftLeg) {
		this.crabLeftLeg = crabLeftLeg;
	}

	/**
	 * @return the crabRightLeg
	 */
	public int getCrabRightLeg() {
		return crabRightLeg;
	}

	/**
	 * @param crabRightLeg the crabRightLeg to set
	 */
	public void setCrabRightLeg(int crabRightLeg) {
		this.crabRightLeg = crabRightLeg;
	}

	/**
	 * @return the crabLegWidth
	 */
	public int getCrabLegWidth() {
		return crabLegWidth;
	}

	/**
	 * @param crabLegWidth the crabLegWidth to set
	 */
	public void setCrabLegWidth(int crabLegWidth) {
		this.crabLegWidth = crabLegWidth;
	}

}
