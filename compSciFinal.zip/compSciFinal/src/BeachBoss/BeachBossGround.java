/** description of BeachBossGround
 * creates a ground image that is used when layering pngs in the JLayeredPane
 * 
 * @author Shivani Chhaya
 */

package BeachBoss;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;

public class BeachBossGround extends JLayeredPane
{
	/** fields
	 * a BufferedImage variable to be set as the ground
	 */
	private BufferedImage groundImage = null;
	
	
	/** description of BeachBossGround(BeachBossFrame frame)
	 * sets groundImage to corresponding image
	 *
	 */
	public BeachBossGround()
	{
		
		try
		{
			groundImage = ImageIO.read(getClass().getResourceAsStream("/beachBossImages/crabboss_ground.png"));

		}
		/** 
		 * @exception IOException
		 * error with image observers/ filepath
		 */
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
	/** description of paintComponent(Graphics g)
	 * draws the ground image component when used in main frame
	 * 
	 * @param g
	 * a graphic that is added to screen
	 */
	public void paintComponent(Graphics g)
	{
		Graphics2D g2 = (Graphics2D)g;
		
		g2.drawImage(groundImage, 0, -35, 896, 768, null);
	}
	
}
