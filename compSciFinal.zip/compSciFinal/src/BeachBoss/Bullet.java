/** description of Bullet
 * creates a bullet component that is used in the crab's attacks
 * 
 * @author Shivani Chhaya
 */

package BeachBoss;

import javax.swing.JComponent;

import pong.Updatable;

import java.awt.geom.Ellipse2D;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JComponent;

public class Bullet extends JComponent implements Updatable
{
	/** fields 
	 * sets default values of the bullet
	 * makes an ellipse
	 */
	private Ellipse2D.Double bullet;
	private int dy;
	private boolean shoot = false;
	private int ammoCount = 1;
	private boolean fire = false;
	
	
	/** description of Bullet(int x, int y, int dy)
	 * sets the bullet size and location as taken by the parameters
	 * @param x
	 * the starting x-coordinate of the bullet
	 * @param y
	 * the starting y-coordinate of the bullet
	 * @param dy
	 * the vertical velocity of the bullet
	 */
	public Bullet(int x, int y, int dy)
	{
		bullet = new Ellipse2D.Double(0,0,23,50);
		this.setBounds(x,y,24,51);
		this.dy = dy;  
	
		
	}
	
	/** description of paintComponent(Graphics g)
	 * takes a graphic to be added to the frame as an ellipse
	 */
	@Override
	public void paintComponent(Graphics g)
	{
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(new Color(185, 59, 33));
		g2.fill(bullet);

	}
 
	/** description of update()
	 * updates the bullet's location accordingly
	 */
	@Override
	public void update() 
	{
		setLocation(this.getX(), this.getY() + dy);
	}
	
	public int getDy()
	{
		return dy;
	}
	
	public void setDy(int dy)
	{
		this.dy = dy;
	}

	public boolean isShoot() {
		return shoot;
	}

	public void setShoot(boolean shoot) {
		this.shoot = shoot;
	}
}