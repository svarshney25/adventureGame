package tile;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;

import javax.imageio.ImageIO;
import adventureGame.GamePanel;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

/**
 * This class sets up the tiles for all 4 maps. 
 * @author Shivani Chhaya 
 * @author Shivika Varshney
 *
 */
public class TileManager {
	/**creates a gamepanel to place all the tiles*/
	private GamePanel gp;
	/**an array of all the tiles used in the game*/
	private Tile[] tile;
	/**the dimensions of the maps*/
	private int mapTileNum[][];
	/**amount of rows in a map*/
	private int worldRow;
	/**amount of columns in a column*/
	private int worldCol;
	/**each map is assigned to a number*/
	private int map;
	
	public TileManager(GamePanel gp)
	{
		this.gp = gp;
		tile = new Tile[150];
		
		map = 1;
		
		mapTileNum = new int[gp.getLastWorldCol() + 1][gp.getLastWorldRow() + 1];
		getTileImage();
		loadMap();
	}
	
	/** description of getTileImage()
	 * assigns each index of a Tile list to a tile picture
	 * collision rules are applied to each tile type
	 */
	public void getTileImage()
	{
		try 
		{
			// JUNGLE TILES
			
			tile[0] = new Tile();
			tile[0].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_grass.png")));
			tile[0].setCollision(true);
			
			tile[1] = new Tile();
			tile[1].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_path1.png"))); 
			
			tile[2] = new Tile();
			tile[2].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_path2.png")));
			
			tile[3] = new Tile();
			tile[3].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_path3.png")));
			
			tile[4] = new Tile();
			tile[4].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_path4.png")));
			
			tile[5] = new Tile();
			tile[5].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_tree.png")));
			tile[5].setCollision(true);

			tile[6] = new Tile();
			tile[6].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_stump.png")));
			tile[6].setCollision(true);

			tile[7] = new Tile();
			tile[7].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_flowers.png")));
			
			tile[8] = new Tile();
			tile[8].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_path5.png")));
			
			tile[9] = new Tile();
			tile[9].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_tree2.png")));
			tile[9].setCollision(true);

			tile[10] = new Tile();
			tile[10].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_bigTree1.png")));
			tile[10].setCollision(true);

			tile[11] = new Tile();
			tile[11].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_bigTree2.png")));
			tile[11].setCollision(true);

			tile[12] = new Tile();
			tile[12].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_bigTree3.png")));
			tile[12].setCollision(true);

			tile[13] = new Tile();
			tile[13].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_bigTree4.png")));
			tile[13].setCollision(true);

			tile[14] = new Tile();
			tile[14].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_bigDeadTree1.png")));
			tile[14].setCollision(true);

			tile[15] = new Tile();
			tile[15].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_bigDeadTree2.png")));
			tile[15].setCollision(true);

			tile[16] = new Tile();
			tile[16].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_bigDeadTree3.png")));
			tile[16].setCollision(true);

			tile[17] = new Tile();
			tile[17].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_bigDeadTree4.png")));
			tile[17].setCollision(true);
			
			tile[18] = new Tile();
			tile[18].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_bear.png")));
			tile[18].setCollision(true);
			
			tile[19] = new Tile();
			tile[19].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_wBoy.png")));
			tile[19].setCollision(true);
			
			tile[20] = new Tile();
			tile[20].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_chest.png")));
			tile[20].setCollision(true);
			
			
			// BEACH TILES 
			
			tile[21] = new Tile();
			tile[21].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_path1.png")));
			
			tile[22] = new Tile();
			tile[22].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_path2.png")));
			
			tile[23] = new Tile();
			tile[23].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_path3.png")));
			
			
//			tile[24] = new Tile();
//			tile[24].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_path2.png")));
//			tile[24].setCollision(true);
			
			tile[25] = new Tile();
			tile[25].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_sand.png")));
			tile[25].setCollision(true);
			
			tile[26] = new Tile();
			tile[26].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_water.png")));
			tile[26].setCollision(true);
			
			tile[27] = new Tile();
			tile[27].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_water1.png")));
			tile[27].setCollision(true);
			
			tile[28] = new Tile();
			tile[28].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_water2.png")));
			tile[28].setCollision(true);
			
			tile[29] = new Tile();
			tile[29].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_water3.png")));
			tile[29].setCollision(true);
			
			tile[30] = new Tile();
			tile[30].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_water4.png")));
			tile[30].setCollision(true);
			
			tile[31] = new Tile();
			tile[31].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_bush.png")));
			tile[31].setCollision(true);
			
			tile[32] = new Tile();
			tile[32].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_starfish.png")));
			tile[32].setCollision(true);
			
			tile[33] = new Tile();
			tile[33].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_stone.png")));
			tile[33].setCollision(true);
			
			tile[34] = new Tile();
			tile[34].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_bigTree1.png")));
			tile[34].setCollision(true);
			
			tile[35] = new Tile();
			tile[35].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_bigTree2.png")));
			tile[35].setCollision(true);
			
			tile[36] = new Tile();
			tile[36].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_bigTree3.png")));
			tile[36].setCollision(true);
			
			tile[37] = new Tile();
			tile[37].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_bigTree4.png")));
			tile[37].setCollision(true);
			
			tile[38] = new Tile();
			tile[38].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_bigStone1.png")));
			tile[38].setCollision(true);
			
			tile[39] = new Tile();
			tile[39].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_bigStone2.png")));
			tile[39].setCollision(true);
			
			tile[40] = new Tile();
			tile[40].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_bigStone3.png")));
			tile[40].setCollision(true);
			
			tile[41] = new Tile();
			tile[41].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_bigStone4.png")));
			tile[41].setCollision(true);
			
			tile[42] = new Tile();
			tile[42].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_tree.png")));
			tile[42].setCollision(true);
			
//			tile[43] = new Tile();
//			tile[43].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_snow.png")));
			
			//SOME MORE JUNGLE TILES, SKIPPED 43
			
			tile[44] = new Tile();
			tile[44].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_boy.png")));
			tile[44].setCollision(true);
			
			tile[45] = new Tile();
			tile[45].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_chest2.png")));
			tile[45].setCollision(true);
			
			tile[46] = new Tile();
			tile[46].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_dChest.png")));
			tile[46].setCollision(true);
//			
//			tile[47] = new Tile();
//			tile[47].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_chest2.png")));
//			tile[47].setCollision(true);
			
			tile[48] = new Tile();
			tile[48].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_girl.png")));
			tile[48].setCollision(true);
			
			tile[49] = new Tile();
			tile[49].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_fish.png")));
			tile[49].setCollision(true);
			
			tile[50] = new Tile();
			tile[50].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_stone.png")));
			
			tile[51] = new Tile();
			tile[51].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_flower.png")));
			tile[51].setCollision(true);
			
			tile[52] = new Tile();
			tile[52].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_path5 1.png")));
			tile[52].setCollision(false); 
			
			tile[53] = new Tile();
			tile[53].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_stone 1.png")));
			
			tile[54] = new Tile();
			tile[54].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_stone 2.png")));
			
			tile[55] = new Tile();
			tile[55].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_stone 3.png")));
			
			tile[56] = new Tile();
			tile[56].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_stone 4.png")));
			
			tile[57] = new Tile();
			tile[57].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_stone 5.png")));
			
			tile[58] = new Tile();
			tile[58].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_stone 6.png")));
			
			tile[59] = new Tile();
			tile[59].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_stone 7.png")));
			
			tile[60] = new Tile();
			tile[60].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/jungle/jungle_stone 8.png")));
			
			//TUNDRA TILES
			tile[61] = new Tile(); 
			tile[61].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_snow.png")));
			tile[61].setCollision(true);
			
			tile[62] = new Tile();
			tile[62].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_path.png")));
			
			tile[63] = new Tile();
			tile[63].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_path2.png")));
			
			tile[64] = new Tile();
			tile[64].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_path3.png")));
			
			tile[65] = new Tile();
			tile[65].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_corner.png")));
			
			tile[66] = new Tile();
			tile[66].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_tree.png")));
			tile[66].setCollision(true);

			tile[67] = new Tile();
			tile[67].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_ice.png")));
			tile[67].setCollision(true);

			tile[68] = new Tile();
			tile[68].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_deadBush.png")));
			tile[68].setCollision(true);

			tile[69] = new Tile();
			tile[69].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_bigTree1.png")));
			tile[69].setCollision(true);

			tile[70] = new Tile();
			tile[70].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_bigTree2.png")));
			tile[70].setCollision(true);

			tile[71] = new Tile();
			tile[71].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_bigTree3.png")));
			tile[71].setCollision(true);

			tile[72] = new Tile();
			tile[72].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_bigTree4.png")));
			tile[72].setCollision(true);

			tile[73] = new Tile();
			tile[73].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_tallTree1.png")));
			tile[73].setCollision(true);

			tile[74] = new Tile();
			tile[74].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_tallTree2.png")));
			tile[74].setCollision(true);

			tile[75] = new Tile();
			tile[75].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_tallTree3.png")));
			tile[75].setCollision(true);

			tile[76] = new Tile();
			tile[76].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_tallTree4.png")));
			tile[76].setCollision(true);

			tile[77] = new Tile();
			tile[77].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_beanie.png")));
			tile[77].setCollision(true);

			tile[78] = new Tile();
			tile[78].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_hotchocolate.png")));
			tile[78].setCollision(true);

			tile[79] = new Tile();
			tile[79].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_socks.png")));
			tile[79].setCollision(true);

			tile[80] = new Tile();
			tile[80].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/tundra/tundra_mistletoe.png")));
			tile[80].setCollision(true);

			tile[81] = new Tile();
			tile[81].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_surfboard.png")));
			tile[81].setCollision(true);
			
			tile[82] = new Tile();
			tile[82].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_umbrella.png")));
			tile[82].setCollision(true);
			
			tile[83] = new Tile();
			tile[83].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_watermelon.png")));
			tile[83].setCollision(true);
			
			tile[84] = new Tile();
			tile[84].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/beach/beach_ball.png")));
			tile[84].setCollision(true);
			
			//LAVA TILES BEGIN HERE
			tile[85] = new Tile();
			tile[85].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_bigVolcano1.png")));
			tile[85].setCollision(true);
			
			tile[86] = new Tile();
			tile[86].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_bigVolcano2.png")));
			tile[86].setCollision(true);
			
			tile[87] = new Tile();
			tile[87].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_bigVolcano3.png")));
			tile[87].setCollision(true);
			
			tile[88] = new Tile();
			tile[88].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_bigVolcano4.png")));
			tile[88].setCollision(true);

			tile[89] = new Tile();
			tile[89].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_fireBall.png")));
			tile[89].setCollision(true);
			
			tile[108] = new Tile();
			tile[108].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_fireTree.png")));
			tile[108].setCollision(true);

			tile[90] = new Tile();
			tile[90].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_ground.png")));
			tile[90].setCollision(true);
			
			tile[91] = new Tile();
			tile[91].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_lava1.png")));
			tile[91].setCollision(true);
			
			tile[92] = new Tile();
			tile[92].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_lava2.png")));
			tile[92].setCollision(true);
			
			tile[93] = new Tile();
			tile[93].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_lava3.png")));
			tile[93].setCollision(true);
			
			tile[94] = new Tile();
			tile[94].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_lava4.png")));
			tile[94].setCollision(true);
			
			tile[95] = new Tile();
			tile[95].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_lavaBoy.png")));
			tile[95].setCollision(true);
			
			tile[96] = new Tile();
			tile[96].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_lavaGirl.png")));
			tile[96].setCollision(true);
			
			tile[97] = new Tile();
			tile[97].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_miniVolcano.png")));
			tile[97].setCollision(true);
			
			tile[98] = new Tile();
			tile[98].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_smokeCloud.png")));
			tile[98].setCollision(true);

			tile[99] = new Tile();
			tile[99].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_splat.png")));
			tile[99].setCollision(true);
			
			tile[100] = new Tile();
			tile[100].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_steam.png")));
			tile[100].setCollision(true);
			
			tile[101] = new Tile();
			tile[101].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_stone.png")));
			tile[101].setCollision(true);
			
			tile[102] = new Tile();
			tile[102].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_streamCorner1.png")));
			tile[102].setCollision(true);
			
			tile[103] = new Tile();
			tile[103].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_streamCorner2.png")));
			tile[103].setCollision(true);
			
			tile[104] = new Tile();
			tile[104].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_streamCorner3.png")));
			tile[104].setCollision(true);
			
			tile[105] = new Tile();
			tile[105].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_streamCorner4.png")));
			tile[105].setCollision(true);
			
			tile[106] = new Tile();
			tile[106].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_streamHor.png")));
			tile[106].setCollision(true);
			
			tile[107] = new Tile();
			tile[107].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_streamVert.png")));
			tile[107].setCollision(true);
			
			tile[109] = new Tile();
			tile[109].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_HorizontalPath.png")));
			
			tile[110] = new Tile();
			tile[110].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_VerticalPath.png")));
			
			tile[111] = new Tile();
			tile[111].setImage(ImageIO.read(getClass().getResourceAsStream("/tiles 2/lava/lava_corner.png")));
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
	/** description of loadMap(String filePath)
	 * reads the map text file and converts it into a map of 
	 * tile images that are drawn
	 * @param filePath
	 * used to find necessary map of tiles (txt)
	 */
	public void loadMap()
	{
		String filePath = "/maps/jungleMap.txt";
		
		switch(map)
		{
		case 1:
			filePath = "/maps/jungleMap.txt";
			break;
		case 2:
			filePath = "/maps/beachMap.txt";
			break;
		case 3:
			filePath = "/maps/tundraMap.txt";
			gp.setLastWorldCol(32);
			gp.setLastWorldRow(32);
			gp.setWorldWidth(gp.getTileSize()*gp.getLastWorldRow());
			gp.setWorldHeight(gp.getTileSize()*gp.getLastWorldCol());

			break;
		case 4:
			filePath = "/maps/lavaMap.txt"; 
			gp.setLastWorldCol(32);
			gp.setLastWorldRow(32);
			gp.setWorldWidth(gp.getTileSize()*gp.getLastWorldRow());
			gp.setWorldHeight(gp.getTileSize()*gp.getLastWorldCol());
			break;
		}
		
		try
		{
			InputStream is = getClass().getResourceAsStream(filePath);
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			
			int col = 0;
			int row = 0;
			
			while(col < gp.getLastWorldCol() && row < gp.getLastWorldRow())
			{
				String line = br.readLine();
				
				while(col < gp.getLastWorldCol())
				{
					String numbers[] = line.split(" "); // makes sure that text input numbers come one by one
					
					int num = Integer.parseInt(numbers[col]); // changes input text from string to integer
					
					mapTileNum[col][row] = num;
					col++;
				}
				if(col == gp.getLastWorldCol()) // hits end of cols
				{
					col = 0;
					row++;
				}
			}
			br.close();
		}
		catch(Exception e)
		{
			
		}
	}
	
	/** description of draw(Graphics g2)
	 * draws the map after assigning each tile to a spot
	 * draws the map only when the character moves 
	 * prevents map from loading extra white out of bounds areas
	 * @param Graphics g2
	 * used to allow drawing of components
	 */
	public void draw(Graphics g2)
	{
		 worldCol = 0;
		 worldRow = 0;
		
		while(worldCol < gp.getLastWorldCol() && worldRow < gp.getLastWorldRow()) //iterates through each column and row of the map
		{
			int tileNum = mapTileNum[worldCol][worldRow]; // index of array
			
			int mapX = worldCol * gp.getTileSize(); //the x coordinate of the whole map that the player is on
			int mapY = worldRow * gp.getTileSize(); //the y coordinate of the whole map that the player is on
			int screenX = mapX - gp.getPlayer().getMapX() + gp.getPlayer().getScreenX(); //the x coordinate of the player on the screen
			int screenY = mapY - gp.getPlayer().getMapY() + gp.getPlayer().getScreenY(); //the y coordinate of the player on the screen
			
			if(gp.getPlayer().getScreenX() > gp.getPlayer().getMapX()) 
			{
				screenX = mapX;
			}
			if(gp.getPlayer().getScreenY() > gp.getPlayer().getMapY())
			{
				screenY = mapY;
			}
			if(gp.getScreenWidth() - gp.getPlayer().getScreenX() > gp.getWorldWidth() - gp.getPlayer().getMapX())
			{
				screenX = gp.getScreenWidth() - (gp.getWorldWidth() - mapX);
			}
			if(gp.getScreenHeight() - gp.getPlayer().getScreenY() > gp.getWorldHeight() - gp.getPlayer().getMapY())
			{
				screenY = gp.getScreenHeight() - (gp.getWorldHeight() - mapY);
			}
			
			if(mapX + gp.getTileSize() > gp.getPlayer().getMapX() - gp.getPlayer().getScreenX()
				&& mapX - gp.getTileSize() < gp.getPlayer().getMapX() + gp.getPlayer().getScreenX()
				&& mapY + gp.getTileSize() > gp.getPlayer().getMapY() - gp.getPlayer().getScreenY()
				&& mapY - gp.getTileSize() < gp.getPlayer().getMapY() + gp.getPlayer().getScreenY())
			{
			
				g2.drawImage(tile[tileNum].getImage(),screenX,screenY,gp.getTileSize(),gp.getTileSize(),null);

			}
			else if(gp.getPlayer().getScreenX() > gp.getPlayer().getMapX()
					|| gp.getPlayer().getScreenY() > gp.getPlayer().getMapY()
					|| gp.getScreenWidth() - gp.getPlayer().getScreenX() > gp.getWorldWidth() - gp.getPlayer().getMapX()
					|| gp.getScreenHeight() - gp.getPlayer().getScreenY() > gp.getWorldHeight() - gp.getPlayer().getMapY())
			{
				g2.drawImage(tile[tileNum].getImage(),screenX,screenY,gp.getTileSize(),gp.getTileSize(),null);

			}

			worldCol++;;
			
			
			if(worldCol == gp.getLastWorldCol())
			{
				worldCol = 0;
				worldRow++;
			}
		}

	}
	
	/** description of getMapTileNum()
	 * gets the array of number tiles
	 * returns the array
	 */
	public int[][] getMapTileNum()
	{
		return mapTileNum;
	}
	
	/** description of getTile()
	 * gets the full list of tile images
	 * returns the list of tiles
	 */
	public Tile[] getTile()
	{
		return tile;
	}
	
	public int getWorldRow()
	{
		return worldRow;
	}
	
	public void setWorldRow(int row)
	{
		worldRow = row;
	}
	
	public int getWorldCol()
	{
		return worldCol;
	}
	
	public void setWorldCol(int col)
	{
		worldCol = col;
	}

	/**
	 * @return the map
	 */
	public int getMap() {
		return map;
	}

	/**
	 * @param map the map to set
	 */
	public void setMap(int map) {
		this.map = map;
	}
}
