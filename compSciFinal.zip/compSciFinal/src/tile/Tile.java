package tile;

import java.awt.image.BufferedImage;

/**This class allows the setting of a tile to a certain image
 * @author Shivani Chhaya
 *
 */
public class Tile {
	private BufferedImage image;
	private boolean collision = false;
	
	
	/** description for getImage()
	 * allows coder to get image from this class
	 * @return
	 * desired image returned from class
	 */
	public BufferedImage getImage()
	{
		return image;
	}
	
	/** description of setImage(BufferedImage b)
	 * this method sets the image to the wanted one
	 * @param b
	 * the desired image that is to be used
	 */
	public void setImage(BufferedImage b)
	{
		image = b;
	}
	/** description of isCollision()
	 * returns whether something is collide-able or not
	 * @return the collision
	 */
	public boolean isCollision() {
		return collision;
	}

	/** description of setCollision(boolean collision)
	 * sets the collision to true or false depending on 
	 * what the player should collide with
	 * @param collision the collision to set
	 */
	public void setCollision(boolean collision) {
		this.collision = collision;
	}
}
