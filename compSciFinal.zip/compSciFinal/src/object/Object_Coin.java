package object;

import java.io.IOException;

import javax.imageio.ImageIO;

/**generates the coin object 
 * 
 * @author Shivani Chhaya
 *
 */
public class Object_Coin extends SuperObject
{
	/**creates a new coin object*/
	public Object_Coin()
	{
		super.setName("Coin");
		try 
		{
			super.setImage(ImageIO.read(getClass().getResourceAsStream("/objects/coin.png")));
		} 
		/** @exception throws an exception if an invalid file path is read */
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
		
	}
}