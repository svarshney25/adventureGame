package object;

import java.io.IOException;

import javax.imageio.ImageIO;

/**generates the hole object 
 * 
 * @author Shivani Chhaya
 *
 */
public class Object_Hole extends SuperObject
{
	
	/**creates a new hole object*/
	public Object_Hole()
	{
		super.setName("Hole");
		
		try 
		{
			super.setImage(ImageIO.read(getClass().getResourceAsStream("/objects/jungle_hole.png")));
		} 
		/** @exception throws an exception if an invalid file path is read */
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
		super.setCollision(true);
	}
}
