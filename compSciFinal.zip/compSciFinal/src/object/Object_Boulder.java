package object;

import java.io.IOException;

import javax.imageio.ImageIO;

/**generates the boulder object 
 * 
 * @author Shivani Chhaya
 *
 */
public class Object_Boulder extends SuperObject
{
	/**creates a new boulder object*/
	public Object_Boulder()
	{
		super.setName("Boulder");
		try 
		{
			super.setImage(ImageIO.read(getClass().getResourceAsStream("/objects/jungle_boulder.png")));
		} 
		/** @exception throws an exception if an invalid file path is read */

		catch (IOException e) 
		{
			e.printStackTrace();
		}
		super.setCollision(true);

	}

	
	
	
}
