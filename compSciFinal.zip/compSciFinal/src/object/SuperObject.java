package object;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.awt.Rectangle;

import javax.imageio.ImageIO;

import java.awt.Graphics2D;

import adventureGame.GamePanel;

/**this class sets up the structure of each object
 * 
 * @author Shivani Chhaya 
 *
 */
public class SuperObject {
	
	/**uploads the image of the object*/
	private BufferedImage image;
	/**name of the object*/
	private String name;
	/**determines if the object is collidable*/
	private boolean collision = false;
	/**object's x position on the map*/
	private int worldX;
	/**object's y position on the map*/
	private int worldY;
	/**the bounds of the player that collide with the bounds of the object*/
	private Rectangle solidArea = new Rectangle(0,0,50,50);
	
	/**solid area of the object - x coordinate*/
	private int solidAreaDefaultX = solidArea.x;
	/**solid area of the object - y coordinate */
	private int solidAreaDefaultY = solidArea.y;

	/**draws the object in their respective positions on the map*/
	public void draw(Graphics2D g2, GamePanel gp)
	{
		
		int screenX = worldX - gp.getPlayer().getMapX() + gp.getPlayer().getScreenX();
		int screenY = worldY - gp.getPlayer().getMapY() + gp.getPlayer().getScreenY();
		
		if(gp.getPlayer().getScreenX() > gp.getPlayer().getMapX()) 
		{
			screenX = worldX;
		}
		if(gp.getPlayer().getScreenY() > gp.getPlayer().getMapY())
		{
			screenY = worldY;
		}
		if(gp.getScreenWidth() - gp.getPlayer().getScreenX() > gp.getWorldWidth() - gp.getPlayer().getMapX())
		{
			screenX = gp.getScreenWidth() - (gp.getWorldWidth() - worldX);
		}
		if(gp.getScreenHeight() - gp.getPlayer().getScreenY() > gp.getWorldHeight() - gp.getPlayer().getMapY())
		{
			screenY = gp.getScreenHeight() - (gp.getWorldHeight() - worldY);
		}
		if(worldX + gp.getTileSize() > gp.getPlayer().getMapX() - gp.getPlayer().getScreenX()
				&& worldX - gp.getTileSize() < gp.getPlayer().getMapX() + gp.getPlayer().getScreenX()
				&& worldY + gp.getTileSize() > gp.getPlayer().getMapY() - gp.getPlayer().getScreenY()
				&& worldY - gp.getTileSize() < gp.getPlayer().getMapY() + gp.getPlayer().getScreenY())
			
		{
		
			g2.drawImage(image,screenX,screenY,gp.getTileSize(),gp.getTileSize(),null);

		}
		else if(gp.getPlayer().getScreenX() > gp.getPlayer().getMapX()
				|| gp.getPlayer().getScreenY() > gp.getPlayer().getMapY()
				|| gp.getScreenWidth() - gp.getPlayer().getScreenX() > gp.getWorldWidth() - gp.getPlayer().getMapX()
				|| gp.getScreenHeight() - gp.getPlayer().getScreenY() > gp.getWorldHeight() - gp.getPlayer().getMapY())
		{
			g2.drawImage(image ,screenX,screenY,gp.getTileSize(),gp.getTileSize(),null);

		}
	}

	
	
	/**
	 * @return the image
	 */
	public BufferedImage getImage() {
		return image;
	}
	/**
	 * @param image the image to set
	 */
	public void setImage(BufferedImage image) {
		this.image = image;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the collision
	 */
	public boolean isCollision() {
		return collision;
	}
	/**
	 * @param collision the collision to set
	 */
	public void setCollision(boolean collision) {
		this.collision = collision;
	}
	/**
	 * @return the worldX
	 */
	public int getWorldX() {
		return worldX;
	}
	/**
	 * @param worldX the worldX to set
	 */
	public void setWorldX(int worldX) {
		this.worldX = worldX;
	}
	/**
	 * @return the worldY
	 */
	public int getWorldY() {
		return worldY;
	}
	/**
	 * @param worldY the worldY to set
	 */
	public void setWorldY(int worldY) {
		this.worldY = worldY;
	}

	/**
	 * @return the solidArea
	 */
	public Rectangle getSolidArea() {
		return solidArea;
	}


	/**
	 * @param solidArea the solidArea to set
	 */
	public void setSolidArea(Rectangle solidArea) {
		this.solidArea = solidArea;
	}

	/**
	 * @return the solidAreaDefaultX
	 */
	public int getSolidAreaDefaultX() {
		return solidAreaDefaultX;
	}

	/**
	 * @param solidAreaDefaultX the solidAreaDefaultX to set
	 */
	public void setSolidAreaDefaultX(int solidAreaDefaultX) {
		this.solidAreaDefaultX = solidAreaDefaultX;
	}

	/**
	 * @return the solidAreaDefaultY
	 */
	public int getSolidAreaDefaultY() {
		return solidAreaDefaultY;
	}


	/**
	 * @param solidAreaDefaultY the solidAreaDefaultY to set
	 */
	public void setSolidAreaDefaultY(int solidAreaDefaultY) {
		this.solidAreaDefaultY = solidAreaDefaultY;
	}

}
