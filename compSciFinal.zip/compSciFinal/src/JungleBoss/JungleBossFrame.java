/** description of JungleBossFrame
 * 
 * creates a frame that carries out all functions of the tree boss battle
 * uses a JPanel, JComponents, as well as ActionListeners and KeyListeners
 * connects all components and parts of the jungle boss into one frame
 * 
 * @author Shivani Chhaya
 */


package JungleBoss;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.io.IOException;
import java.sql.Time;
import java.time.Clock;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.Timer;

public class JungleBossFrame extends JFrame implements ActionListener
{
	/** fields
	 * default values for the frame
	 * used across the components for updates and other features
	 * 
	 * healthNum and bossHealthNum- health measures for the player and boss
	 * 
	 */
	private JLabel background = new JLabel();
	private JungleBossPlayer player;
	private JungleMiniBoss boss;
	private ArrayList<Bullet> bullets;
	private Rectangle ground = new Rectangle();
	private Timer timer;
	private JungleBossBackground bckgrd;
	
	private boolean leftPressed = false;
	private boolean leftReleased = true;
	private boolean rightPressed = false;
	private boolean rightReleased = true;
	private boolean spacePressed = false;
	private boolean spaceReleased = true;
	
	private boolean gameDone = false;
	private boolean gameWon = false;
	private boolean moveOnClicked = false;
	
	private JLabel grass;
	private int healthNum = 30;
	private int bossHealthNum = 9;
	private JLabel health = new JLabel("PLAYER HEALTH: " + healthNum);
	private JLabel treeHealth = new JLabel("BOSS HEALTH: " + bossHealthNum);
	private JLabel finished = new JLabel("YOU WIN!");
	
	private BufferedImage grassImg = null;
	private BufferedImage treeImg = null;
	private BufferedImage skyImg = null;
	

	
	/** description of JungleBossFrame()
	 * creates a new frame and adds all images to it
	 * starts a timer and sets up the panel accordingly
	 * uses a keylistener to properly detect player movement
	 */
	
	public JungleBossFrame()
	{
		this.setBounds(400,400,896,768);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		this.setTitle("Mini Boss");
		this.setResizable(false);
			
	
		try 
		{
			setGrassImg(ImageIO.read(getClass().getResourceAsStream("/jungleBossImages/treeboss_grass.png")));
			setTreeImg(ImageIO.read(getClass().getResourceAsStream("/jungleBossImages/treeboss_tree.png")));
			setSkyImg(ImageIO.read(getClass().getResourceAsStream("/jungleBossImages/treeboss_sky.png")));
			
		} 
		/** 
		 * @exception IOException
		 * error with image reading/ filepath
		 */
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
		this.getContentPane();
		
//		grass = new JLabel();
//		grass.setIcon(new ImageIcon(grassImg));
		
		bullets = new ArrayList<Bullet>();

		boss = new JungleMiniBoss(this);
		bckgrd = new JungleBossBackground(0, 0, this);
		player = new JungleBossPlayer(500, 300, this);
	
		timer = new Timer(20, this);
		timer.start();
		
		bckgrd.setOpaque(false);
		
		bckgrd.setLayout(new BorderLayout());
		this.setContentPane(bckgrd);
		
		player.setOpaque(false);
		bckgrd.add(player, BorderLayout.CENTER, 0);
		
		this.addKeyListener(new KeyListener() 
		{

			@Override
			public void keyTyped(KeyEvent e) 
			{
				
			}

			@Override
			public void keyPressed(KeyEvent e) 
			{
				int code = e.getKeyCode();
				if(!gameDone)
				{
					switch(code)
					{
					case KeyEvent.VK_A:
						leftPressed = true;
						leftReleased = false;
						player.setDirection("left");
						player.setDx(-5);
						
						if(player.isFire())
						{
							
								for(int i = 0; i < 1; i++)
								{
									Bullet temp1 = new Bullet(630,(int)(Math.random()*100+525), -10);
									add(temp1);
									bullets.add(temp1);
								}
						}
						break;
					case KeyEvent.VK_D:
						rightPressed = true;
						rightReleased = false;
						player.setDirection("right");
						player.setDx(+5);
						
						//boss's ammo count is stored in the player, sorry :(
						if(player.isFire())
						{
							
								for(int i = 0; i < 1; i++)
								{
									Bullet temp1 = new Bullet(630,(int)(Math.random()*100+525), -10);
									add(temp1);
									bullets.add(temp1);
								}
						}
						break;
						
					case KeyEvent.VK_SPACE:
						spacePressed = true;
						spaceReleased = false;
	//					player.setLocation(player.getX() + player.getDx(), player.getY() -50);
						if(player.getPlayerY() + 100 > 500)
						{
							player.setDy(player.getDy()-20);
						}
						break;
					case KeyEvent.VK_ENTER:
	//					enterPressed = true;
	//					enterReleased = false;
						if(player.getX()+player.getWidth() > 645)
						{
							System.out.println("hit");
							if(bossHealthNum >= 3)
							{
								bossHealthNum -= 3;
							}
							
						}
						treeHealth.setForeground(Color.red);
					}
				}
				
				
					
			}

			@Override
			public void keyReleased(KeyEvent e) {
				
				int code = e.getKeyCode();
				if(!gameDone)
				{
					switch(code)
					{
					case KeyEvent.VK_A:
						leftPressed = false;
						leftReleased = true;
						player.setDx(0);
						break;
					case KeyEvent.VK_D:
						rightPressed = false;
						rightReleased = true;
						player.setDx(0);
				
						break;
					case KeyEvent.VK_SPACE:
						spacePressed = false;
						spaceReleased = true;
	//					player.setLocation(player.getX() + player.getDx(), player.getY() + 50);
	//					player.setDy(50);
						break;
					case KeyEvent.VK_ENTER:
						treeHealth.setForeground(Color.white);

					}
				}
			}
		});
		
		
		
		health.setForeground(Color.green);
		health.setFont(new Font("Monospaced Plain", Font.PLAIN, 20));
		health.setOpaque(false);
		
		bckgrd.add(health, BorderLayout.SOUTH, 0);
		
		treeHealth.setForeground(Color.white);
		treeHealth.setFont(new Font("Monospaced Plain", Font.PLAIN, 20));
		treeHealth.setOpaque(false);
		treeHealth.setBounds(700, 693, 200, 50);
		
		
		bckgrd.add(treeHealth, BorderLayout.LINE_END, 0);
		
		
		
	
		
		
		bckgrd.moveToFront(player);
		
//		this.getLayeredPane().add(player,0);
//		bckgrd.add(player,0);

		
		
		
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setVisible(true);
		
	}
	

	/** description of actionPerformed(ActionEvent e)
	 * allows for the updating of components on the JFrame
	 * ensures that the game is not over by checking health values before updating
	 * keeps player from leaving frame
	 * adds bullets to the frame
	 * adds choice buttons depending on victory or loss of game
	 * actionlisteners used on buttons to close screen upon completion 
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(healthNum >=2 && bossHealthNum >=3)
		{
			player.update();
		}
		else
		{
			
		}
		if(player.getPlayerY() <= 250)
		{
			player.setDy(15);
		}
		
		if(player.getPlayerY() + 100 >= 560)
		{
			player.setDy(0);
//			player.setPlayerY(501);
		}
		
		if(player.getPlayerX() + 100 >= 600)
		{
			player.setLocation(player.getX() - player.getDx(), player.getY());
		}
		
	
			for(int i = 0; i < bullets.size(); i++)
			{
				
				Bullet b = bullets.get(i);
				bckgrd.add(b, BorderLayout.NORTH, 1);
				b.update();
				
				if(b.getBounds().intersects(player.getPlayerX(), player.getPlayerY() + 100, 100,  100))
				{
					if(healthNum >= 2)
					{
						healthNum-=2;
					}
					System.out.println("ouch!");
					this.remove(b);
					bullets.remove(i);
					i--;
					player.setAmmoCount(1);
				}
//				if(b.getY() + b.getHeight() > player.getPlayerY() -100 && b.getY() < player.getPlayerY())
//				{
//					if(b.getX() < player.getPlayerX() + 100 && b.getX() + b.getWidth() > player.getPlayerX() )
//					{
//						System.out.println("ouch!");
//						this.remove(b);
//						bullets.remove(i);
//						i--;
//						player.setAmmoCount(1);
//					}
//				}
				else if(b.getX() - b.getWidth() < 0)
				{
					this.remove(b);
					bullets.remove(i); 
					i--;
					player.setAmmoCount(1);
				}
				
			}
			
			health.setText("PLAYER HEALTH: " + healthNum);
			treeHealth.setText("TREE HEALTH: " + bossHealthNum);
			
			
			if(healthNum == 0)
			{
				gameDone = true;
				
				finished.setForeground(Color.red);
				finished.setFont(new Font("Verdana", Font.PLAIN, 60));
				finished.setText("YOU DIED!");
				
				JButton playLater = new JButton("You died! Play later?");
				playLater.setFont(new Font("Verdana", Font.PLAIN, 30));
				playLater.setBackground(Color.black);
				playLater.setForeground(Color.white);
				playLater.setBounds(400,300,100,100);
				
				bckgrd.add(finished, BorderLayout.CENTER, 0);
				finished.setVisible(true);
				
				bckgrd.add(playLater,BorderLayout.NORTH, 0);
				playLater.setVisible(true);
				
				playLater.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
					
//						reset();
//						bckgrd.remove(playAgain);
//						playAgain.setVisible(false);
						dispose();
						
						
					}
					});	
							
				
			}
			if(bossHealthNum == 0)
			{
				gameWon = true;
				gameDone = true;
				
				finished.setForeground(Color.green);
				finished.setFont(new Font("Verdana", Font.PLAIN, 60));
				finished.setText("YOU WIN!");
				
//				bckgrd.add(finished, BorderLayout.PAGE_START, 0);
				
				
				JButton moveOn = new JButton("You won! Move on!");
				moveOn.setFont(new Font("Verdana", Font.PLAIN, 30));
				moveOn.setBackground(Color.black);
				moveOn.setForeground(Color.BLACK);
//				moveOn.setBounds(400,300,200,50);
				
				bckgrd.add(moveOn, BorderLayout.SOUTH, 0);
				moveOn.setFocusable(true);
				moveOn.setVisible(true);
				
				moveOn.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
//						reset();
//						bckgrd.remove(playAgain);
//						playAgain.setVisible(false);
						dispose();
						moveOnClicked = true;
						
						
					}
					});	
				
			}
			
	}
	
	/** description of main(String[] args)
	 * a main method for testing purposes
	 * @param args
	 */
	public static void main(String[] args)
	{
		new JungleBossFrame();
	}



	/**
	 * @return the leftPressed
	 */
	public boolean isLeftPressed() {
		return leftPressed;
	}



	/**
	 * @param leftPressed the leftPressed to set
	 */
	public void setLeftPressed(boolean leftPressed) {
		this.leftPressed = leftPressed;
	}



	/**
	 * @return the leftReleased
	 */
	public boolean isLeftReleased() {
		return leftReleased;
	}



	/**
	 * @param leftReleased the leftReleased to set
	 */
	public void setLeftReleased(boolean leftReleased) {
		this.leftReleased = leftReleased;
	}



	/**
	 * @return the rightPressed
	 */
	public boolean isRightPressed() {
		return rightPressed;
	}



	/**
	 * @param rightPressed the rightPressed to set
	 */
	public void setRightPressed(boolean rightPressed) {
		this.rightPressed = rightPressed;
	}



	/**
	 * @return the rightReleased
	 */
	public boolean isRightReleased() {
		return rightReleased;
	}



	/**
	 * @param rightReleased the rightReleased to set
	 */
	public void setRightReleased(boolean rightReleased) {
		this.rightReleased = rightReleased;
	}



	/**
	 * @return the spaceReleased
	 */
	public boolean isSpaceReleased() {
		return spaceReleased;
	}



	/**
	 * @param spaceReleased the spaceReleased to set
	 */
	public void setSpaceReleased(boolean spaceReleased) {
		this.spaceReleased = spaceReleased;
	}



	/**
	 * @return the spacePressed
	 */
	public boolean isSpacePressed() {
		return spacePressed;
	}



	/**
	 * @param spacePressed the spacePressed to set
	 */
	public void setSpacePressed(boolean spacePressed) {
		this.spacePressed = spacePressed;
	}

	public BufferedImage getGrassImg() {
		return grassImg;
	}

	public void setGrassImg(BufferedImage grassImg) {
		this.grassImg = grassImg;
	}

	public BufferedImage getTreeImg() {
		return treeImg;
	}

	public void setTreeImg(BufferedImage treeImg) {
		this.treeImg = treeImg;
	}

	public BufferedImage getSkyImg() {
		return skyImg;
	}

	public void setSkyImg(BufferedImage skyImg) {
		this.skyImg = skyImg;
	}
	
	public ArrayList<Bullet> getBulletList()
	{
		return bullets;
	}
	
	public void setBulletList(int index, Bullet b)
	{
		bullets.set(index, b);
	}



	public int getHealthNum() {
		return healthNum;
	}



	public void setHealthNum(int healthNum) {
		this.healthNum = healthNum;
	}
	
	public JungleBossPlayer getPlayer()
	{
		return player;
	}
	
	public void setPlayer(JungleBossPlayer player)
	{
		this.player = player;
	}



	public boolean isGameDone() {
		return gameDone;
	}



	public void setGameDone(boolean gameDone) {
		this.gameDone = gameDone;
	}



	public boolean isMoveOnClicked() {
		return moveOnClicked;
	}



	public void setMoveOnClicked(boolean nextMap) {
		this.moveOnClicked = nextMap;
	}

}

