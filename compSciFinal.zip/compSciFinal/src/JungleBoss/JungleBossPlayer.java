/** description of JungleBossPlayer
 * creates a player component for the jungle boss player
 * 
 * @author Shivani Chhaya
 */



package JungleBoss;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JComponent;

import Entity.Entity;

public class JungleBossPlayer extends JComponent
{
	
	/** fields
	 * default values of the player component 
	 * 
	 * ammoCount is created here, however is used to represent the jungle boss's ammo
	 * Images- used for sprite animations
	 * direction- used for sprite animations
	 * playerX and playerY- player's initial X and Y coordinates
	 */
	private int dx;
	private int dy;
	private Image left1,left2,left3,left4,right1,right2,right3,right4;
	private Image image = null;
	private String direction = "right";
	private int spriteNum = 1;
	private int spriteCounter = 0;
	private JungleBossFrame frame;
	private int playerX = 100;
	private int playerY = 450;
	private int ammoCount = 1;
	private boolean fire = true;

	
	/** description of JungleBossPlayer(int x, int y, JungleBossFrame frame)
	 * sets default values of the player component
	 * @param x
	 * the starting x-coordinate of the player
	 * @param y
	 * the starting y-coordinate of the player
	 * @param frame
	 * the frame used to display all components, taken as arg in order to get/set certain values
	 */
	public JungleBossPlayer(int x, int y, JungleBossFrame frame)
	{
		this.setBounds(x,y,50,50);
		this.frame = frame;
		setDefaultValues();
		getPlayerImage();
		this.setDoubleBuffered(true);
		
	}
	
	/** description of setDefaultValues()
	 * sets the dx and dy of the player
	 */
	public void setDefaultValues()
	{
	
		this.dx = 0;
		this.dy = 0;
	}
	
	/** description of getPlayerImage()
	 * assigns each BufferedImage variable to its corresponding image/file path
	 */
	public void getPlayerImage()
	{
		try
		{
			left1 = (ImageIO.read(getClass().getResourceAsStream("/Left/Left_MidStep.png")));
			left2 = (ImageIO.read(getClass().getResourceAsStream("/Left/Left_LeftStep.png")));
			left3 = (ImageIO.read(getClass().getResourceAsStream("/Left/Left_Rest.png")));
			left4 = (ImageIO.read(getClass().getResourceAsStream("/Left/Left_RightStep.png")));
			right1 = (ImageIO.read(getClass().getResourceAsStream("/Right/Right_MidStep.png")));
			right2 = (ImageIO.read(getClass().getResourceAsStream("/Right/Right_LeftStep.png")));
			right3 = (ImageIO.read(getClass().getResourceAsStream("/Right/Right_Rest.png")));
			right4 = (ImageIO.read(getClass().getResourceAsStream("/Right/Right_RightStep.png")));

		}
		/** 
		 * @exception IOException
		 * error with image reading/ filepath
		 */
		catch(IOException e) 
		{
			e.printStackTrace();
		}
		
	}
	
	/** description of update()
	 * updates the player's location and directions accordingly
	 * based on keylistener inputs
	 */
	public void update()
	{
		
		playerX += dx;
		playerY += dy;
		
		setLocation(getX() + dx, getY()+dy);
		
		if(frame.isLeftPressed() || frame.isRightPressed())
		{
			if(frame.isLeftPressed() == true)
			{
				setDirection("left");
			}
			else if(frame.isRightPressed() == true)
			{
				setDirection("right");
			}
	//		else if(frame.isLeftReleased() && frame.isRightReleased())
	//		{
	//			setDirection("right");
	//		}
	//		else if(frame.isSpacePressed() && getY() == 450)
	//		{
	//			while(getY() <= 450 && getY() > 470)
	//			{
	//				setLocation(getX() + dy, getY() + dy);
	//			}
	//			
	//			while(getY() < 450 && getY() <= 470)
	//			{
	//				setLocation(getX(), getY() - dy);
	//			}
	//		}
	//		else
	//		{
	//			setLocation(getX(), getY());
	//		}
			
			spriteCounter +=1;
			if(spriteCounter > 6)
			{
				if(spriteNum == 1)
				{
					spriteNum = 2;
				}
				else if(spriteNum == 2)
				{
					spriteNum = 3;
				}
				else if(spriteNum == 3)
				{
					spriteNum = 4; 
				}
				else if(spriteNum == 4)
				{
					spriteNum = 1;
				}
				
				spriteCounter = 0;
			}
		}
		else
		{
			spriteNum = 1;
		}
		
//		setLocation(getX()+dx, getY()+dy);
		
	}
	
	/** description of paintComponent(Graphics g2)
	 * animates the player using switch case and image  assignment
	 * allows for the image to be painted on the main frame
	 * @param g2
	 * takes in a type of graphic to display on screen
	 */
	@Override
	public void paintComponent(Graphics g2)
	{	
//		super.paintComponent(g2); 
		
		Graphics2D g = (Graphics2D)g2;
		
		switch(direction)
		{
		case "left":
			if(spriteNum == 1)
			{
				image = left1;
			}
			if(spriteNum == 2)
			{
				image = left2;
			}
			if(spriteNum == 3)
			{
				image = left3;
			}
			if(spriteNum == 4)
			{
				image = left4;
			}
			break;
			
		case "right":
			if(spriteNum == 1)
			{
				image = right1;
			}
			if(spriteNum == 2)
			{
				image = right2;
			}
			if(spriteNum == 3)
			{
				image = right3;
			}
			if(spriteNum == 4)
			{
				image = right4;
			}
			break; 
		}	
		
		g.drawImage(image, 100,560, 125, 125, null);
		

	}
	
	
	public int getDx() {
		return dx;
	}
	public void setDx(int dx) {
		this.dx = dx;
	}
	
	public int getDy() {
		return dy;
	}
	public void setDy(int dy) {
		this.dy = dy;
	}
	
	public String getDirection()
	{
		return direction;
	}
	
	public void setDirection(String direction)
	{
		this.direction = direction;
	}

	/**
	 * @return the playerStartingY
	 */
	public int getPlayerY() {
		return playerY;
	}

	/**
	 * @param playerStartingY the playerStartingY to set
	 */
	public void setPlayerY(int playerY) {
		this.playerY = playerY;
	}

	/**
	 * @return the playerStartingX
	 */
	public int getPlayerX() {
		return playerX;
	}
	

	/**
	 * @param playerStartingX the playerStartingX to set
	 */
	public void setPlayerX(int playerX) {
		this.playerX = playerX;
	}
	
	public int getAmmoCount() 
	{
		return ammoCount;
	}

	public void setAmmoCount(int ammoCount) {
		this.ammoCount = ammoCount;
	}

	public boolean isFire() 
	{
		if(ammoCount > 0)
		{
			ammoCount--;
			return true;
		}
		fire = false;
		return false;
	}

	public void setFire(boolean fire) {
		this.fire = fire;
	}
	
	public Image getImage()
	{
		return image;
	}
	
	public void setImage(Image image)
	{
		this.image = image;
	}
}