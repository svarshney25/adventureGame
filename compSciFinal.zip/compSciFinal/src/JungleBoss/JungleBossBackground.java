/** description of JungleBossBackground
 * creates a JLayeredPane with multiple components on it
 * layers 3 pngs together to create a background for the jungle Boss
 * 
 * @author Shivani Chhaya
 */

package JungleBoss;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;

public class JungleBossBackground extends JLayeredPane
{
	/** fields
	 * sets default values and labels
	 */
	private JungleBossFrame frame;
	private BufferedImage skyImage;
	private BufferedImage grassImage;
	private BufferedImage treeImage;
	
	private JLabel grass = new JLabel("");
	private JLabel sky = new JLabel("");
	private JLabel tree = new JLabel("");
	
	
	/** description of JungleBossBackground(int x, int y, JungleBossFrame frame)
	 * creates the frame background
	 * @param x
	 * x-coordinate of pane
	 * @param y
	 * y-coordinate of pane
	 * @param frame
	 * used for getters/setters
	 */
	public JungleBossBackground(int x, int y, JungleBossFrame frame)
	{
		this.setBounds(x,y,896,768);
		
		this.frame = frame;
		
		skyImage = frame.getSkyImg();
		grassImage = frame.getGrassImg();
		treeImage = frame.getTreeImg();
		
		grass.setIcon(new ImageIcon(grassImage));
		sky.setIcon(new ImageIcon(skyImage));
		tree.setIcon(new ImageIcon(treeImage));
		
		grass.setBounds(0,-30,896, 768);
		sky.setBounds(0,0,896, 768);
		tree.setBounds(0,-6,896, 768);
		
		
//		grass.setVisible(true);
//		sky.setVisible(true);
//		tree.setVisible(true);
	
		this.add(tree, 2);
		this.add(grass, 3);
		this.add(sky, 4);
		
		
	
	}
	/** description of paintComponent(Graphics g)
	 * takes a graphic to be added to the frame as an ellipse
	 */
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g; 
		
		skyImage = frame.getSkyImg();
		grassImage = frame.getGrassImg();
		treeImage = frame.getTreeImg();
		
//		g2.drawImage(skyImage,0,0,896, 768, null);
//		g2.drawImage(grassImage,0,5,896, 768, null);
//		g2.drawImage(treeImage,0,0,896, 768, null);
			
	}

	public BufferedImage getSkyImage() {
		return skyImage;
	}

	public void setSkyImage(BufferedImage skyImage) {
		this.skyImage = skyImage;
	}

	public BufferedImage getTreeImage() {
		return treeImage;
	}

	public void setTreeImage(BufferedImage treeImage) {
		this.treeImage = treeImage;
	}

	public BufferedImage getGrassImage() {
		return grassImage;
	}

	public void setGrassImage(BufferedImage grassImage) {
		this.grassImage = grassImage;
	}
}
