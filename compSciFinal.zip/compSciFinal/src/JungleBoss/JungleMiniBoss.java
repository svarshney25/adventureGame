/** description of JungleMiniBoss
 * creates a tree component to layer on top of everything in main frame
 * 
 * @author Shivani Chhaya
 */

package JungleBoss;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Color;
import javax.swing.JComponent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class JungleMiniBoss extends JComponent implements ActionListener
{
	/** fields
	 * sets default values
	 */
	private JungleKeyHandler keyH = new JungleKeyHandler(this);
	private ArrayList<Bullet> bullets;
	private Rectangle bossR = new Rectangle();
	private BufferedImage treeImage = null;
	private JungleBossFrame frame;
	
	
	/** description of JungleMiniBoss(JungleBossFrame frame)
	 * used to set treeImage
	 * @param frame
	 * taken for getting/setting important values
	 */
	public JungleMiniBoss(JungleBossFrame frame) 
	{
		this.frame = frame;
		treeImage = frame.getTreeImg();
	}
	
	
	
//	@Override
//	public void paintComponent(Graphics g)
//	{
//		super.paintComponent(g);
//		
//		Graphics2D g2 = (Graphics2D) g;
//		
////		g2.drawImage(treeImage,0,0,896, 768, null);
//		
//	}



	@Override
	public void actionPerformed(ActionEvent e) {
		
	}
}
