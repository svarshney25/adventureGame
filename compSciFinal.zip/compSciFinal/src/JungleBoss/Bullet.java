/** description of Bullet
 * creates a bullet component that is used in the crab's attacks
 * 
 * @author Shivani Chhaya
 */

package JungleBoss;

import javax.swing.JComponent;

import pong.Updatable;

import java.awt.geom.Ellipse2D;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JComponent;

public class Bullet extends JComponent implements Updatable
{
	/** fields 
	 * sets default values of the bullet
	 * makes an ellipse
	 */
	private Ellipse2D.Double bullet;
	private int dx;
	private boolean shoot = false;
	private int ammoCount = 1;
	private boolean fire = false;
	
	/** description of Bullet(int x, int y, int dx)
	 * sets the bullet size and location as taken by the parameters
	 * @param x
	 * the starting x-coordinate of the bullet
	 * @param y
	 * the starting y-coordinate of the bullet
	 * @param dx
	 * the horizontal velocity of the bullet
	 */
	public Bullet(int x, int y, int dx)
	{
		bullet = new Ellipse2D.Double(0,0,50,23);
		this.setBounds(x,y,51,24);
		this.dx = dx;  
		
	}
	
	/** description of paintComponent(Graphics g)
	 * takes a graphic to be added to the frame as an ellipse
	 */
	@Override
	public void paintComponent(Graphics g)
	{
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(new Color(129,83,44));
		g2.fill(bullet);

	}
	
	
	/** description of update()
	 * updates the bullet's location accordingly
	 */
	@Override
	public void update() 
	{
		setLocation(this.getX() + dx, getY());
	}
	
	public int getDx()
	{
		return dx;
	}
	
	public void setDx(int dx)
	{
		this.dx = dx;
	}

	public boolean isShoot() {
		return shoot;
	}

	public void setShoot(boolean shoot) {
		this.shoot = shoot;
	}
}
