/** description of JungleKeyHandler
 * sets boolean values to key inputs for player movement
 * 
 * @author Shivani Chhaya
 */

package JungleBoss;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class JungleKeyHandler implements KeyListener
{
	
	/** fields
	 * set default values/ declares them
	 * for key inputs
	 */
	private boolean upPressed, downPressed, leftPressed, rightPressed;
	private boolean upReleased, downReleased, leftReleased, rightReleased;
	private JungleMiniBoss jungleMiniBoss;
	
	/** description of JungleKeyHandler(JungleMiniBoss jungleMiniBoss)
	 * uses miniBoss
	 * @param jungleMiniBoss
	 * used for getters/setters
	 */
	public JungleKeyHandler(JungleMiniBoss jungleMiniBoss)
	{
		this.jungleMiniBoss = jungleMiniBoss;
	}
	

	@Override
	public void keyPressed(KeyEvent e) {
		
		int code = e.getKeyCode();
		switch(code)
		{
		case KeyEvent.VK_A:
			setLeftPressed(true);
			setLeftReleased(false);
			break;
		case KeyEvent.VK_D:
			setRightPressed(true);
			setRightReleased(false);
			break;
		}		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		
		int code = e.getKeyCode();
		switch(code)
		{
		case KeyEvent.VK_A:
			setLeftPressed(false);
			setLeftReleased(true);
			break;
		case KeyEvent.VK_D:
			setRightPressed(false);
			setRightReleased(true);
			break;
		}
	}
	
	
	
	
	
	
	
	
	/**
	 * @return the leftPressed
	 */
	public boolean isLeftPressed() {
		return leftPressed;
	}
	/**
	 * @param leftPressed the leftPressed to set
	 */
	public void setLeftPressed(boolean leftPressed) {
		this.leftPressed = leftPressed;
	}
	/**
	 * @return the rightPressed
	 */
	public boolean isRightPressed() {
		return rightPressed;
	}
	/**
	 * @param rightPressed the rightPressed to set
	 */
	public void setRightPressed(boolean rightPressed) {
		this.rightPressed = rightPressed;
	}
	/**
	 * @return the leftReleased
	 */
	public boolean isLeftReleased() {
		return leftReleased;
	}
	/**
	 * @param leftReleased the leftReleased to set
	 */
	public void setLeftReleased(boolean leftReleased) {
		this.leftReleased = leftReleased;
	}
	/**
	 * @return the rightReleased
	 */
	public boolean isRightReleased() {
		return rightReleased;
	}
	/**
	 * @param rightReleased the rightReleased to set
	 */
	public void setRightReleased(boolean rightReleased) {
		this.rightReleased = rightReleased;
	}


	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}











	










	
}