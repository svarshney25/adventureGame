package brickBreaker;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;
import javax.swing.Timer;

/** Handles most of the interactions with the game and how the game is meant to function
 * 
 * @author Bella Acker
 * @author Britney Yang ( comments )
 *
 */
public class GamePlay extends JPanel implements KeyListener, ActionListener  {
	/**	determines whether or not the player is playing */
		private boolean play = true;
		/** The amount of bricks broken*/
		private int score = 0;
		
		/** number of bricks in the game */
		private int totalBricks = 21;
		
		/** game timer for while the game is running regardign the speed of the ball */
		private Timer timer;
		/** delay in speed*/
		private int delay = 8;
		
		/**	starting position of the slider */
		private int playerX = 310;
		
		/** starting x position of the ball */
		private int ballposX = 120;
		/** starting y position of the ball	 */
		private int ballposY = 350;
		/**	starting horizontal direction of the ball */
		private int ballXdir = -1;
		/** starting vertical direction of the ball */
		private int ballYdir = -2;
		
		/**	map to be generated */
		private MapGenerator map;
		
		/** determines if the game has ended yet */
		private boolean gameWon = false;

		/** creates a new game with it's various forms of interactions 
		 * established, but not yet detailed, as well as starting the 
		 * game for the player to interact
		 * 
		 */
		public GamePlay() {
			map = new MapGenerator(3, 7);
			addKeyListener(this);
			setFocusable(true);
			setFocusTraversalKeysEnabled(false);
			timer = new Timer(delay, this);
			timer.start();
			gameWon = false;
			
			
		}
		public boolean isGameWon() {
			return gameWon;
		}
		
		public int getScore() {
			return score;
		}
		
		public void setScore(int score) {
			this.score = score;
		}
		
		public int getTotalBricks() {
			return totalBricks;
		}
		
		public int getBallPosY() {
			return ballposY;
		}

		/** Painting most of the details on the game's frame relating to the ball, 
		 * starting platform, and statistic about the game. Also determines when 
		 * the game ends and whether or not the player has won, prompting them to 
		 * either restart or close out on its own, ending the minigame
		 * 
		 */
		public void paint(Graphics g) {
			
			//background
			Color lightblue = new Color (198,207,230);
			g.setColor(lightblue);
			g.fillRect(1, 1, 692, 592);
			
			map.draw((Graphics2D)g);
			
			g.fillRect(0, 0, 3, 592);
			g.fillRect(0, 0, 692, 3);
			g.fillRect(691, 0, 3, 592);
			
			//starting platform
			g.setColor(new Color(14,20,36));
			g.fillRect(playerX, 550, 100, 12);
			
			//ball
			g.setColor(Color.white);  
			g.fillOval(ballposX, ballposY, 20, 20);
			
			g.setColor(Color.black);
			g.setFont(new Font("Georgia", Font.BOLD, 25));
			g.drawString("Score: " + score, 520, 30);
			
			if (totalBricks <= 0) { 
				gameWon = true;
				play = false;
				ballXdir = 0;
				ballYdir = 0;
				g.setColor(new Color(14,20,36));
				g.setFont(new Font("Georgia", Font.BOLD, 30));
				g.drawString("You Won, Score: " + score, 190, 300);
				
				g.setFont(new Font("Georgia", Font.BOLD, 20));
				g.drawString("Press Enter to Restart.", 230, 350);
			}
			
			if(ballposY > 570) {
				gameWon = true;
				play = false;
				ballXdir = 0;
				ballYdir = 0;
				g.setColor(Color.BLACK);
				g.setFont(new Font("Georgia", Font.BOLD, 30));
				g.drawString("Game Over, Score: " + score, 190, 300);
				
				g.setFont(new Font("Georgia", Font.BOLD, 20));
				g.drawString("Press Enter to Restart", 230, 350);
				
			} 
			g.dispose();
		}

		/** largely works on detecting the collisions within this game. Handles the direction 
		 * change of the ball when colliding with the players platform or the bricks. It also 
		 * handles the rmeoval of the brick from the screen once the brick has been hit, 
		 * changing the direction still and changing the score 
		 * 
		 */
		@Override
		public void actionPerformed(ActionEvent arg0) {
			timer.start();
			if(play) {

				if(new Rectangle(ballposX, ballposY, 20, 20).intersects(new Rectangle(playerX, 550, 100, 8))) {
					ballYdir = - ballYdir;
				}
				for( int i = 0; i<map.map.length; i++) {
					for(int j = 0; j<map.map[0].length; j++) { 
						if(map.map[i][j] > 0) {
							int brickX = j*map.brickWidth + 80;
							int brickY = i*map.brickHeight + 50;
							int brickWidth= map.brickWidth;
							int brickHeight = map.brickHeight;
							
							Rectangle rect = new Rectangle(brickX, brickY, brickWidth, brickHeight);
							Rectangle ballRect = new Rectangle(ballposX, ballposY, 20,20);
							Rectangle brickRect = rect;
							
							if(ballRect.intersects(brickRect) ) {
								map.setBrickValue(0, i, j);
								totalBricks--;
								score+=1;
								
								if(ballposX + 19 <= brickRect.x || ballposX +1 >= brickRect.x + brickRect.width) 
									ballXdir = -ballXdir;
								 else {
									ballYdir = -ballYdir;
								}
							}
							
						}
						
					}
				}
				
				ballposX += ballXdir;
				ballposY += ballYdir;
				if(ballposX < 0) { 
					ballXdir = -ballXdir;}
				if(ballposY < 0) { 
					ballYdir = -ballYdir;}
				if(ballposX > 670) { 
					ballXdir = -ballXdir;}
				
			}
			
			
			repaint();

		}
		

		@Override
		public void keyTyped(KeyEvent arg0) {
			
		}
		
		/** moves the platform right until they hit a certain bound */
		@Override
		public void keyPressed(KeyEvent arg0) {
			if(arg0.getKeyCode() == KeyEvent.VK_RIGHT) { 
				if(playerX >= 600) {
					playerX = 600;
				} else {
					moveRight();
						
				}
			}
			/** moves the platform left until they hit a certain bound */
			if(arg0.getKeyCode() == KeyEvent.VK_LEFT) { 
				if(playerX < 10) {
					playerX = 10;
				} else {
					moveLeft();
						
				}
			}
			/** If the game isn't currently going on, starts the game with reset positioning and brick layout as well as score */
			if(arg0.getKeyCode() == KeyEvent.VK_ENTER) { 
				if(!play) {
					play = true;
					ballposX = 120;
					ballposY = 350;
					ballXdir = -1;
					ballYdir = -2;
					score = 0;
					totalBricks = 21;
					map = new MapGenerator(3,7);
					
					repaint();
				}
			}
			
		}	
		/** moves the platform right by 50*/
			public void moveRight() {
				play = true;
				playerX += 50;
			}
			/** moves the platform left by 50*/
			public void moveLeft() { 
				play = true;
				playerX -= 50;
			}
			

		@Override
		public void keyReleased(KeyEvent arg0) {
			
		}
		
		
		
	}


