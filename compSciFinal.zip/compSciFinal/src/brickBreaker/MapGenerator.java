package brickBreaker;

import javax.swing.*;
import java.awt.*;

/**	Class here the map of the game is generated as well as values that relate 
 * to the managing of the map and the measurements of the map
 * 
 * @author Bella Acker
 * @author Britney Yang ( comments )
 *
 */
	public class MapGenerator extends JFrame {
		
		/** map containing numerical valus representing the size of the map*/
		public int map [][];
		/**	The width of bricks that can be horizontally present based on 
		 * the number of columns in the map 2D array*/
		public int brickWidth;
		/**	The height of bricks that can be vertically present based on the 
		 * number of rows in the map 2D array*/
		public int brickHeight;
		
		/** Creates the map array based on a given number of rows and columns, 
		 * also using that information to determine the size of bricks that 
		 * can be added in order to fit the screen
		 * 
		 * @param row	number of rows of bricks
		 * @param col	number of columns of bricks
		 */
		public MapGenerator(int row, int col) {
			map = new int [row][col];
			for (int i = 0; i < map.length; i++) { 
				for (int j=0; j< map[0].length;j++) {
					map[i][j] = 1;
				}
			}
			
			brickWidth = 540/col;
			brickHeight = 150/row;
		}
		
		/**	Using the genrated 2D array and brick measurements, the methiod 
		 * will allo for the bricks to be created or drawn on the JFrame
		 * 
		 */
		public void draw(Graphics2D g) {
			Color ice = new Color (102,125,188);
			for (int i = 0; i < map.length; i++) {
				for (int j=0; j< map[0].length;j++) {
					if(map[i][j] > 0) {
						g.setColor(ice); 
						g.fillRect(j*brickWidth + 80, i*brickHeight + 50, brickWidth, brickHeight);
						
						g.setStroke(new BasicStroke(4));
						g.setColor(Color.BLACK);
						g.drawRect(j*brickWidth + 80, i*brickHeight + 50, brickWidth, brickHeight);
					}
				}
				
			}
		}
		
		/** Assigns a certain value to a brick on the 2D array based on row and column
		 * 
		 * @param value		number to be assigned to the area of the 2D array
		 * @param row		row here the value is assigned
		 * @param col		column where the value is assigned
		 */
		public void setBrickValue(int value, int row, int col) {
			map[row][col] = value;
		}

	}