package adventureGame;
import object.Object_Boulder;
import object.Object_Hole;
import object.Object_Coin;

/**
 * sets up the locations of each of the coins, holes, and boulders on the maps
 * @author Shivani Chhaya
 * @author Shivika Varshney
 */
public class AssetSetter 
{
	/**creates a gamepanel object*/
	private GamePanel gp;
	
	/**creates a new assetsetter 
	 * 
	 * @param gp
	 * the parameter gp allows the various objects to be placed on that gamepanel
	 */
	public AssetSetter(GamePanel gp)
	{
		this.gp = gp;
	}
	
	/**
	 * this method sets objects at a certain position in the list to the one 
	 * that is being created such as a coin, boulder, or hole 
	 */
	public void setObject()
	{
		
		/*adding hole throughout the jungle map*/
		gp.getObject()[1] = new Object_Hole();
		gp.getObject()[1].setWorldX(60*gp.getTileSize());
		gp.getObject()[1].setWorldY(7*gp.getTileSize());
		
		/*adding coins throughout the jungle map*/
		gp.getObject()[2] = new Object_Coin();
		gp.getObject()[2].setWorldX(4*gp.getTileSize());
		gp.getObject()[2].setWorldY(7*gp.getTileSize());
		
		gp.getObject()[3] = new Object_Coin();
		gp.getObject()[3].setWorldX(10*gp.getTileSize());
		gp.getObject()[3].setWorldY(56*gp.getTileSize());
		
		gp.getObject()[4] = new Object_Coin();
		gp.getObject()[4].setWorldX(13*gp.getTileSize());
		gp.getObject()[4].setWorldY(7*gp.getTileSize());
		
		gp.getObject()[5] = new Object_Coin();
		gp.getObject()[5].setWorldX(7*gp.getTileSize());
		gp.getObject()[5].setWorldY(51*gp.getTileSize());
		
		gp.getObject()[6] = new Object_Coin();
		gp.getObject()[6].setWorldX(16*gp.getTileSize());
		gp.getObject()[6].setWorldY(30*gp.getTileSize());
		
		gp.getObject()[7] = new Object_Coin();
		gp.getObject()[7].setWorldX(23*gp.getTileSize());
		gp.getObject()[7].setWorldY(26*gp.getTileSize());
		
		gp.getObject()[8] = new Object_Coin();
		gp.getObject()[8].setWorldX(38*gp.getTileSize());
		gp.getObject()[8].setWorldY(15*gp.getTileSize());
		
		gp.getObject()[9] = new Object_Coin();
		gp.getObject()[9].setWorldX(54*gp.getTileSize());
		gp.getObject()[9].setWorldY(13*gp.getTileSize());
		
		gp.getObject()[10] = new Object_Coin();
		gp.getObject()[10].setWorldX(31*gp.getTileSize());
		gp.getObject()[10].setWorldY(51*gp.getTileSize());
	
		gp.getObject()[11] = new Object_Coin();
		gp.getObject()[11].setWorldX(39*gp.getTileSize());
		gp.getObject()[11].setWorldY(43*gp.getTileSize());
		
		gp.getObject()[12] = new Object_Coin();
		gp.getObject()[12].setWorldX(39*gp.getTileSize());
		gp.getObject()[12].setWorldY(26*gp.getTileSize());
	
		gp.getObject()[13] = new Object_Coin();
		gp.getObject()[13].setWorldX(25*gp.getTileSize());
		gp.getObject()[13].setWorldY(17*gp.getTileSize());
		
		/*adding coins throughout the beach map*/
		gp.getObject()[14] = new Object_Coin();
		gp.getObject()[14].setWorldX(16*gp.getTileSize());
		gp.getObject()[14].setWorldY(10*gp.getTileSize());
		
		gp.getObject()[15] = new Object_Coin();
		gp.getObject()[15].setWorldX(24*gp.getTileSize());
		gp.getObject()[15].setWorldY(57*gp.getTileSize());
		
		gp.getObject()[16] = new Object_Coin();
		gp.getObject()[16].setWorldX(31*gp.getTileSize());
		gp.getObject()[16].setWorldY(15*gp.getTileSize());
		
		gp.getObject()[17] = new Object_Coin();
		gp.getObject()[17].setWorldX(2*gp.getTileSize());
		gp.getObject()[17].setWorldY(38*gp.getTileSize());
		
		gp.getObject()[18] = new Object_Coin();
		gp.getObject()[18].setWorldX(6*gp.getTileSize());
		gp.getObject()[18].setWorldY(12*gp.getTileSize());
		
		gp.getObject()[19] = new Object_Coin();
		gp.getObject()[19].setWorldX(8*gp.getTileSize());
		gp.getObject()[19].setWorldY(14*gp.getTileSize());
		
		gp.getObject()[20] = new Object_Coin();
		gp.getObject()[20].setWorldX(58*gp.getTileSize());
		gp.getObject()[20].setWorldY(19*gp.getTileSize());
		
		gp.getObject()[21] = new Object_Coin();
		gp.getObject()[21].setWorldX(59*gp.getTileSize());
		gp.getObject()[21].setWorldY(53*gp.getTileSize());
		
		gp.getObject()[22] = new Object_Coin();
		gp.getObject()[22].setWorldX(56*gp.getTileSize());
		gp.getObject()[22].setWorldY(46*gp.getTileSize());
		
		
		/*TUNDRA MAP*/
		/*add coins in the tundra map*/ 
		gp.getObject()[23] = new Object_Coin();
		gp.getObject()[23].setWorldX(17*gp.getTileSize());
		gp.getObject()[23].setWorldY(22*gp.getTileSize());
		
		gp.getObject()[24] = new Object_Coin();
		gp.getObject()[24].setWorldX(10*gp.getTileSize());
		gp.getObject()[24].setWorldY(14*gp.getTileSize());

		gp.getObject()[25] = new Object_Coin();
		gp.getObject()[25].setWorldX(25*gp.getTileSize());
		gp.getObject()[25].setWorldY(4*gp.getTileSize());
		
		gp.getObject()[26] = new Object_Coin();
		gp.getObject()[26].setWorldX(6*gp.getTileSize());
		gp.getObject()[26].setWorldY(4*gp.getTileSize());
		
		gp.getObject()[27] = new Object_Coin();
		gp.getObject()[27].setWorldX(14*gp.getTileSize());
		gp.getObject()[27].setWorldY(23*gp.getTileSize());
		
		gp.getObject()[28] = new Object_Coin();
		gp.getObject()[28].setWorldX(16*gp.getTileSize());
		gp.getObject()[28].setWorldY(4*gp.getTileSize());
		
		gp.getObject()[29] = new Object_Coin();
		gp.getObject()[29].setWorldX(26*gp.getTileSize());
		gp.getObject()[29].setWorldY(20*gp.getTileSize());
	
//		
		/*add coins in the lava map */
		gp.getObject()[30] = new Object_Coin();
		gp.getObject()[30].setWorldX(6*gp.getTileSize());
		gp.getObject()[30].setWorldY(10*gp.getTileSize());
	
		gp.getObject()[31] = new Object_Coin();
		gp.getObject()[31].setWorldX(12*gp.getTileSize());
		gp.getObject()[31].setWorldY(18*gp.getTileSize());
		
		gp.getObject()[32] = new Object_Coin();
		gp.getObject()[32].setWorldX(22*gp.getTileSize());
		gp.getObject()[32].setWorldY(13*gp.getTileSize());
		
		gp.getObject()[33] = new Object_Coin();
		gp.getObject()[33].setWorldX(25*gp.getTileSize());
		gp.getObject()[33].setWorldY(29*gp.getTileSize());
	
		gp.getObject()[34] = new Object_Coin();
		gp.getObject()[34].setWorldX(7*gp.getTileSize());
		gp.getObject()[34].setWorldY(26*gp.getTileSize());
		
		gp.getObject()[35] = new Object_Coin();
		gp.getObject()[35].setWorldX(16*gp.getTileSize());
		gp.getObject()[35].setWorldY(11*gp.getTileSize());
		
		gp.getObject()[36] = new Object_Coin();
		gp.getObject()[36].setWorldX(18*gp.getTileSize());
		gp.getObject()[36].setWorldY(22*gp.getTileSize());
		

	}
}
