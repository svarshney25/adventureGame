package adventureGame;
import java.awt.Dimension;

import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import BeachBoss.BeachBossFrame;
import pong.PingPongFrame;
import pongTundra.PingPongFrameTundra;
import tictactoe.TileMain;
import Entity.Player;
import FinalBoss.FinalBossFrame;
import JungleBoss.JungleBossFrame;
import TundraBoss.TundraBossFrame;
import beachImageFinder.BeachImageFinder;
import boulderGame.RockFrame;
import brickBreaker.BrickBreakerMain;
import brickBreakerLava.LavaBrickBreakerMain;
import chest.ChestFrame;
import guessNumber.GuessNumberFrame;
import guessNumberHard.HardGuessNumberFrame;
import hole.HoleFrame;
import imageFinder.ImageFinder;
import object.SuperObject;
import tile.TileManager;
import tileClickBeach.ClickFrame;
import platformer.Platformer;
import platformerHard.PlatformerHard;

import java.awt.Color;
/** description of GamePanel
 * 
 * organizes the majority of the game functions, components, and displays
 * includes many important variables and values that are accessed across most classes
 * implements all mini-games and mini-bosses 
 * implements checkers, setters, and other functional classes
 * 
 * @authors Shivani Chhaya, Shivika Varshney
 */
public class GamePanel extends JPanel implements Runnable{

		/** screen preset fields
		 * ogTileSize- original size of tiles, scaled by 2 to be 64 (tileSize)
		 * maxScreenCol, maxScreenRow- the maximum amount of columns and rows in each map
		 * screenWidth, screenHeight- the width and height of the gameplay window
		 */
		// screen presets and sizing
		private int ogTileSize = 32; // 32 x 32 tile
		private int scale = 2;
		private int tileSize = ogTileSize * scale; // 64 x 64 tile
		private int maxScreenCol = 14;
		private int maxScreenRow = 12;
		private int screenWidth = tileSize * maxScreenCol; // 896 pixels 
		private int screenHeight = tileSize * maxScreenRow; // 768 pixels
		
		
		/** world bounds fields
		 * lastWorldCol, lastWorldRow- biggest amount of columns and rows
		 * worldWidth, worldHeight- pixel size of map width and height
		 */
		// world bounds
		private int lastWorldCol = 64;
		private int lastWorldRow = 64;
		private int worldWidth = tileSize * lastWorldRow;
		private int worldHeight = tileSize * lastWorldCol;
		
		/** game mode fields
		 * playMode- game can be played
		 * pauseMode- game can not be played
		 */
		private int gameMode;
		private int playMode = 1;
		private int pauseMode = 2;
		
		/** game boolean fields
		 * set to false
		 * when true, their corresponding frames are set visible and can be played
		 */
		
		private boolean pong = false;
		private boolean toe = false;
		private boolean boulder = false;
		private boolean chest = false;
		private boolean platformer = false;
		private boolean hole = false;
		private boolean brick = false;
		private boolean hardPong = false;
		private boolean hardGuess = false;
		private boolean ezGuess = false;
		private boolean clicker = false;
		private boolean hardPlatformer = false;
		private boolean finder = false;
		private boolean lavaBrick = false;
		private boolean beachFinder = false;
		private boolean jungleFight = false;
		private boolean beachFight = false;
		private boolean tundraFight = false;
		private boolean finalFight = false;
		
		/**keeps track of coins*/
		private int coins;
		
		/**keeps track of playerHealth */
		private int playerHealth;
		
		/** 
		 * 60 frames per second in thread
		 */
		private int FPS = 60;
		
		/** functional fields
		 * tileM- creates the map
		 * keyH- takes player key inputs
		 * gameThread- game timer
		 * checker- checks collisions between player, tiles, and objects
		 * aSetter- list of assets stores and used in GamePanel
		 * adMain- implements CardLayout and has "start" and "shop" buttons to toggle game screen
		 */
		private TileManager tileM = new TileManager(this);
		private KeyHandler keyH = new KeyHandler(this);
		private Thread gameThread;
		private CollisionChecker checker = new CollisionChecker(this);
		private AssetSetter aSetter = new AssetSetter(this);
		private AdventureMain adMain;
		
		/** mini-game frame fields
		 * creates all mini-game frames that are used in game
		 */
		private PingPongFrame pongFrame;
		private TileMain toeFrame = new TileMain();
		private ChestFrame chestFrame = new ChestFrame();
		private Platformer platformerFrame = new Platformer();
		private HoleFrame holeFrame = new HoleFrame();
		private BrickBreakerMain brickBreaker = new BrickBreakerMain();
		private PingPongFrameTundra tundraPong = new PingPongFrameTundra();
		private HardGuessNumberFrame hardGuessNum = new HardGuessNumberFrame();
		private GuessNumberFrame guessNum = new GuessNumberFrame();
		private ClickFrame clickFrame = new ClickFrame();
		private PlatformerHard hardPlatformerFrame = new PlatformerHard();
		private ImageFinder imageFinder = new ImageFinder();
		private LavaBrickBreakerMain lavaBrickBreaker = new LavaBrickBreakerMain();
		private BeachImageFinder beachFinderFrame = new BeachImageFinder();
		private RockFrame boulderFrame = new RockFrame();
		private JungleBossFrame jungleBoss = new JungleBossFrame();
		private BeachBossFrame beachBoss = new BeachBossFrame();
		private TundraBossFrame tundraBoss = new TundraBossFrame();
		private FinalBossFrame finalBoss = new FinalBossFrame();
		
		/** things drawn on map
		 * player- player added with keyhandler to be navigated on map
		 * object[]- list of objects that are placed around the map
		 */
		private Player player = new Player(this, keyH);
		private SuperObject object[] = new SuperObject[50];
		
		/** weapon fields
		 * includes integer values of damage and protection of different tools
		 */
		private int axeDamage;
		private int swordDamage;
		private int shooterDamage;
		private int ammoDamage;
		private int shieldProtection;
		private int energyProtection;
		

		/** upgrade button fields
		 * creates "upgrade" buttons for all purchaseable weapons
		 */
		private JButton upgradeAxe = new JButton("Upgrade");
		private JButton upgradeSword = new JButton("Upgrade");
		private JButton upgradeShooter = new JButton("Upgrade");
		private JButton upgradeAmmo = new JButton("Upgrade");
		private JButton upgradeShield = new JButton("Upgrade");
		private JButton upgradeEnergy = new JButton("Upgrade");	
		
		/** 
		 * map- the current map the player is on
		 */
		private int map;
		
		/** description of GamePanel()
		 * sets default values of a JPanel
		 * including:
		 * bounds
		 * mini-game visibility
		 * player stats
		 * coins
		 * map
		 * 
		 */
		public GamePanel()
		{
//			new AdventureMain(this);
			this.setPreferredSize(new Dimension(screenWidth, screenHeight));
			this.setBackground(Color.white);
			this.setDoubleBuffered(true);
			this.addKeyListener(keyH);
			this.setFocusable(true);
			pongFrame = new PingPongFrame();
			pongFrame.setVisible(false);
			toeFrame.setVisible(false);
			chestFrame.setVisible(false);
			holeFrame.setVisible(false);
			platformerFrame.setVisible(false);
			brickBreaker.setVisible(false);
			tundraPong.setVisible(false);
			hardGuessNum.setVisible(false);
			guessNum.setVisible(false);
			clickFrame.setVisible(false);
			hardPlatformerFrame.setVisible(false);
			imageFinder.setVisible(false);
			lavaBrickBreaker.setVisible(false);
			beachFinderFrame.setVisible(false);
			boulderFrame.setVisible(false);
			jungleBoss.setVisible(false);
			beachBoss.setVisible(false);
			tundraBoss.setVisible(false);
			finalBoss.setVisible(false);
			
			coins = 0;
			playerHealth = 20;
			
		}
		
		
		
		/** description of startGameThread()
		 * this creates a Thread, which was used instead of a timer for this code
		 * the Thread runs multiple tasks at once and helps with the timing and updating of the system
		 */
		public void startGameThread()
		{
			gameThread = new Thread(this);
			gameThread.start();
		}

		/** description of run()
		 * this sets up a system that is similar to a timer. 
		 * an interval is created that determines how often the images update
		 * update() is run when an interval is passed
		 * method by RyiSnow
		 */
		@Override
		public void run() 
		{
			
			double drawInterval = 1000000000/FPS;
			double delta = 0;
			long lastTime = System.nanoTime();
			long currentTime;
			while(gameThread != null)
			{			
				currentTime = System.nanoTime();
				
				delta += (currentTime-lastTime) / drawInterval;
				
				lastTime  = currentTime;
				
				if(delta >= 1)
				{
					update();
					repaint();
					delta--;
				}
				// 1 UPDATE: update information such as character position
				// 2 DRAW: draw the screen with the updated information
			}
		}
		/** description of update()
		 * updates the player information
		 */
		public void update()
		{
			tileM.loadMap();
			map = tileM.getMap();
			if(gameMode == pauseMode)
			{
				keyH.setDownPressed(false);
				keyH.setUpPressed(false);
				keyH.setLeftPressed(false);
				keyH.setRightPressed(false);
			}
			setMiniGame();
			/*add coins if jungle pong is won*/
			if(pongFrame.isGameWon()) {
				setCoins(10);
				pongFrame.setGameWon(false);
				System.out.println(getCoins() + " coins after pong win");
			}
			/*add coins if tundra pong is won*/
			if(tundraPong.isGameWon()) {
				setCoins(15);
				tundraPong.setGameWon(false);
				System.out.println(getCoins() + " coins after pong win");
			}
			
			/*add coins if beach guess number is won*/
			if(guessNum.isGameWon()) {
				setCoins(10);
				guessNum.setGameWon(false);
				System.out.println(getCoins() + " coins after guess number win");
			}
			
			/*add coins if tundra guess number is won*/
			if(hardGuessNum.isGameWon()) {
				setCoins(15);
				hardGuessNum.setGameWon(false);
				System.out.println(getCoins() + " coins after guess number win");
			}
			
			/*add coins if beach platformer is won*/
			if(platformerFrame.isGameWon()) {
				setCoins(10);
				platformerFrame.setGameWon(false);
				System.out.println(getCoins() + " coins after platformer win");
			}
			
			/*add coins if lava platformer is won*/
			if(hardPlatformerFrame.isGameWon()) {
				setCoins(10);
				hardPlatformerFrame.setGameWon(false);
				System.out.println(getCoins() + " coins after platformer win");
			}
			
			/*add coins if hole game is won in jungle*/
			if(holeFrame.isGameBeat()) {
				setCoins(5);
				holeFrame.setGameBeat(false);
				System.out.println(getCoins() + " coins after hole game win");
			}
			/*add coins if click game is won in beach*/
			if(clickFrame.isGameBeat()) {
				setCoins(5);
				clickFrame.setGameBeat(false);
				System.out.println(getCoins() + " coins after clicker win");
			}
			
			/*add coins if button finder is won in lava*/
			if(imageFinder.isGameWon()) {
				setCoins(15);
				imageFinder.setGameWon(false);
				System.out.println(getCoins() + " coins after button finder win");
			}
			
			/*add coins if button finder is won in beach*/
			if(beachFinderFrame.isGameWon()) {
				setCoins(10);
				beachFinderFrame.setGameWon(false);
				System.out.println(getCoins() + " coins after button finder win");
			}
			
			/*add coins if chest game is won in jungle*/
			if(chestFrame.isGameWon()) {
				setCoins(5);
				chestFrame.setGameWon(false);
				System.out.println(getCoins() + " coins after chest game win");
			}
			
			/*add coins if boulder game is wone*/
			if(boulderFrame.isGameWon()) {
				setCoins(5);
				boulderFrame.setGameWon(false);
				System.out.println(getCoins() + " coins after boulder game win");
			}
			
//			//add coins if tic tac toe is won anywhere
//			if(toeFrame.isGameWon()) {
//				setCoins(5);
//				toeFrame.setGameWon(false);
//				System.out.println(getCoins() + " coins after clicker win");
//			}
			
//			if(brickBreaker.isGameWon()) {
//				setCoins(6);
//				brickBreaker.setGameWon(false);
//				System.out.println(getCoins() + " after brickbreaker");
//			}
			
			player.update();
									
		}
		
		/** description of setUpGame()
		 * creates set of objects to be added around map
		 * sets gameMode to playMode
		 */
		
		public void setUpGame()
		{
			aSetter.setObject();
			gameMode = playMode;
			
		}
		
		/** description of setMiniGame()
		 * opens mini-games under certain conditions:
		 *  
		 */
		public void setMiniGame()
		{
			//SET PONG
			if(pongFrame.isPlayAgainClicked())
			{
				pongFrame.dispose();
				pongFrame = new PingPongFrame();
				
			}
			if(!pongFrame.isVisible() && pong)
			{
				pong = false;
//				pongFrame = new PingPongFrame();
				pongFrame.setVisible(true);
				
			}
			else
			{
				pong = false;
				gameMode = playMode;
			}
			//SET TIC TAC TOE
			if(!toeFrame.isVisible() && toe)
			{
				toe = false;
				toeFrame.setVisible(true);
			}
			else
			{
				toe = false;
				gameMode = playMode;
			}
			//SET BOULDER GAME
			if(!boulderFrame.isVisible() && boulder)
			{
				boulder = false;
				boulderFrame = new RockFrame();
			}
			else
			{
				boulder = false;
				gameMode = playMode;
			}
			
			//SET CHEST GAME
			if(!chestFrame.isVisible() && chest)
			{
				chest = false;
				chestFrame = new ChestFrame();
				chestFrame.setVisible(true);
			}
			else
			{
				chest = false;
				gameMode = playMode;
			}
			
			//SET HOLE GAME
			if(!holeFrame.isVisible() && hole)
			{
				hole = false;
				holeFrame = new HoleFrame();
			}
			else
			{
				hole = false;
				gameMode = playMode;
			}
			
			//SET BRICKBREAKER 
			if(!brickBreaker.isVisible() && brick)
			{
				brick = false;
//				brickBreaker = new BrickBreakerMain();
				brickBreaker.setVisible(true);
			}
			else
			{
				brick = false;
				gameMode = playMode;
			}
			
			//SET PONG FOR TUNDRA 
			if(!tundraPong.isVisible() && hardPong)
			{
				hardPong = false;
				tundraPong.setVisible(true);
			}
			else
			{
				hardPong = false;
				gameMode = playMode;
			}
			
			//SET GUESS NUMBER FOR TUNDRA 
			if(!hardGuessNum.isVisible() && hardGuess)
			{
				hardGuess = false;
				hardGuessNum.setVisible(true);
			}
			else
			{
				hardGuess = false;
				gameMode = playMode;
			}
			
			//SET GUESS NUMBER FOR BEACH 
			if(!guessNum.isVisible() && ezGuess)
			{
				ezGuess = false;
				guessNum.setVisible(true);
			}
			else
			{
				ezGuess = false;
				gameMode = playMode;
			}
			//SET PLATFORMER FOR BEACH 
			if(!platformerFrame.isVisible() && platformer)
			{
				platformer = false;
				platformerFrame.setVisible(true);
			}
			else
			{
				platformer = false;
				gameMode = playMode;
			}
			//SET CLICK GAME FOR BEACH 
			if(!clickFrame.isVisible() && clicker)
			{
				clicker = false;
				clickFrame.setVisible(true);
			}
			else
			{
				clicker = false;
				gameMode = playMode;
			}
			
			//SET PLATFORMER GAME FOR LAVA 
			if(!hardPlatformerFrame.isVisible() && hardPlatformer)
			{
				hardPlatformer = false;
				hardPlatformerFrame.setVisible(true);
			}
			else
			{
				hardPlatformer = false;
				gameMode = playMode;
			}
			
			//SET BUTTON FINDER GAME FOR LAVA
			if(!imageFinder.isVisible() && finder)
			{
				finder = false;
				imageFinder.setVisible(true);
			}
			else
			{
				finder = false;
				gameMode = playMode;
			}
			
			//SET BRICKBREAKER FOR LAVA
			if(!lavaBrickBreaker.isVisible() && lavaBrick)
			{
				lavaBrick = false;
				lavaBrickBreaker.setVisible(true);
			}
			else
			{
				lavaBrick = false;
				gameMode = playMode;
			}
			
			//SET BUTTON FINDER GAME FOR BEACH
			if(!beachFinderFrame.isVisible() && beachFinder)
			{
				beachFinder = false;
				beachFinderFrame.setVisible(true);
			}
			else
			{
				beachFinder = false;
				gameMode = playMode;
			}
			//SET JUNGLE MINI BOSS
			if(!jungleBoss.isVisible() && jungleFight)
			{
				jungleFight = false;
				jungleBoss.setVisible(true);
				gameMode = pauseMode;
			}
			if(jungleBoss.isMoveOnClicked())
			{
				jungleFight = false;
				jungleBoss.setMoveOnClicked(false);
				gameMode = playMode;
				
				player.setMapX(getTileSize()*31);
				player.setMapY(getTileSize()*57);
				tileM.setMap(2);
				
			}
			
			//SET BEACH MINI BOSS
			if(!beachBoss.isVisible() && beachFight)
			{
				beachFight = false;
				beachBoss.setVisible(true);
				gameMode = pauseMode;
			}
			if(beachBoss.isMoveOnClicked())
			{
				beachFight = false;
				beachBoss.setMoveOnClicked(false);
				gameMode = playMode;
				
				player.setMapX(getTileSize()* 18);
				player.setMapY(getTileSize()*29);
				tileM.setMap(3);
			}
			
			//SET TUNDRA MINI BOSS
			if(!tundraBoss.isVisible() && tundraFight)
			{
				tundraFight = false;
				tundraBoss.setVisible(true);
				gameMode = pauseMode;
			}
			if(tundraBoss.isMoveOnClicked())
			{
				tundraFight = false;
				tundraBoss.setMoveOnClicked(false);
				gameMode = playMode;
				
				player.setMapX(getTileSize()* 18);
				player.setMapY(getTileSize()*29);
				tileM.setMap(4);
			}
			
			//SET FINAL  BOSS
			if(!finalBoss.isVisible() && finalFight)
			{
				finalFight = false;
				finalBoss.setVisible(true);
				gameMode = pauseMode;
			}
		}
		
		
		/** description of paintComponent(Graphics g)
		 * calls superclass and draws the player on top of the game tiles
		 * 
		 */
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			
			Graphics2D g2 = (Graphics2D)g;
			
			//draw tiles
			
			tileM.draw(g2);
			
			//draw object
			/*remove the hole in jungle map if the minigame is beat*/
			if(holeFrame.isGameBeat())
			{
				object[1] = null;
				
			}

			
			/*remove the boulder in jungle map if the minigame is beat*/
			if(boulderFrame.isGameWon()) {
				object[0] = null;
			}

			
			for(int i = 0; i < object.length; i++)
			{
				if(object[i] != null)
				{
					if(i<14 && tileM.getMap() == 1)
					{
						object[i].draw(g2, this);
					} 
					if(i > 13 && i < 23 && tileM.getMap() == 2) {
						object[i].draw(g2, this);
					} 
					if(i > 22 && i < 29 && tileM.getMap() == 3) {
						object[i].draw(g2, this);
					}
					if(i > 28 && i < 36 && tileM.getMap() == 4) {
						object[i].draw(g2, this);
					}
					
					/*adjusting the coin value once the player collides with objects in the middle of the path*/
					if(checker.isCoinPickedUp()) {
						if(object[i].getName().equals("Coin")) {
							coins++;
							System.out.println(coins + " coins");
							checker.setCoinPickedUp(false);
						}
					}
					
				}
			}
			//draw player
			player.draw(g2);
			
			g2.dispose();
		}
		
		
		public int getHealth() {
			return playerHealth;
		}
		public void setHealth(int health) {
			playerHealth += health;
		}
		
		/** description of buyAxe()
		 * ensures player can afford an axe
		 *
		 * @return
		 * true if player has at least 5 coins
		 */
		public boolean buyAxe() {
			if(coins >= 5) {
				return true;
			} 
			return false;

		}
		
		/** description of buySword()
		 * ensures player can afford a sword
		 *
		 * @return
		 * true if player has at least 10 coins
		 */
		public boolean buySword() {
			if(coins >= 10) {
				return true;
			}
			return false;
		}
		
		/** description of buyShooter()
		 * ensures player can afford a shooter
		 *
		 * @return
		 * true if player has at least 15 coins
		 */
		public boolean buyShooter() {
			if(coins >= 15) {
				return true;
			}
			return false;
		}
		
		/** description of buyAmmo()
		 * ensures player can afford ammo
		 *
		 * @return
		 * true if player has at least 20 coins
		 */
		
		public boolean buyAmmo() {
			if(coins >= 20) {
				return true;
			}
			return false;
		}
		
		/** description of buyShield()
		 * ensures player can afford a shield
		 *
		 * @return
		 * true if player has at least 10 coins
		 */
		public boolean buyShield() {
			if(coins >= 10) {
				return true;
			}
			return false;
		}
		
		/** description of buyEnergy()
		 * ensures player can afford energy
		 *
		 * @return
		 * true if player has at least 5 coins
		 */
		public boolean buyEnergy() {
			if(coins >= 5) {
				return true;
			}
			return false;
		}

		//returns the axe damage value
		public int getAxeDamage() {
			return axeDamage;
		}

		//sets the axe damage by adding 5 and subtracts the money value 
		/** description of setAxeDamage()
		 * updates the axe damage
		 * updates the coin amount
		 */
		public void setAxeDamage() {
			axeDamage += 5;
			coins -= 5;
		}

		public int getSwordDamage() {
			return swordDamage;
		}

		/** description of setSwordDamage()
		 * updates the sword damage
		 * updates the coin amount
		 */
		public void setSwordDamage() {
			swordDamage += 10;
			coins -= 10;
		}

		public int getShooterDamage() {
			return shooterDamage;
		}

		/** description of setShooterDamage()
		 * updates the shooter damage
		 * updates the coin amount
		 */
		public void setShooterDamage() {
			shooterDamage += 15;
			coins -= 15;
		}

		public int getAmmoDamage() {
			return ammoDamage;
		}
		/** description of setAmmoDamage()
		 * updates the ammo damage
		 * updates the coin amount
		 */

		public void setAmmoDamage() {
			ammoDamage += 5;
			coins -= 20;
		}

		public int getShieldProtection() {
			return shieldProtection;
		}

		/** description of setShieldDamage()
		 * updates the axe damage
		 * updates the coin amount
		 */
		public void setShieldProtection() {
			shieldProtection += 10;
			coins -= 10;
			playerHealth += 10;
		}

		public int getEnergyProtection() {
			return energyProtection;
		}

		/** description of setEnergyProtection()
		 * updates the energy protection
		 * updates the coin amount
		 * updates the health 
		 */
		public void setEnergyProtection() {
			energyProtection += 5;
			coins -= 5;
			playerHealth += 5;
		}

		public int getPlayerHealth() {
			return playerHealth;
		}
		
		public void setPlayerHealth(int health) {
			playerHealth = health;
		}
		
		public int getCoins() {
			return coins;
		}
		
		/** description of setCoins()
		 * updates the coin amount
		 * @param coins
		 * the amount of coins incrementing
		 */
		public void setCoins(int coins) {
			this.coins += coins;
		}
		
		public int getMap() {
			return map;
		}
		public void setMap(int map) {
			this.map = map;
		}
		
		//showing the buttons on shop
		/** description of showAxeButton()
		 * adds the axe upgrade button
		 */
		public JButton showAxeButton() {
			upgradeAxe.setBounds(100,310,100,35);
			this.add(upgradeAxe);
			return upgradeAxe;
		}
		
		/** description of showSwordButton()
		 * adds the sword upgrade button
		 */
		public JButton showSwordButton() {
			upgradeSword.setBounds(400,310,100,35);
			this.add(upgradeSword);
			return upgradeSword;
			
		}
		
		/** description of showShooterButton()
		 * adds the shooter upgrade button
		 */
		public JButton showShooterButton() {
			upgradeShooter.setBounds(710,310,100,35);
			this.add(upgradeShooter);
			return upgradeShooter;
		}
		
		/** description of showAmmoButton()
		 * adds the ammo upgrade button
		 */
		public JButton showAmmoButton() {
			upgradeAmmo.setBounds(100,607,100,35);
			this.add(upgradeAmmo);
			return upgradeAmmo;
		}
		
		/** description of showShieldButton()
		 * adds the shield upgrade button
		 */
		public JButton showShieldButton() {
			upgradeShield.setBounds(400,607,100,35);
			this.add(upgradeShield);
			return upgradeShield;
		}
		
		/** description of showEnergyButton()
		 * adds the energy upgrade button
		 */
		public JButton showEnergyButton() {
			upgradeEnergy.setBounds(720,607,100,35);
			this.add(upgradeEnergy);
			return upgradeEnergy;
		}
		
		
		
		//make button accessible in the main method
		public JButton upgradeAxe() {
			return upgradeAxe;
		}
		
		public JButton upgradeSword() {
			return upgradeSword;
		}
		
		public JButton upgradeShooter() {
			return upgradeShooter;
		}
		
		public JButton upgradeAmmo() {
			return upgradeAmmo;
		}
		
		public JButton upgradeShield() {
			return upgradeShield;
		}
		
		public JButton upgradeEnergy() {
			return upgradeEnergy;
		}

		
		public int getTileSize()
		{
			return tileSize;
		}
		
		public void setTileSize(int x)
		{
			tileSize = x;
		}
		public int getMaxScreenCol()
		{
			return maxScreenCol;
		}
		
		public void setMaxScreenCol(int x)
		{
			maxScreenCol = x;
		}
		public int getMaxScreenRow()
		{
			return maxScreenRow;
		}
		
		public void setMaxScreenRow(int x)
		{
			maxScreenRow = x;
		}
		public int getScreenWidth()
		{
			return screenWidth;
		}
		
		public void setScreenWidth(int x)
		{
			screenWidth = x;
		}
		public int getScreenHeight()
		{
			return screenHeight;
		}
		
		public void setScreenHeight(int x)
		{
			screenHeight = x;
		}
		public int getLastWorldCol()
		{
			return lastWorldCol;
		}
		
		public void setLastWorldCol(int x)
		{
			lastWorldCol = x;
		}
		public int getLastWorldRow()
		{
			return lastWorldRow;
		}
		
		public void setLastWorldRow(int x)
		{
			lastWorldRow = x;
		}
		public int getWorldWidth()
		{
			return worldWidth;
		}
		
		public void setWorldWidth(int x)
		{
			worldWidth = x;
		}
		public int getWorldHeight()
		{
			return worldHeight;
		}
		
		public void setWorldHeight(int x)
		{
			worldHeight = x;
		}
		
		public Player getPlayer()
		{
			return player;
		}
		
		public void setPlayer(Player x)
		{
			player = x;
		}
		
		public TileManager getTileManager()
		{
			return tileM;
		}

		/**
		 * @return the checker
		 */
		public CollisionChecker getChecker() {
			return checker;
		}

		/**
		 * @param checker the checker to set
		 */
		public void setChecker(CollisionChecker checker) {
			this.checker = checker;
		}


		/**
		 * @return the pong
		 */
		public boolean isPong() {
			return pong;
		}


		/**
		 * @param pong the pong to set
		 */
		public void setPong(boolean pong) {
			this.pong = pong;
		}
		
		public PingPongFrame getPongFrame()
		{
			return pongFrame;
		}
		
		public void setPongFrame(PingPongFrame frame)
		{
			pongFrame = frame;
		}


		/**
		 * @return the gameMode
		 */
		public int getGameMode() {
			return gameMode;
		}


		/**
		 * @param gameMode the gameMode to set
		 */
		public void setGameMode(int gameMode) {
			this.gameMode = gameMode;
		}


		/**
		 * @return the playMode
		 */
		public int getPlayMode() {
			return playMode;
		}


		/**
		 * @param playMode the playMode to set
		 */
		public void setPlayMode(int playMode) {
			this.playMode = playMode;
		}


		/**
		 * @return the pauseMode
		 */
		public int getPauseMode() {
			return pauseMode;
		}


		/**
		 * @param pauseMode the pauseMode to set
		 */
		public void setPauseMode(int pauseMode) {
			this.pauseMode = pauseMode;
		}


		/**
		 * @return the object
		 */
		public SuperObject[] getObject() {
			return object;
		}

		/**
		 * @param object the object to set
		 */
		public void setObject(SuperObject object[]) {
			this.object = object;
		}


		/**
		 * @return the toe
		 */
		public boolean isToe() {
			return toe;
		}

		/**
		 * @param toe the toe to set
		 */
		public void setToe(boolean toe) {
			this.toe = toe;
		}

		/**
		 * @return the boulder
		 */
		public boolean isBoulder() {
			return boulder;
		}
		/**
		 * @param boulder the boulder to set
		 */
		public void setBoulder(boolean boulder) {
			this.boulder = boulder;
		}
		/**
		 * @return the boulder
		 */
		public boolean isChest() {
			return chest;
		}

		/**
		 * @param boulder the boulder to set
		 */
		public void setChest(boolean chest) {
			this.chest = chest;
		}
		/**
		 * @return the hole
		 */
		public boolean isHole() {
			return hole;
		}

		/**
		 * @param hole the hole to set
		 */
		public void setHole(boolean hole) {
			this.hole = hole;
		}
		
	
		
		
		/*
		 * setting up button finder in beach
		 */
		public BeachImageFinder getBeachFinder()
		{
			return beachFinderFrame;
		}
		
		public void setBeachFinderFrame(BeachImageFinder frame)
		{
			beachFinderFrame = frame;
		}
		
		public void setBeachFinder(boolean find) {
			beachFinder = find;
		}
		
		public boolean isBeachFinder() {
			return beachFinder;
		}
		/*
		 * setting up lava brick breaker
		 */
		public LavaBrickBreakerMain getLavaBrick()
		{
			return lavaBrickBreaker;
		}
		
		public void setLavaBrickFrame(LavaBrickBreakerMain frame)
		{
			lavaBrickBreaker = frame;
		}
		
		public void setLavaBrick(boolean find) {
			lavaBrick = find;
		}
		
		public boolean isLavaBrick() {
			return lavaBrick;
		}
		
		/*
		 * setting up image finder for lava
		 */
		
		public ImageFinder getImageFinder()
		{
			return imageFinder;
		}
		
		public void setFinderFrame(ImageFinder frame)
		{
			imageFinder = frame;
		}
		
		public void setFinder(boolean find) {
			finder = find;
		}
		
		public boolean isFinder() {
			return finder;
		}
		
		/*
		 * setting up brickbreaker 
		 */
		
		public BrickBreakerMain getBrickFrame()
		{
			return brickBreaker;
		}
		
		public void setBrickFrame(BrickBreakerMain frame)
		{
			brickBreaker = frame;
		}
		
		public void setBrick(boolean brick) {
			this.brick = brick;
		}
		
		public boolean isBrick() {
			return brick;
		}
		
		/**setting pong for tundra*/
		public PingPongFrameTundra getTundraPong()
		{
			return tundraPong;
		}
		
		public void setTundraPong(PingPongFrameTundra frame)
		{
			tundraPong = frame;
		}
		
		public void setHardPong(boolean pong) {
			hardPong = pong;
		}
		
		public boolean isHardPong() {
			return hardPong;
		}

		/**setting hard guess number for tundra*/
		public HardGuessNumberFrame getHardGuess()
		{
			return hardGuessNum;
		}
		
		public void setHardGuess(HardGuessNumberFrame frame)
		{
			hardGuessNum = frame;
		}
		
		public void setHard(boolean guess) {
			hardGuess = guess;
		}
		
		public boolean isHardGuess() {
			return hardGuess;
		}
		
		/**setting guess number for beach*/
		public GuessNumberFrame getEasyGuess()
		{
			return guessNum;
		}
		
		public void setHardGuess(GuessNumberFrame frame)
		{
			guessNum = frame;
		}
		
		public void setEasy(boolean guess) {
			ezGuess = guess;
		}
		
		public boolean isEasyGuess() {
			return ezGuess;
		}
		
		/**setting platformer in beach*/
		public Platformer getPlatformerFrame()
		{
			return platformerFrame;
		}
		
		public void setPlatformerFrame(Platformer frame)
		{
			platformerFrame = frame;
		}
		
		public void setPlatformer(boolean guess) {
			platformer = guess;
		}
		
		public boolean isPlatformer() {
			return platformer;
		}
		
		/**setting clicker game in the beach*/
		public ClickFrame getClicker()
		{
			return clickFrame;
		}
		
		public void setClickerFrame(ClickFrame frame)
		{
			clickFrame = frame;
		}
		
		public void setClicker(boolean guess) {
			clicker = guess;
		}
		
		public boolean isClicker() {
			return clicker;
		}
		
		/**setting the platformer game in lava*/
		public PlatformerHard getHardPlatformer()
		{
			return hardPlatformerFrame;
		}
		
		public void setHardPlatformer(PlatformerHard frame)
		{
			hardPlatformerFrame = frame;
		}
		
		public void setHardP(boolean guess) {
			hardPlatformer = guess;
		}
		
		public boolean isHardPlatformer() {
			return hardPlatformer;
		}
		
		public int getScale()
		{
			return scale;
		}
		
		public void setScale(int scale)
		{
			this.scale = scale;
		}
		/**
		 * @return the beachFight
		 */
		public boolean isBeachFight() {
			return beachFight;
		}
		public void setBeachFight(boolean beachFight) {
			this.beachFight = beachFight;
		}


		/**
		 * @param beachFight the beachFight to set
		 */
		
		
		public boolean isJungleFight() {
			return jungleFight;
		}



		public void setJungleFight(boolean jungleFight) {
			this.jungleFight = jungleFight;
		}



		public JungleBossFrame getJungleBoss() {
			return jungleBoss;
		}



		public void setJungleBoss(JungleBossFrame jungleBoss) {
			this.jungleBoss = jungleBoss;
		}
		
		/**
		 * @param tundraFight 
		 */
		public boolean isTundraFight() {
			return tundraFight;
		}
		public void setTundraFight(boolean tundraFight) {
			this.tundraFight = tundraFight;
		}

		/**
		 * @return the finalFight
		 */
		public boolean isFinalFight() {
			return finalFight;
		}
		public void setFinalFight(boolean beachFight) {
			this.finalFight = beachFight;
		}

}
