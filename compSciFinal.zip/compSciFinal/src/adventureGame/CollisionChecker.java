package adventureGame;

import Entity.Entity;

/** description of CollisionChecker
* 
* checks player collisions with objects and tiles on the map
* triggers mini-games and bosses when collision is detected
* allows for the picking up of coins 
* 
* @authors Shivani Chhaya, Shivika Varshney
*/

public class CollisionChecker
{
	/** field
	 * gp used to get player
	 */
	private GamePanel gp;
	/**checks if player picked up coin*/
	private boolean coinPickedUp;
	
	/** description of CollisionChecker(GamePanel gp)
	 * sets this private gp to the argument
	 * @param gp
	 * set equal to the field 
	 */
		public CollisionChecker(GamePanel gp)
	{
		this.gp = gp;
		coinPickedUp = false;
	}
	
	/** description of checkTile(Entity player)
	 * retrieves information about the player's position 
	 * checks if a player is colliding with a tile on the map
	 * triggers mini-games/bosses/interactions
	 * @param player
	 */
	
	
	public void checkTile(Entity player)
	{
		int playerLeftX = player.getMapX() + 15;
		int playerRightX = player.getMapX() + 8 + 32;
		int playerTopY = player.getMapY() + 32;
		int playerBottomY = player.getMapY() + 16 + 50;
		
		int playerLeftNum = playerLeftX/gp.getTileSize();
		int playerRightNum = playerRightX/gp.getTileSize();
		int playerTopNum = playerTopY/gp.getTileSize();
		int playerBottomNum = playerBottomY/gp.getTileSize();
		
		int tile1, tile2;
		
		switch(player.getDirection())
		{
		case "up":
			playerTopNum = (playerTopY - player.getSpeed())/gp.getTileSize();
			tile1 = gp.getTileManager().getMapTileNum()[playerLeftNum][playerTopNum];
			tile2 = gp.getTileManager().getMapTileNum()[playerRightNum][playerTopNum];
			//collision when moving up, watermelon boy triggers tic tac toe
			
			
			if(tile1 == 19 || tile2 == 19)
			{
				player.setCollisionOn(true);
				gp.setToe(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapY(player.getMapY() + (player.getSpeed() + 1));
			}
			
			if(tile1 == 20 || tile2 == 20)
			{
				player.setCollisionOn(true);
				gp.setChest(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapY(player.getMapY() + (player.getSpeed() + 1));
			}
			
			//collide with beanie in tundra 
			if(tile1 == 77 || tile2 == 77)
			{
				player.setCollisionOn(true);
				gp.setHard(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapY(player.getMapY() + (player.getSpeed() + 1));
			}
			
			//collide with beach ball in beach 
			if(tile1 == 84 || tile2 == 84)
			{
				player.setCollisionOn(true);
				gp.setToe(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapY(player.getMapY() + (player.getSpeed() + 1));
			}
			
			//collide with splat in lava
			if(tile1 == 99 || tile2 == 99)
			{
				player.setCollisionOn(true);
				gp.setFinder(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapY(player.getMapY() + (player.getSpeed() + 1));
			}
			if(tile1 == 56 || tile2 == 56)
			{
				player.setCollisionOn(true);
//				gp.getPlayer().setMapX(gp.getTileSize()*31);
//				gp.getPlayer().setMapY(gp.getTileSize()*57);
//				gp.getTileManager().setMap(2);
				
				gp.setJungleFight(true);
				player.setMapY(player.getMapY() + (player.getSpeed() + 1));
				
//				if(gp.getJungleBoss().isMoveOnClicked())
//				{
//					gp.getPlayer().setMapX(gp.getTileSize()*31);
//					gp.getPlayer().setMapY(gp.getTileSize()*57);
//					gp.getTileManager().setMap(2);
//				}
			}
			if(tile1 == 33 || tile2 == 33)
			{
				player.setCollisionOn(true);
				gp.setBeachFight(true);
				gp.setGameMode(gp.getPauseMode());
			}	
			
			if(tile1 == 67 || tile2 == 67)
			{
				player.setCollisionOn(true);
				gp.setTundraFight(true);
				gp.setGameMode(gp.getPauseMode());
			}	
			
			if(tile1 == 108 || tile2 == 108)
			{
				player.setCollisionOn(true);
				gp.setFinalFight(true);
				gp.setGameMode(gp.getPauseMode());
			}
			if(gp.getTileManager().getTile()[tile1].isCollision() || gp.getTileManager().getTile()[tile2].isCollision())
			{
				player.setCollisionOn(true);
			}
			break;
		
			
		case "down":
			playerBottomNum = (playerBottomY + player.getSpeed())/gp.getTileSize();
			tile1 = gp.getTileManager().getMapTileNum()[playerLeftNum][playerBottomNum];
			tile2 = gp.getTileManager().getMapTileNum()[playerRightNum][playerBottomNum];
			
//			if(tile1 == 20 || tile2 == 20)
//			{
//				player.setCollisionOn(true);
//				gp.setChest(true);
//				gp.setGameMode(gp.getPauseMode());
//				player.setMapY(player.getMapY() + (player.getSpeed() + 1));
//			}
			
			if(tile1 == 45 || tile2 == 45)
			{
				player.setCollisionOn(true);
				gp.setChest(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapY(player.getMapY() - (player.getSpeed() + 1));
			}
			
			//collide with the beanie in tundra
			if(tile1 == 77 || tile2 == 77)
			{
				player.setCollisionOn(true);
				gp.setHard(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapY(player.getMapY() - (player.getSpeed() + 1));
			}
			
			//collide with the beach girl and fish in beach
			if(tile1 == 48 || tile2 == 48 || tile1 == 49 || tile2 == 49)
			{
				player.setCollisionOn(true);
				gp.setClicker(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapY(player.getMapY() - (player.getSpeed() + 1));
			}
			
			//collide with the lava smoke cloud 
			if(tile1 == 98 || tile2 == 98)
			{
				player.setCollisionOn(true);
				gp.setToe(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapY(player.getMapY() - (player.getSpeed() + 1));
			}
			
			if(gp.getTileManager().getTile()[tile1].isCollision() || gp.getTileManager().getTile()[tile2].isCollision())
			{
				player.setCollisionOn(true);
			}
			
			break;
		case "left":
			playerLeftNum = (playerLeftX - player.getSpeed())/gp.getTileSize();
			tile1 = gp.getTileManager().getMapTileNum()[playerLeftNum][playerTopNum];
			tile2 = gp.getTileManager().getMapTileNum()[playerLeftNum][playerBottomNum];
			
			if(tile1 == 47 || tile2 == 47)
			{
				player.setCollisionOn(true);
				gp.setChest(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapY(player.getMapY() - (player.getSpeed() + 1));
			}
			
			//collide with socks in tundra 
			if(tile1 == 79 || tile2 == 79)
			{
				player.setCollisionOn(true);
				gp.setHardPong(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapY(player.getMapY() - (player.getSpeed() + 1));
			}
			
			//collide with mistletoe in tundra 
			if(tile1 == 80 || tile2 == 80)
			{
				player.setCollisionOn(true);
				gp.setToe(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapY(player.getMapY() - (player.getSpeed() + 1));
			}
			
			//collision with the surfboard and umbrella in beach 
			if(tile1 == 83 || tile2 == 83 || tile1 == 44 || tile2 == 44)
			{
				player.setCollisionOn(true);
				gp.setPlatformer(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapX(player.getMapX() - (player.getSpeed() + 1));
			}
			
			//collision with the lava boy in lava 
			if(tile1 == 95 || tile2 == 95 )
			{
				player.setCollisionOn(true);
				gp.setClicker(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapX(player.getMapX() - (player.getSpeed() + 1));
			}
			
			//collision with the lava girl in lava
			if(tile1 == 96 || tile2 == 96 )
			{
				player.setCollisionOn(true);
				gp.setLavaBrick(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapX(player.getMapX() - (player.getSpeed() + 1));
			}
			
			if(gp.getTileManager().getTile()[tile1].isCollision() || gp.getTileManager().getTile()[tile2].isCollision())
			{
				player.setCollisionOn(true);
			}
			
			break;
		case "right":
			playerRightNum = (playerRightX + player.getSpeed())/gp.getTileSize();
			tile1 = gp.getTileManager().getMapTileNum()[playerRightNum][playerTopNum];
			tile2 = gp.getTileManager().getMapTileNum()[playerRightNum][playerBottomNum];
			
			//collision when moving right, bear triggers pong game
			if(tile1 == 18 || tile2 == 18)
			{
				player.setCollisionOn(true);
				gp.setPong(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapX(player.getMapX() - (player.getSpeed() + 1));
			}
			//collide with the beanie in tundra
			if(tile1 == 77 || tile2 == 77)
			{
				player.setCollisionOn(true);
				gp.setHard(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapY(player.getMapY() - (player.getSpeed() + 1));
			}
			
			//collision with the hot chocolate in tundra 
			if(tile1 == 78 || tile2 == 78)
			{
				player.setCollisionOn(true);
				gp.setBrick(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapX(player.getMapX() - (player.getSpeed() + 1));
			}
			
			//collision with the socks in tundra 
			if(tile1 == 79 || tile2 == 79)
			{
				player.setCollisionOn(true);
				gp.setHardPong(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapX(player.getMapX() - (player.getSpeed() + 1));
			}
			
			//collision with the mistletoe in tundra 
			if(tile1 == 80 || tile2 == 80)
			{
				player.setCollisionOn(true);
				gp.setToe(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapX(player.getMapX() - (player.getSpeed() + 1));
			}
			
			//collision with the surfboard in beach 
			if(tile1 == 81 || tile2 == 81)
			{
				player.setCollisionOn(true);
				gp.setEasy(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapX(player.getMapX() - (player.getSpeed() + 1));
			}
			
			//collision with the  umbrella in beach 
			if(tile1 == 82 || tile2 == 82)
			{
				player.setCollisionOn(true);
				gp.setBeachFinder(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapX(player.getMapX() - (player.getSpeed() + 1));
			}
			
			//collision with the fireball in lava 
			if(tile1 == 89 || tile2 == 89)
			{
				player.setCollisionOn(true);
				gp.setHardP(true);
				gp.setGameMode(gp.getPauseMode());
				player.setMapX(player.getMapX() - (player.getSpeed() + 1));
			}
			
			if(gp.getTileManager().getTile()[tile1].isCollision() || gp.getTileManager().getTile()[tile2].isCollision())
			{
				player.setCollisionOn(true);
			}
			break;
		}
		
//		if(gp.getTileManager().getMapTileNum()[((playerRightX + player.getSpeed())/gp.getTileSize())][playerTopNum] == 18 
//		&& gp.getTileManager().getMapTileNum()[((playerRightX + player.getSpeed())/gp.getTileSize())][playerBottomNum] == 18 && player.isCollisionOn())
//		{
//			gp.setPong(true);
//		}
		
	}
	
	/** description of checkObject(Entity entity, boolean player)
	 * retrieves information about the player and the objects
	 * checks if the player collides with an object 
	 * triggers minigames/bosses/interactions
	 * 
	 * @param entity
	 * what type of entity is colliding
	 * @param player
	 * if the player exists
	 * @return
	 */
	public int checkObject(Entity entity, boolean player)
	{
		int index = 999;
		setCoinPickedUp(false);

//		gp.setBoulder(true);
		
		for(int i = 0; i < gp.getObject().length; i++)
		{
			if(gp.getObject()[i] != null)
			{
				entity.getSolidArea().x = entity.getMapX() + entity.getSolidArea().x;
				entity.getSolidArea().y = entity.getMapY() + entity.getSolidArea().y;
				
				gp.getObject()[i].getSolidArea().x = gp.getObject()[i].getWorldX() + gp.getObject()[i].getSolidArea().x;
				gp.getObject()[i].getSolidArea().y = gp.getObject()[i].getWorldY() + gp.getObject()[i].getSolidArea().y;
				
				switch(entity.getDirection())
				{
				case "up":
					entity.getSolidArea().y -= entity.getSpeed();
					if(entity.getSolidArea().intersects(gp.getObject()[i].getSolidArea()))
					{
						if(gp.getObject()[i].isCollision() == true)
						{
							entity.setCollisionOn(true);
						}
						if(player == true)
						{
							if(gp.getObject()[i].getName().equals("Boulder"))
							{
						
								index = i;

							}
							else if(gp.getObject()[i].getName().equals("Hole"))
							{
								
								index = i;
							}
							else if(gp.getObject()[i].getName().equals("Coin"))
							{
								index = i;
								setCoinPickedUp(true);
							}
						}
					}
					break;
				case "down":
					entity.getSolidArea().y += entity.getSpeed();
					if(entity.getSolidArea().intersects(gp.getObject()[i].getSolidArea()))
					{
						if(gp.getObject()[i].isCollision() == true)
						{
							entity.setCollisionOn(true);
						}
						if(player == true)
						{
							if(gp.getObject()[i].getName().equals("Boulder"))
							{
								
								index = i;

							}
							else if(gp.getObject()[i].getName().equals("Hole"))
							{
								gp.setHole(true);
								gp.setGameMode(gp.getPauseMode());
								entity.setMapY(entity.getMapY()-1);
								index = i;
							}
							else if(gp.getObject()[i].getName().equals("Coin"))
							{
								index = i;
								setCoinPickedUp(true);
							}
						}
					}
					break;
				case "left":
					entity.getSolidArea().x -= entity.getSpeed();
					if(entity.getSolidArea().intersects(gp.getObject()[i].getSolidArea()))
					{
						if(gp.getObject()[i].isCollision() == true)
						{
							entity.setCollisionOn(true);
						}
						if(player == true)
						{
							if(gp.getObject()[i].getName().equals("Boulder"))
							{
								gp.setBoulder(true);
								gp.setGameMode(gp.getPauseMode());
								entity.setMapY(entity.getMapY()-1);
								index = i;


//								entity.setMapX(entity.getMapX()+(entity.getSpeed()+1));
							}
							else if(gp.getObject()[i].getName().equals("Hole"))
							{
								
								index = i;
							}
							else if(gp.getObject()[i].getName().equals("Coin"))
							{
								index = i;
								
								
							}
						}
					}
					break;
				case "right":
					entity.getSolidArea().x += entity.getSpeed();
					if(entity.getSolidArea().intersects(gp.getObject()[i].getSolidArea()))
					{
						if(gp.getObject()[i].isCollision() == true)
						{
							entity.setCollisionOn(true);
						}
						if(player == true)
						{
							if(gp.getObject()[i].getName().equals("Boulder"))
							{
								gp.setBoulder(true);
								gp.setGameMode(gp.getPauseMode());
								entity.setMapY(entity.getMapY()-1);
								index = i;

							}
							else if(gp.getObject()[i].getName().equals("Hole"))
							{	
//								gp.setHole(true);
//								gp.setGameMode(gp.getPauseMode());
//								entity.setMapY(entity.getMapY()-1);
								index = i;
							}
							else if(gp.getObject()[i].getName().equals("Coin"))
							{
								index = i;
								setCoinPickedUp(true);
							}}
					}
					break;
				}
				
				entity.getSolidArea().x = entity.getSolidAreaDefaultX();
				entity.getSolidArea().y = entity.getSolidAreaDefaultY();
				
				gp.getObject()[i].getSolidArea().x = gp.getObject()[i].getSolidAreaDefaultX();
				gp.getObject()[i].getSolidArea().y = gp.getObject()[i].getSolidAreaDefaultY();
			}
			
		}
		return index;
	}

	public boolean isCoinPickedUp() {
		return coinPickedUp;
	}

	public void setCoinPickedUp(boolean coinPickedUp) {
		this.coinPickedUp = coinPickedUp;
	}
}
