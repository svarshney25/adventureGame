package adventureGame;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

import Entity.Player;
import pong.Updatable;

/**
 * Creates the starting and shop screens for the player to play the game.
 * This class is where the gamepanel is created and allows the user to play the game
 * @author Shivika Varshney
 */
public class AdventureMain extends JFrame implements ActionListener, Updatable {
		
		/**creates a brand new pane that allows any instances to be stores*/
		Container pane;
		/**creates a new Jpanel to allow buttons to be stored*/
		private JPanel panel;
		/**jpanel for the shop page*/
		private JPanel j;
		/**the start button to begin playing the game*/
		private JButton start;
		/**the shop button opens up the shop*/
		private JButton shop;
		/**creates a new gamepanel*/
		private GamePanel gamePanel;
		/**creates a new keyhandler*/
		private KeyHandler keyH;
		/**displays amount of coins left in shop*/
		private JLabel coinsLeft;
		/**tells whether player has enough coins or not to buy powerups*/
		private JLabel enoughCoins;
		/**shows how much damage the axe can do*/
		private JLabel axeDamage;
		/**shows how much damage the sword can do*/
		private JLabel swordDamage;
		/**shows how much damage the shooter can do*/
		private JLabel shooterDamage;
		/**shows how much damage the ammo can do*/
		private JLabel ammoDamage;
		/**shows how much protection the shield can do*/
		private JLabel shieldProtection;
		/**shows how much protection the energy can do*/
		private JLabel energyProtection;
		/**shows how much health the player has*/
		private JLabel health;
	
		/**
		 * Constructs a brand new game by setting up the background image. 
		 * The two buttons added at the bottom, start and shop allow the user 
		 * to toggle back and forth between them to play the game and buy powerups.
		 * The game panel is created and the game begins as soon as start is clicked.
		 * The shop displays all 6 powerups the user can buy and shows the amount of
		 * damage/protection they have.
		 */
	public AdventureMain() {
		this.setLayout(new BorderLayout(10, 5));
		this.setBounds(50,50,896,768);
		this.setLocationRelativeTo(null);
		this.setTitle("Adventure Game");
		this.setResizable(false);
				
		ImagePanel background = new ImagePanel(new ImageIcon("src/screens/beginningScreen1.png").getImage());
		this.getContentPane().add(background);
//		this.pack();
		this.setVisible(true);
//		
		panel = new JPanel();
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 5));

				
		this.setFocusable(true);
//		
		start = new JButton("Start");
		panel.add(start);
		gamePanel = new GamePanel();
		
		//when start is clicked a new screen should pop up leading to level 1
		start.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				pane = getContentPane();
				pane.removeAll();
//				pack();
				/* sets up all the jungle levels and screen
				 * 
				 */
				pane.add(gamePanel);
				setLocationRelativeTo(null);
				gamePanel.setMap(1);
				pane.setSize(896, 768);

				pane.addKeyListener(keyH);
				gamePanel.requestFocus();//setFocusable(true);
				
				gamePanel.setUpGame();
				gamePanel.startGameThread();
				
				pane.validate();
				pane.repaint();

				//add the panel 
				panel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 5));
				pane.add(panel, BorderLayout.SOUTH);
				
				setVisible(true);
				
	}
//			
});
//		
		shop = new JButton("Shop");
		panel.add(shop);
//		
		shop.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					
					pane = new JFrame();
					pane = getContentPane();
					pane.removeAll();
					j = new JPanel();
					
					coinsLeft = new JLabel("Coins: " + gamePanel.getCoins());
					coinsLeft.setBounds(40,650,100,60);
					coinsLeft.setFont(new Font("Monospaced Plain", Font.PLAIN, 17));
					coinsLeft.setForeground(Color.BLACK);
					
					health = new JLabel("PLAYER HEALTH: " + gamePanel.getHealth());
					health.setBounds(350,0,200,60);
					health.setFont(new Font("Monospaced Plain", Font.PLAIN, 20));
					health.setForeground(Color.PINK);
					pane.add(health);
					
					coinsLeft.repaint();

					pane.add(coinsLeft);

					/**
					 * determines which upgrade buttons to show based on the map.
					 * some weapons are only accessible in some maps.
					 */
					if(gamePanel.getMap() == 1) {
						pane.add(gamePanel.showAxeButton());
						pane.add(gamePanel.showAmmoButton());
						pane.add(gamePanel.showEnergyButton());
					} else if(gamePanel.getMap() == 2) {
						pane.add(gamePanel.showAxeButton());
						pane.add(gamePanel.showSwordButton());
						pane.add(gamePanel.showAmmoButton());
						pane.add(gamePanel.showEnergyButton());
					} else if(gamePanel.getMap() == 3) {
						pane.add(gamePanel.showAxeButton());
						pane.add(gamePanel.showSwordButton());
						pane.add(gamePanel.showAmmoButton());
						pane.add(gamePanel.showEnergyButton());
						pane.add(gamePanel.showShieldButton());
					} else if(gamePanel.getMap() == 4) {
						pane.add(gamePanel.showAxeButton());
						pane.add(gamePanel.showSwordButton());
						pane.add(gamePanel.showAmmoButton());
						pane.add(gamePanel.showEnergyButton());
						pane.add(gamePanel.showShieldButton());
						pane.add(gamePanel.showShooterButton());
					}

					/** displays the damage/protection each powerup has 
					 * and sets their location, color, and font.
					 */
					enoughCoins = new JLabel("");
					enoughCoins.setBounds(130,650,190,60);
					enoughCoins.setFont(new Font("Monospaced Plain", Font.PLAIN, 17));
					enoughCoins.setForeground(Color.WHITE);
					pane.add(enoughCoins);
					
					
					axeDamage = new JLabel("Axe Damage: " + gamePanel.getAxeDamage());
					axeDamage.setBounds(300,630,150,60);
					axeDamage.setFont(new Font("Monospaced Plain", Font.PLAIN, 17));
					axeDamage.setForeground(Color.BLACK);
					pane.add(axeDamage);
					
					swordDamage = new JLabel("Sword Damage: " + gamePanel.getSwordDamage());
					swordDamage.setBounds(500,630,150,60);
					swordDamage.setFont(new Font("Monospaced Plain", Font.PLAIN, 17));
					swordDamage.setForeground(Color.YELLOW);
					pane.add(swordDamage);
					
					shooterDamage = new JLabel("Shooter Damage: " + gamePanel.getShooterDamage());
					shooterDamage.setBounds(700,630,200,60);
					shooterDamage.setFont(new Font("Monospaced Plain", Font.PLAIN, 17));
					shooterDamage.setForeground(Color.DARK_GRAY);
					pane.add(shooterDamage);
//					
					ammoDamage = new JLabel("Ammo Damage: " + gamePanel.getAmmoDamage());
					ammoDamage.setBounds(300,650,150,60);
					ammoDamage.setFont(new Font("Monospaced Plain", Font.PLAIN, 17));
					ammoDamage.setForeground(Color.ORANGE);
					pane.add(ammoDamage);
//					
					shieldProtection = new JLabel("Shield Protection: " + gamePanel.getShieldProtection());
					shieldProtection.setBounds(500,650,200,60);
					shieldProtection.setFont(new Font("Monospaced Plain", Font.PLAIN, 17));
					shieldProtection.setForeground(Color.BLUE);
					pane.add(shieldProtection);
					
					energyProtection = new JLabel("Energy: " + gamePanel.getEnergyProtection());
					energyProtection.setBounds(700,650,150,60);
					energyProtection.setFont(new Font("Monospaced Plain", Font.PLAIN, 17));
					energyProtection.setForeground(Color.GREEN);
					pane.add(energyProtection);
//					
					/**when each button is clicked, their respective labels update.
					 * If there are not enough coins, the enoughCoins JLabel will be 
					 * displayed.*/
					
					gamePanel.upgradeAxe().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							if(gamePanel.buyAxe()) {
								gamePanel.setAxeDamage();
								coinsLeft.setText("Coins: " + gamePanel.getCoins());
								enoughCoins.setText("");
								axeDamage.setText("Axe Damage: " + gamePanel.getAxeDamage());
							} else {
								enoughCoins.setText("Not enough coins!");
							}
						}
						
					});
					
					gamePanel.upgradeSword().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							if(gamePanel.buySword()) {
								gamePanel.setSwordDamage();
								coinsLeft.setText("Coins: " + gamePanel.getCoins());
								enoughCoins.setText("");
								swordDamage.setText("Sword Damage: " + gamePanel.getSwordDamage());
							} else {
								enoughCoins.setText("Not enough coins!");
							}
						}
						
						
					});
					
					gamePanel.upgradeShooter().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							if(gamePanel.buyShooter()) {
								gamePanel.setShooterDamage();
								coinsLeft.setText("Coins: " + gamePanel.getCoins());
								enoughCoins.setText("");
								shooterDamage.setText("Shooter Damage: " + gamePanel.getShooterDamage());
							} else {
								enoughCoins.setText("Not enough coins!");
							}
						}
						
						
					});
					
					gamePanel.upgradeAmmo().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							if(gamePanel.buyAmmo()) {
								gamePanel.setAmmoDamage();
								coinsLeft.setText("Coins: " + gamePanel.getCoins());
								enoughCoins.setText("");
								ammoDamage.setText("Ammo Damage: " + gamePanel.getAmmoDamage());
							} else {
								enoughCoins.setText("Not enough coins!");
							}
						}
						
						
					});
					
					
					gamePanel.upgradeShield().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							if(gamePanel.buyShield()) {
								gamePanel.setShieldProtection();
								coinsLeft.setText("Coins: " + gamePanel.getCoins());
								enoughCoins.setText("");
								shieldProtection.setText("Shield Protection: " + gamePanel.getShieldProtection());
							} else {
								enoughCoins.setText("Not enough coins!");
							}
						}
						
						
					});
					
					gamePanel.upgradeEnergy().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							if(gamePanel.buyEnergy()) {
								gamePanel.setEnergyProtection();
								gamePanel.setHealth(5);
								coinsLeft.setText("Coins: " + gamePanel.getCoins());
								enoughCoins.setText("");
								energyProtection.setText("Energy: " + gamePanel.getEnergyProtection());
								health.setText("PLAYER HEALTH: " + gamePanel.getHealth());
							} else {
								enoughCoins.setText("Not enough coins!");
							}
						}
						
						
					});
					
					System.out.println(gamePanel.getCoins() + " coins");

					
					ImagePanel background = new ImagePanel(new ImageIcon("src/screens/shop.png").getImage());
					pane.add(background);
					
					j.setSize(800, 500);
					
					
					pane.validate();
					pane.repaint();
					panel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 5));
					pane.add(panel, BorderLayout.SOUTH);	
					setVisible(true);
				}
						
		});
		
		
//
		
		this.add(panel, BorderLayout.SOUTH);		
		
		setVisible(true);
		
		
		this.setVisible(true); 
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("setting text");
		coinsLeft.setText("Coins: " + gamePanel.getCoins());
	
	}
	

	public static void main(String[] args) {
		new AdventureMain();
	}

	@Override
	public void update() {
	
	}
	
}


