package adventureGame;

public interface Updatable {
//	String update(String label);
}
