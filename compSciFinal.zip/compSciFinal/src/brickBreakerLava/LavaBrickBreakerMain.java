package brickBreakerLava;

import javax.swing.JFrame;

import brickBreakerLava.LavaBrickBreakerMain;
import brickBreakerLava.LavaGamePlay;
import brickBreakerLava.LavaMapGenerator;

/** Controls the creaton of the game's frame to appear in a GUI as well as closing 
 * the game once the game is won, recieving the proper rewards
 * 
 * @author Bella Acker
 * @author Britney Yang ( comments )
 *
 */
public class LavaBrickBreakerMain extends JFrame {

		/** Indicates whether or not the game is over, not really won*/
		private boolean gameWon = false;
		/** Contains the operation of the actual game*/
		private LavaGamePlay gamePlay;
		/** The number of coins recieved from the game*/
		private int coins = 0;
		
		public LavaBrickBreakerMain() {
			gamePlay = new LavaGamePlay();
			this.setBounds(10, 10, 700, 600);
			this.setTitle("Brick Breaker");
			this.setResizable(false);
			this.setLocationRelativeTo(null);
			this.add(gamePlay);
			
			gameWon = false;
//			coins = gamePlay.getScore();
			
			this.setVisible(true);
			this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		}
		
		public boolean isGameWon() {
			return gameWon;
		}
		public void setGameWon(boolean value) {
			gameWon = value;
		}
		
		/** adds the game to a main method to be run
		 * 
		 */
		public static void main(String[] args) {
			new LavaBrickBreakerMain();
		}
		
		public int getCoins() {
			return coins;
		}

	}
	