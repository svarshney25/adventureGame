package tictactoe;

/** description of Tiles
 * 
 * sets up the JPanel background that is to be used in the TileMain class
 * assigns BufferedImages to Icons
 * sets JLabel Icons to the BufferedImage icons
 * 
 * @author Britney Yang
 * 
 */
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Tiles extends JPanel
{
	//variables ( conditional )
	/** fields
	 * strawberryP- opponent turn
	 * endGame- stop program
	 * winner- true if player wins
	 */
	private boolean strawberryP; //strawberryP serves as the opponent's turn
	private boolean endGame;
	private boolean winner; //true will rep player win and false is opposite
	
	//panel assets
	/** panel fields
	 * creates a 2D Array for the board
	 * adds background Images and JLabels
	 */
	private int board[][]; // 2s will rep strawberry tiles while 1s will rep banana tiles
	private JLabel background;
	private JLabel restart;
	private Image table;
	private Image re;
	
	//strawberry
	/** strawberry fields
	 * creates new JLabels for each strawberry image
	 */
	private Image strawberryimg;
	private JLabel sR1C1;
	private JLabel sR1C2;
	private JLabel sR1C3;
	private JLabel sR2C1;
	private JLabel sR2C2;
	private JLabel sR2C3;
	private JLabel sR3C1;
	private JLabel sR3C2;
	private JLabel sR3C3;
	
	//banana
	/** banana fields
	 * creates new JLabels for each banana image
	 */
	private Image bananaimg;
	private JLabel bR1C1;
	private JLabel bR1C2;
	private JLabel bR1C3;
	private JLabel bR2C1;
	private JLabel bR2C2;
	private JLabel bR2C3;
	private JLabel bR3C1;
	private JLabel bR3C2;
	private JLabel bR3C3;

	/** description of Tiles()
	 * fills the 2D array with values to be used for gameplay
	 * adds images into their respective places
	 * sets images not visible
	 */
	public Tiles()
	{
		//conditionals
		strawberryP = false;
		endGame = false;
		
		//numbers
		board = new int[3][3];
		for ( int i = 0; i < 3; i++)
		{
			for ( int j = 0; j < 3; j++)
			{
				board[i][j] = 0;
			}
		}
		
		//images
		
		try
		{
			strawberryimg = ImageIO.read((getClass().getResourceAsStream("/tictactoeimages/strawberry tile.png")));
			bananaimg = ImageIO.read((getClass().getResourceAsStream("/tictactoeimages/banana tile.png")));
			table = ImageIO.read((getClass().getResourceAsStream("/tictactoeimages/table.png")));
			re = ImageIO.read((getClass().getResourceAsStream("/tictactoeimages/retry.png")));
		} 
		
		/** 
		 * @exception IOException
		 * error with image observer/filepath
		 */
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
		//tile pieces - strawberry
			//row 1
			sR1C1 = new JLabel();
			sR1C1.setBounds(165,27,300,300);
			sR1C1.setIcon(new ImageIcon(strawberryimg));
			sR1C1.setVisible(false);
	
			sR1C2 = new JLabel();
			sR1C2.setBounds(397,27,300,300);
			sR1C2.setIcon(new ImageIcon(strawberryimg));
			sR1C2.setVisible(false);
			
			sR1C3 = new JLabel();
			sR1C3.setBounds(625,27,300,300);
			sR1C3.setIcon(new ImageIcon(strawberryimg));
			sR1C3.setVisible(false);
			
			//row2
			sR2C1 = new JLabel();
			sR2C1.setBounds(165,205,300,300);
			sR2C1.setIcon(new ImageIcon(strawberryimg));
			sR2C1.setVisible(false);

			sR2C2 = new JLabel();
			sR2C2.setBounds(397,205,300,300);
			sR2C2.setIcon(new ImageIcon(strawberryimg));
			sR2C2.setVisible(false);
			
			sR2C3 = new JLabel();
			sR2C3.setBounds(625,205,300,300);
			sR2C3.setIcon(new ImageIcon(strawberryimg));
			sR2C3.setVisible(false);
		
			//row3
			sR3C1 = new JLabel();
			sR3C1.setBounds(165,400,300,300);
			sR3C1.setIcon(new ImageIcon(strawberryimg));
			sR3C1.setVisible(false);
	
			sR3C2 = new JLabel();
			sR3C2.setBounds(397,400,300,300);
			sR3C2.setIcon(new ImageIcon(strawberryimg));
			sR3C2.setVisible(false);
			
			sR3C3 = new JLabel();
			sR3C3.setBounds(625,400,300,300);
			sR3C3.setIcon(new ImageIcon(strawberryimg));
			sR3C3.setVisible(false);
		
		//tile pieces - banana
			//row 1
			bR1C1 = new JLabel();
			bR1C1.setBounds(165,27,300,300);
			bR1C1.setIcon(new ImageIcon(bananaimg));
			bR1C1.setVisible(false);
			
			bR1C2 = new JLabel();
			bR1C2.setBounds(397,27,300,300);
			bR1C2.setIcon(new ImageIcon(bananaimg));
			bR1C2.setVisible(false);
			
			bR1C3 = new JLabel();
			bR1C3.setBounds(625,27,300,300);
			bR1C3.setIcon(new ImageIcon(bananaimg));
			bR1C3.setVisible(false);
			
			//row 2
			bR2C1 = new JLabel();
			bR2C1.setBounds(165,205,300,300);
			bR2C1.setIcon(new ImageIcon(bananaimg));
			bR2C1.setVisible(false);
			
			bR2C2 = new JLabel();
			bR2C2.setBounds(397,205,300,300);
			bR2C2.setIcon(new ImageIcon(bananaimg));
			bR2C2.setVisible(false);
			
			bR2C3 = new JLabel();
			bR2C3.setBounds(625,205,300,300);
			bR2C3.setIcon(new ImageIcon(bananaimg));
			bR2C3.setVisible(false);
			
			//row 3
			bR3C1 = new JLabel();
			bR3C1.setBounds(165,400,300,300);
			bR3C1.setIcon(new ImageIcon(bananaimg));
			bR3C1.setVisible(false);
		
			bR3C2 = new JLabel();
			bR3C2.setBounds(397,400,300,300);
			bR3C2.setIcon(new ImageIcon(bananaimg));
			bR3C2.setVisible(false);
			
			bR3C3 = new JLabel();
			bR3C3.setBounds(625,400,300,300);
			bR3C3.setIcon(new ImageIcon(bananaimg));
			bR3C3.setVisible(false);
			
		//bg label :)
		background = new JLabel();
		background.setBounds(0,0,896,768 );
		background.setIcon(new ImageIcon(table));
		
		restart = new JLabel();
		restart.setBounds(0,0,896,768 );
		restart.setIcon(new ImageIcon(re));
		
	}
	
	//getters
	
	public boolean getTurn() // return true if opponent turn and false otherwise
	{
		return strawberryP;
	}
	
	public boolean getEndGame()
	{
		return endGame;
	}
	
	public int[][] getBoard() // int values on the board for individual pieces
	{
		return board;
	}
	
	public boolean getWinner() //true if player win
	{
		return winner;
	}
	
	public JLabel getBg()
	{
		return background;
	}
	
	//for adding tiles to the game :,)
	
	/** description of getSTile(int row, int col)
	 *gets the image of the location that was clicked
	 * @param row
	 * the row of the game board
	 * @param col
	 * the column of the game board
	 * @return
	 * the strawberry image at the spot on the board
	 */
	public JLabel getSTile( int row, int col)
	{
		if ( row == 0)
		{
			if ( col == 0)
			{
				return sR1C1;
			}
			else if ( col == 1)
			{
				return sR1C2;
			}
			else 
			{
				return sR1C3;
			}
		}
		else if ( row == 1)
		{
			if ( col == 0)
			{
				return sR2C1;
			}
			else if ( col == 1)
			{
				return sR2C2;

			}
			else 
			{
				return sR2C3;
			}
		}
		else
		{
			if ( col == 0)
			{
				return sR3C1;
			}
			else if ( col == 1)
			{
				return sR3C2;
			}
			else
			{
				return sR3C3;
			}
		}
	}
	
	/** description of getBTile(int row, int col)
	 *gets the image of the location that was clicked
	 * @param row
	 * the row of the game board
	 * @param col
	 * the column of the game board
	 * @return
	 * the banana image at the spot on the board
	 */	
	public JLabel getBTile( int row, int col)
	{
		if ( row == 0)
		{
			if ( col == 0)
			{
				return bR1C1;
			}
			else if ( col == 1)
			{
				return bR1C2;
			}
			else 
			{
				return bR1C3;
			}
		}
		else if ( row == 1)
		{
			if ( col == 0)
			{
				return bR2C1;
			}
			else if ( col == 1)
			{
				return bR2C2;

			}
			else 
			{
				return bR2C3;
			}
		}
		else
		{
			if ( col == 0)
			{
				return bR3C1;
			}
			else if ( col == 1)
			{
				return bR3C2;
			}
			else
			{
				return bR3C3;
			}
		}
	}
	
	public JLabel getRestart()
	{
		return restart;
	}
	//null will represent empty slots
	
	/** description of getTileAt(int row, int col)
	 * 
	 * @param row
	 * row of the game board
	 * @param col
	 * column of the gameboard
	 * @return
	 * get the image at the spot
	 */
	public int getTileAt( int row, int col)
	{
		return board[row][col];
	}
	
	//setters
	/** description of endTurn()
	 * checks if player won or not
	 * 
	 */
	public void endTurn()
	{
		if ( strawberryP == false )
		{
			strawberryP = true;
		}
		else if ( strawberryP == true)
		{
			strawberryP = false;
		}
	}
	
	public void setEndGame( boolean b)
	{
		endGame = b;
	}
	
	public void setBoard( int row, int col )
	{
			board[row][col] = 1;
	}
	/** description of setTile(int row, int col, boolean tile)
	 * 
	 * sets images of tiles visible if clicked on
	 * @param row
	 * row of the gameboard
	 * @param col
	 * column of the gameboard
	 * @param tile
	 * image on the board
	 */
	public void setTile( int row, int col, boolean tile) //placing tiles on the board by changing visibility
	{
		if ( tile == false)//banana tiles
		{
			if ( row == 0)
			{
				if ( col == 0)
				{
					bR1C1.setVisible(true);
				}
				else if ( col == 1)
				{
					bR1C2.setVisible(true);
				}
				else 
				{
					bR1C3.setVisible(true);
				}
			}
			else if ( row == 1)
			{
				if ( col == 0)
				{
					bR2C1.setVisible(true);
				}
				else if ( col == 1)
				{
					bR2C2.setVisible(true);

				}
				else 
				{
					bR2C3.setVisible(true);
				}
			}
			else
			{
				if ( col == 0)
				{
					bR3C1.setVisible(true);
				}
				else if ( col == 1)
				{
					bR3C2.setVisible(true);
				}
				else
				{
					bR3C3.setVisible(true);
				}
			}
		}
		else //strawberry tiles
		{

			if ( row == 0) 
			{
				if ( col == 0)
				{
					sR1C1.setVisible(true);
				}
				else if ( col == 1)
				{
					sR1C2.setVisible(true);
				}
				else 
				{
					sR1C3.setVisible(true);
				}
			}
			else if ( row == 1)
			{
				if ( col == 0)
				{
					sR2C1.setVisible(true);
				}
				else if ( col == 1)
				{
					sR2C2.setVisible(true);

				}
				else 
				{
					sR2C3.setVisible(true);
				}
			}
			else
			{
				if ( col == 0)
				{
					sR3C1.setVisible(true);
				}
				else if ( col == 1)
				{
					sR3C2.setVisible(true);
				}
				else
				{
					sR3C3.setVisible(true);
				}
			}
			}
	}
	
	/** description of checkWinner()
	 * checks what parts of the board are filled with what tiles
	 * determines winner if 3 in a row is detected
	 */
	public void checkWinner() 
	{
		//horizontal
			//first horizontal
			if ( board[0][0] == board[0][1] && board[0][1] == board[0][2] )
			{
				if ( board[0][0] == 1)
				{
					setEndGame( true );
				}
				else if ( board[0][0] == 2)
				{
					setEndGame( true );
					winner = false;
				}
			}
			//second horizontal
			else if ( board[1][0] == board[1][1] && board[1][1] == board[1][2] )
			{
				if ( board[1][0] == 1)
				{
					setEndGame( true );
					winner = true;
				}
				else if ( board[1][0] == 2)
				{
					setEndGame( true );
					winner = false;
				}
			}
			//third horizontal
			else if ( board[2][0] == board[2][1] && board[2][1] == board[2][2] )
			{
				if ( board[2][0] == 1)
				{
					setEndGame( true );
					winner = true;
				}
				else if ( board[2][0] == 2)
				{
					setEndGame( true );
					winner = false;
				}
			}
		//vertical
				//first vertical
			else if ( board[0][0] == board[1][0] && board[1][0] == board[2][0])
				{
					if ( board[0][0] == 1)
					{
						setEndGame( true );
						winner = true;
					}
					else if ( board[0][0] == 2)
					{
						setEndGame( true );
						winner = false;
					}
				}
				//second vertical
			else if ( board[0][1] == board[1][1] && board[1][1] == board[2][1])
				{
					if ( board[0][1] == 1)
					{
						setEndGame( true );
						winner = true;
					}
					else if ( board[0][0] == 2)
					{
						setEndGame( true );
						winner = false;
					}
				}
				//third vertical
			else if ( board[0][2] == board[1][2] && board[1][2] == board[2][2])
				{
					if ( board[0][2] == 1)
					{
						setEndGame( true );
						winner = true;
					}
					else if ( board[0][2] == 2)
					{
						setEndGame( true );
						winner = false;
					}
				}
		//diagonals
				//left to right
			else if ( board[0][0] == board[1][1] && board[2][2] == board[2][0])
				{
					if ( board[0][0] == 1)
					{
						setEndGame( true );
						winner = true;
					}
					else if ( board[0][0] == 2)
					{
						setEndGame( true );
						winner = false;
					}
				}
				//second vertical
			else if ( board[0][2] == board[1][1] && board[2][0] == board[2][1])
				{
					if ( board[0][2] == 1)
					{
						setEndGame( true );
						winner = true;
					}
					else if ( board[0][2] == 2)
					{
						setEndGame( true );
						winner = false;
					}
				}
	}
	//opponents turn will generate a random value until the tile is empty before "playing it's turn"
	public void opTurn ( )
	{
		if ( strawberryP = true)
		{
			boolean a = false;
			while ( a == false)
			{
				int oR = (int)(Math.random()*3);
				int oC = (int)(Math.random()*3);
				if( board[oR][oC] == 0 )
				{
					setTile( oR, oC, true);
					board[oR][oC] = 2;
					a = true;
				}
			}
		}
		
	}
	
	//restart for when the player loses
	/** description for reset()
	 * resets the gameboard when the player loses
	 */
	public void reset()
	{
		for(int i = 0; i < 3; i ++)
		{
			for (int j = 0; j < 3; j++)
			{
				restart.setVisible(false);
				board[i][j] = 0;
				getSTile(i,j).setVisible(false);
				getBTile(i,j).setVisible(false);
				strawberryP = false;
				endGame = false;
			}
		}
	}
	
}