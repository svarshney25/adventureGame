/** description of TileMain
 * 
 * adds the tile panel to a JFrame
 * uses a MouseListener to detect player clicks for gameplay
 * 
 * @author Britney Yang
 */


package tictactoe;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;

public class TileMain extends JFrame implements MouseListener
{
	/** description of TileMain()
	 * adds components and panel to a JFrame
	 * adds a MouseListener to detect where the user clicks
	 * gameplay things done here
	 */
		public TileMain()
		{
			//variables (board)
			Tiles game = new Tiles();
			
			//setting up the Frame
//			JFrame frame = new JFrame("Tiles");
			this.getContentPane();
			this.setBounds(0,0,896,768);
			this.setLocationRelativeTo(null);
			
			Tiles tPanel = new Tiles();
			this.add(tPanel);
			
			this.add(game);
			
			//tiles
			for ( int i = 0; i < 3; i ++)
			{
				for ( int j = 0; j < 3; j++)
				{
					this.add(game.getSTile(i, j));
					this.add(game.getBTile(i, j));
				}
			}
			
			//board
			this.add(game.getBg());
			
			this.setResizable(false);
			
			this.addMouseListener( new MouseListener() {
			public void mouseClicked(MouseEvent e)
			{
				// coordinates of click
				int x = 0;
				int y = 0;
				
				// row / column the mouse clicked
				int lR = -1;
				int lC = -1;
				
				//if the game is continuing
				if ( game.getEndGame() == false)
				{
					x = e.getX();
					y = e.getY();
					
					//bounds to determine the column the mouse clicked 
					if ( x> 165 && x < 390)
					{
						lC = 0;
					}
					else if ( x>397 && x<610)
					{
						lC = 1;
					}
					else if ( x > 625 && x < 910)
					{
						lC = 2;
					}
					
					if ( y > 27 && y < 327)
					{
						lR = 0;
					}
					else if ( y > 205 && y < 505)
					{
						lR = 1;
					}
					else if ( y > 400 && y < 700)
					{
						lR = 2;
					}
					
					//Player turn, then opponent turn
					if ( game.getTileAt(lR, lC) == 0 )
					{
						game.setBoard(lR, lC);
						game.setTile(lR,lC, false);
						game.endTurn();
						game.checkWinner();
						game.opTurn();
						game.endTurn();
						game.checkWinner();
					}
				}
				else if ( game.getEndGame() == true)
				{
					if ( game.getWinner() == false)
					{
						//reset label appears and player must restart
						add(game.getRestart());
						
						if( e.getX() > 0 && e.getX() < 896 && e.getY() > 0 && e.getY() < 768)
						{
							game.reset();
							remove(game.getRestart());
						}
					}
					else if (game.getWinner() == true)
					{
						//HERE SHIVIKA <333
						//window closes and returns back to the original game
						dispose();
					}
				}
			}
	
			//eclipse required me to add these in but i have no use for them so they sit here
			@Override
			public void mousePressed(MouseEvent e) 
			{
			
				
			}
	
			@Override
			public void mouseReleased(MouseEvent e) 
			{
				
				
			}
	
			@Override
			public void mouseEntered(MouseEvent e) 
			{
				
				
			}
	
			@Override
			public void mouseExited(MouseEvent e) 
			{
				
				
			}
			
		});
		
			this.setVisible(true);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE );
		
	}
	//eclipse required me to add these in but i have no use for them so they sit here (pt. 2)
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	/** description of main(String[] args)
	 * main class needed for testing
	 * @param args
	 */
	public static void main(String[] args)
	{
		new TileMain();
	}

}
