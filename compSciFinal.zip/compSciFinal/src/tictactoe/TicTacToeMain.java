package tictactoe;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;

public class TicTacToeMain extends JFrame implements MouseListener
{

	public static void main(String[] args) 
	{
		//variables (board)
		TicTacToe game = new TicTacToe();
		
		//setting up the Frame
		JFrame frame = new JFrame("Tiles");
		frame.getContentPane();
		frame.setBounds(0,0,896,768);
		
		TicTacToe tPanel = new TicTacToe();
		frame.add(tPanel);
		
		frame.add(game);
		
		//tiles
		for ( int i = 0; i < 3; i ++)
		{
			for ( int j = 0; j < 3; j++)
			{
				frame.add(game.getSTile(i, j));
				frame.add(game.getBTile(i, j));
			}
		}
		
		//board
		frame.add(game.getBg());
		
		frame.setVisible(true);
		frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		frame.setResizable(false);
		
	frame.addMouseListener( new MouseListener() {
		public void mouseClicked(MouseEvent e)
		{
			// coordinates of click
			int x = 0;
			int y = 0;
			
			// row / column the mouse clicked
			int lR = -1;
			int lC = -1;
			
			//if the game is continuing
			if ( game.getEndGame() == false)
			{
				x = e.getX();
				y = e.getY();
				
				//bounds to determine the column the mouse clicked 
				if ( x> 165 && x < 390)
				{
					lC = 0;
				}
				else if ( x>397 && x<610)
				{
					lC = 1;
				}
				else if ( x > 625 && x < 910)
				{
					lC = 2;
				}
				
				if ( y > 27 && y < 327)
				{
					lR = 0;
				}
				else if ( y > 205 && y < 505)
				{
					lR = 1;
				}
				else if ( y > 400 && y < 700)
				{
					lR = 2;
				}
				
				//Player turn, then opponent turn
				if ( game.getTileAt(lR, lC) == 0 )
				{
					game.setBoard(lR, lC);
					game.setTile(lR,lC, false);
					game.endTurn();
					game.checkWinner();
					game.opTurn();
					game.endTurn();
					game.checkWinner();
				}
			}
			else if ( game.getEndGame() == true)
			{
				if ( game.getWinner() == false)
				{
					//reset label appears and player must restart
					frame.add(game.getRestart());
					
					if( e.getX() > 0 && e.getX() < 896 && e.getY() > 0 && e.getY() < 768)
					{
						game.reset();
						frame.remove(game.getRestart());
					}
				}
				else if ( game.getWinner() == true)
				{
					//HERE SHIVIKA <333
					//window closes and returns back to the original game
				}
			}
		}

		//eclipse required me to add these in but i have no use for them so they sit here
		@Override
		public void mousePressed(MouseEvent e) 
		{
		
			
		}

		@Override
		public void mouseReleased(MouseEvent e) 
		{
			
			
		}

		@Override
		public void mouseEntered(MouseEvent e) 
		{
			
			
		}

		@Override
		public void mouseExited(MouseEvent e) 
		{
			
			
		}
		
	});
	
	
	}
	//eclipse required me to add these in but i have no use for them so they sit here (pt. 2)
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}