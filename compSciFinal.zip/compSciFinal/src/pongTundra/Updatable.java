package pongTundra;

/** ensures that all the classes have a described process of updating
 * @author Shivani Chhaya 
 * */
public interface Updatable {
	void update();

}
