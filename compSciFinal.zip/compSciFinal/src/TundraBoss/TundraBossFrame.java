package TundraBoss;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * creates the frame for the tundra boss
 * @author Shivani Chhaya
 * @author Shivika Varshney
 *
 */
public class TundraBossFrame extends JFrame implements ActionListener {
	/**variable to store tundra boss image*/
	private BufferedImage image;
	/**holds an icon image used as a background*/
	private JLabel background;
	/**move on button clicked, player can advance*/
	private boolean moveOn = false;
	/**move on button*/
	private JButton moveOnClicked = new JButton("Move on");
	
	
	/**creates the tundra boss frame*/
	public TundraBossFrame() {
		this.setBounds(10,50,896,768);
		this.setLocationRelativeTo(null);
		background = new JLabel();
		
		moveOnClicked.setBounds(100, 300, 100, 70);
		this.add(moveOnClicked);

		try {
			image = ImageIO.read(getClass().getResourceAsStream("/pngs/snowman2.png"));

		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		moveOnClicked.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				moveOn = true;
			}
		});

		background.setIcon(new ImageIcon(image));
		this.add(background);
		
		this.setVisible(true);

	}
	
	public static void main(String[] args) {
		new TundraBossFrame();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	/**
	 * @return the moveOnClicked
	 */
	public boolean isMoveOnClicked() {
		return moveOn;
	}


	/**
	 * @param moveOnClicked the moveOnClicked to set
	 */
	public void setMoveOnClicked(boolean moveOn) {
		this.moveOn = moveOn;
	}


}
