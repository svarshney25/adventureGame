package platformer;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import javax.swing.JComponent;

public class Ball extends JComponent {
	private Ellipse2D.Double ball;
	private int dx;
	private int dy;
	
	public Ball(int x, int y) {
		dx = 0;
		dy = 0;
		ball = new Ellipse2D.Double(0,0,15,15);
		this.setBounds(x,y,15,15);
		this.setFocusable(false);
	}
	
	
	public int getDx() {
		return dx;
	} 
	public int getDy() {
		return dy;
	}
	public void setDx(int dx) {
		this.dx = dx;
	}
	public void setDy(int dy) {
		this.dy = dy;
	}
	public void update() {
		this.setLocation(getX() + dx, getY() + dy);
	}
	
	public void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D) g; //guaranteed its a graphic2D object
		g2.draw(ball);
		
		g2.setColor(Color.MAGENTA); //blue and yellow are capitalized bc they're constants
		g2.fill(ball);
	}
	
}

