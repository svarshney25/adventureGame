package platformer;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;

import platformerHard.CoinsHard;
import platformerHard.ObstaclesHard;
import platformerHard.PlayerHard;
/*
 * This class creates the platformer minigame in the beach level. It is triggered when the player collides
 * with the surfboard
 * @author Shivika Varshney
 * @author Britney Yang ( comments line 28 and after)
 */
public class Platformer extends JFrame implements ActionListener  {
		/** timer for the duration of the game*/
		private Timer timer;
		/** player that will move aroud the screen*/
		private Player blue;
		/** ground of the platformer*/
		private JButton ground;
		/** player can jump*/
		private boolean blueJump;
		/** triggered with coins collected*/
		private JLabel blueText;
		/** welcome message*/
		private JLabel welcome;
		private int blueScore;
		/** first platform*/
		private Obstacles obstacle1;
		/** second platform*/
		private Obstacles obstacle2;
		/** third platform*/
		private Obstacles obstacle3;
		/** fourth platform*/
		private Obstacles obstacle4;
		/** first coin on platform*/
		private Coins coin1;
		/** second coin on platform*/
		private Coins coin2;
		/** third coin on platform*/
		private Coins coin3;
		/** fourth coin on platform*/
		private Coins coin4;
		/** fifth coin on platform*/
		private Coins coin5;
		/** true if game finished, false if not*/
		private boolean gameWon = false;
		
//		private Color ground = new Color(51, 76, 46);
		/** background color ofJFrame*/
		private Color background = new Color(66, 140, 189);
		/** ground color of platformer*/
		private Color groundColor = new Color(74, 185, 70);
		
		/** Assembles the frame of theplatformer, setting up text and platforms in 
		 * fixed positions along with coins. A welcome statement is created that 
		 * prompts the player to start moving using the WASD keys. Movement is 
		 * assigned to the WAD keys for the player to move around the map
		 * 
		 */
		public Platformer() {
			this.setBounds(100, 100, 700, 500);
			this.setLayout(null);
			this.setTitle("Platformer");
			this.getContentPane().setBackground(background);
			timer = new Timer(25, this);
			timer.start();
			
			blue = new Player(100, 408);
			this.add(blue);
			
			obstacle1 = new Obstacles(620, 390, 30, 60);
			this.add(obstacle1);
			
			obstacle2 = new Obstacles(450, 370, 30, 80);
			this.add(obstacle2);
			
			obstacle3 = new Obstacles(320, 410, 30, 40);
			this.add(obstacle3);
			
			obstacle4 = new Obstacles(150, 350, 100, 30);
			this.add(obstacle4);
			
			coin1 = new Coins(630, 375);
			coin1.setVisible(true);
			this.add(coin1);
			
			coin2 = new Coins(460, 355);
			coin2.setVisible(true);
			this.add(coin2);
			
			coin3 = new Coins(330, 395);
			coin3.setVisible(true);
			this.add(coin3);
			
			coin4 = new Coins(200, 335);
			coin4.setVisible(true);
			this.add(coin4);
			
			coin5 = new Coins(530, 305);
			coin5.setVisible(true);
			this.add(coin5);
			
			blueJump = true;
			
			welcome = new JLabel("Welcome! Click the WASD keys to move. Get all the coins from left to right!");
			welcome.setFont(new Font("Monospaced Plain", Font.PLAIN, 17));
			welcome.setForeground(Color.WHITE);
			welcome.setBounds(40,5,650,300);
			this.add(welcome);
			
			blueScore = 0;
			blueText = new JLabel("Coins: " + blueScore);
			blueText.setFont(new Font("Monospaced Plain", Font.PLAIN, 17));
			blueText.setForeground(Color.WHITE);
			blueText.setBounds(315,50,150,300);
			this.add(blueText);
			

			ground = new JButton();
			ground.setBounds(0,450, getWidth(), getHeight());
			ground.setBackground(groundColor);
			ground.setFocusable(false);
			
			this.add(ground);
			
			
			this.addKeyListener(new KeyListener() {
				/** player moves left when A is pressed, moves right when D is pressed, and jumps when W is pressed
				 * 
				 */
			public void keyPressed(KeyEvent e) {
				int code = e.getKeyCode();
			
				switch(code) {
				case KeyEvent.VK_A:
					blue.setLocation(blue.getX()-10, blue.getY());
					break;
				case KeyEvent.VK_D:
					blue.setLocation(blue.getX()+10, blue.getY());
					break;
				case KeyEvent.VK_W:
					if(blueJump && blue.getBounds().intersects(ground.getBounds())) {
						blue.setDy(blue.getDy() - 6);
					} 
					break;

				}
				}
			@Override
			public void keyTyped(KeyEvent e) {

			}

			@Override
			public void keyReleased(KeyEvent e) {
				
			}
			
		});
		
			this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			this.setVisible(true);
		}
		
		//if game is won update coins in gamepanel
		public boolean isGameWon() {
			return gameWon;
		}
		
		public void setGameWon(boolean game) {
			gameWon = game;
		}
		
		/** Checks when character runs/jumps into platforms to set the chracater into 
		 * the correct position. Also checks when the player runs into the coin to 
		 * update the coin count and display a message. A form of gravity is also 
		 * established, reseting the direction and velocity when the charcater touches 
		 * the ground or a platform of some kind.
		 * 
		 */
		@Override
		public void actionPerformed(ActionEvent e) {
			blue.update();
			
			if(blueScore == 5) {
				gameWon = true;
				blueScore = 0;
			}
			
			
			//rightmost obstacle
			if(blue.getBounds().intersects(obstacle1.getBounds())) {
				blue.setLocation(blue.getX(), obstacle1.getY() - blue.getHeight());
				blueJump = true;
			} 
			if(blue.getBounds().intersects(obstacle2.getBounds())) {
				blue.setLocation(blue.getX(), obstacle2.getY() - blue.getHeight());
				blueJump = true;
			}
			if(blue.getBounds().intersects(obstacle3.getBounds())) {
				blue.setLocation(blue.getX(), obstacle3.getY() - blue.getHeight());
				blueJump = true;
			}
			//leftmost obstacle
			if(blue.getBounds().intersects(obstacle4.getBounds())) {
				blue.setLocation(blue.getX(), obstacle4.getY() - blue.getHeight());
				blueJump = true;
			}
			
			if(blue.getBounds().intersects(coin1.getBounds())) {
				blueScore++;
				if(blueScore > 5) {
					blueScore = 5;
				}
				blueText.setText("Coins: " + blueScore);
				coin1.setVisible(false);
//				this.remove(coin1);
			}
			if(blue.getBounds().intersects(coin2.getBounds())) {
				blueScore++;
				if(blueScore > 3) {
					blueScore = 3;
				}
				blueText.setText("Coins: " + blueScore);
				coin2.setVisible(false);
//				this.remove(coin2);

			}
			
			if(blue.getBounds().intersects(coin3.getBounds())) {
				blueScore++;
				if(blueScore > 2) {
					blueScore = 2;
				}
				blueText.setText("Coins: " + blueScore);
				coin3.setVisible(false);
			}
			
			if(blue.getBounds().intersects(coin4.getBounds())) {
				blueScore++;
				if(blueScore > 1) {
					blueScore = 1;
				}
				blueText.setText("Coins: " + blueScore);
				coin4.setVisible(false);
			}
			
			if(blue.getBounds().intersects(coin5.getBounds())) {
				blueScore++;
				if(blueScore > 4) {
					blueScore = 4;
				}
				blueText.setText("Coins: " + blueScore);
				coin5.setVisible(false);
			}
			
			//blue should come down
			if(blue.getY() < 270) {
				
				blue.setDy(5);
				
			}

			if(blue.getBounds().intersects(ground.getBounds())) {
				blueJump = true;
				blue.setDy(0);
			}	
	

		}
		
		
		/** Resets the direction and velocity of the player as well as the coin count
		 * 
		 */
		public void reset()
		{
			blueScore = 0;
			blue.setDy(0);
		}
		
		/** Adds the game to the main to be run
		 * 
		 */
		public static void main(String[] args) {
			new Platformer();
		}
}



