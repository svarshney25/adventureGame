package platformer;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Ellipse2D;

import javax.swing.JComponent;


/**
* creates the character present in the frame
* @author Shivika Varshney
* @author Britney Yang ( comments )
*
*/
public class Player extends JComponent {
	/** ellispe of the head of the stick figure*/
	private Ellipse2D.Double head;
	/** rectangle for the body of the stick figure*/
    private Rectangle body;
    /** rectangle for left leg of the stick figure*/
    private Rectangle leftLeg;
    /** rectangle for the left arm of the stick figure*/
    private Rectangle leftArm;
    /** rectangle for the right leg of the stick figure*/
    private Rectangle rightLeg;
    /** rectangle for the right arm of the stick figure*/
    private Rectangle rightArm;
    /** number player has to guess */
    private int number;
    /** direction and velocity of the character horizontally*/
    private int dx;
    /** direction and velocity of the character vertically*/
    private int dy;
    
    /** constructs the person using shapes at the provided coordinate
     * 
     * @param x	The horizontal value where the person is created
     * @param y	The vertical value where the person is created
     */
  public Player(int x, int y)
    {
        dx = 0;
        dy = 0;
        head = new Ellipse2D.Double(7,0,11,11);
        body = new Rectangle(8,10,10,20);
        leftArm = new Rectangle(0,10,10,5);
        leftLeg = new Rectangle(7,30,5,15);
        rightLeg = new Rectangle(14,30,5,15);
        rightArm = new Rectangle(18,10,10,5);
        this.setBounds(x,y,25,45);
        
        this.setFocusable(false);
    }
  	public int bodyHeight() {
	  return 25;
    }
    public int getDx() {
		return dx;
	} 
	public int getDy() {
		return dy;
	}
	public void setDx(int dx) {
		this.dx = dx;
	}
	public void setDy(int dy) {
		this.dy = dy;
	}
	/** Updates the location of the person with the assigned velocities and current location
	 * 
	 */
	public void update() {
		this.setLocation(getX() + dx, getY() + dy);
	}
	/** Paints the person's shapes onto the screen so that the character is visible in the JFrame
	 * 
	 */
    public void paintComponent(Graphics g)
    {
        Graphics2D g2 = (Graphics2D) g;

        g2.setColor(Color.WHITE);
        g2.fill(head);
        g2.fill(body);
        g2.fill(leftArm);
        g2.fill(leftLeg);
        g2.fill(rightArm);
        g2.fill(rightLeg);
    }

}