package platformer;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import javax.swing.JComponent;

/** Creates the platforms the player must jump on
 * 
 * @author Shivika Varshney
 * @author Britney Yang
 *
 */
public class Obstacles extends JComponent {
	/** shaope for the platforms*/
	private Rectangle goal;
	/** platform color*/
	private Color background = new Color(250, 225, 5);
	
	/** creates the platform given appropriate measurements of size and location
	 * 
	 * @param x 	 The x location of the platform
	 * @param y		The y location of the platform
	 * @param width	The width of the platform
	 * @param height	The height of the platform
	 */
	public Obstacles(int x, int y, int width, int height) {
		goal = new Rectangle(0,0,width,height);
		this.setBounds(x,y,width+1,height+1);
	}
	
	/** Allows for the platform to be visible in the JFrame
	 * 
	 */
	@Override
	public void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;

        g2.setColor(background);
        g2.fill(goal);
	}
}