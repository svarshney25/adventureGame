package platformer;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Ellipse2D;

import javax.swing.JComponent;

/** Creates the coins that will appear
 * 
 * @author Shivika Varshney
 * @author Britney Yang ( comments )
 *
 */
public class Coins extends JComponent {
	/** the shape for the coins*/
	private Ellipse2D.Double coin;
	/** color of the coin*/
	private Color background = new Color(245, 117, 171);
	
	/**Creates a coin on a certain location of the frame
	 * 
	 * @param x		The x locaiton where the coin will be located
	 * @param y		The y location where the coin will be located
	 */
	public Coins(int x, int y) {
		coin = new Ellipse2D.Double(0,0,15,15);
		this.setBounds(x,y,16,16);
	}
	
	/** allows for the coin to be vsiisble on the JFrame*/
	@Override
	public void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.draw(coin);
		 
        g2.setColor(background);
        g2.fill(coin);
       
	}
}
