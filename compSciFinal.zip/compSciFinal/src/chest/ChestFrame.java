package chest;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;


import pong.Updatable;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

/** creates and assmebles the seperate methods into the main game
 * 
 * @author Shivani Chhaya
 * @author Britney Yang
 *
 */
public class ChestFrame extends JFrame implements ActionListener, MouseListener, MouseMotionListener, Updatable
{
	/** key hole for the game*/
	private KeyHole keyHole = new KeyHole();
	/** key for the game*/
	private Key key = new Key();
	
	/** timer for the progression of the mini game*/
	private Timer timer;
	/** color of the background*/
	private Color background = new Color(87, 67, 56);
	/** image for the keyhole*/
	private ImageIcon keyHolePic = new ImageIcon(keyHole.getKeyHoleImage());
	/** image for the key*/
	private ImageIcon keyPic = new ImageIcon(key.getKeyImagePic());
	/** button for the keyhole*/
	private JButton keyHoleButton = new JButton(keyHolePic);
	/** button for the key*/
	private JButton keyButton = new JButton(keyPic);
	/** number of keyhole clicks still needed to complete the game*/
	private  int numClicksLeft = 10;
	/** Label to display the number of clicks left*/
	private JLabel clicksLeft = new JLabel("Clicks left: " + numClicksLeft);
	/** x location of the cursor*/
	private int mouseX;
	/** y locaiton of the cursor*/
	private int mouseY;
	/** whether or not the keyhole has been clicked. True if clicked.*/
	private boolean holeClicked = false;
	/** informaton on how to play the game*/
	private JLabel info = new JLabel("You must click the keyhole 10 times to open the chest!");
	/** Label for the background image*/
	private JLabel bckgrd = new JLabel();
	/** button the end the game*/
	private JButton doneButton = new JButton("Okay, bye.");
	/** whether or not the game has been finished.True if ended.*/
	private boolean gameWon;

//	private JButton keyHoleButton = new JButton("hello");


	/** Adds all the appropriate text, labels and buttons into the game as well as the background. 
	 * Tapping of the key hole is also added, causing the number of clicks left to decrease and 
	 * moves the key hole to another random position
	 * 
	 */
	public ChestFrame()
	{
		this.setBounds(250,30,600,600);
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		this.setTitle("open chest");
		this.setResizable(false);
		
		timer = new Timer(15, this);
		timer.start();
		
		gameWon = false;
		
		doneButton.setBounds(198, 275, 200, 25);
		doneButton.setFont(new Font("Monospaced Plain", Font.PLAIN, 20));
		doneButton.setBackground(background);
		doneButton.setContentAreaFilled(false);
		doneButton.setForeground(Color.white);
		doneButton.setBorderPainted(false);
		doneButton.setFocusPainted(false);

		doneButton.setVisible(false);
		
		keyHoleButton.setOpaque(false);
		keyHoleButton.setContentAreaFilled(false);
		keyHoleButton.setBorderPainted(false);
		keyHoleButton.setFocusPainted(false);
		keyHoleButton.setBounds((int)(Math.random()*550),(int)(Math.random()*490 + 60),51,51);
		keyHoleButton.setVisible(true);
		
		keyButton.setOpaque(false);
		keyButton.setContentAreaFilled(false);
		keyButton.setBorderPainted(false);
		keyButton.setFocusPainted(false);
		
		clicksLeft.setBounds(50,50,100,100);
		clicksLeft.setForeground(Color.white);
		clicksLeft.setVisible(true);
		
		info.setBounds(20,25, 600, 100);
		info.setFont(new Font("Monospaced Plain", Font.PLAIN, 20));
		info.setForeground(Color.white);
		keyHoleButton.addActionListener(new ActionListener() { 
			
			  public void actionPerformed(ActionEvent e) { 
				  
//				  keyButton.setBounds((keyHoleButton.getX()+keyHoleButton.getWidth())/2, keyHoleButton.getY()+keyHoleButton.getHeight(), 20, 20);
				  holeClicked = true;
				  numClicksLeft--;
				  keyHoleButton.setBounds((int)(Math.random()*550),(int)(Math.random()*530),51,51);
				  holeClicked = false;
				  

			  } 
			} );
		addMouseListener(this);
		addMouseMotionListener(this);
		
		add(doneButton);
		add(info);
		add(clicksLeft);
		add(keyHoleButton);				
		add(keyButton);
		
		bckgrd.setIcon(new ImageIcon(keyHole.getBckgrd()));
		bckgrd.setBounds(0,0,600,600 );
		add(bckgrd);
		
		
		this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
		this.setVisible(true);
		
	}

	

	/** updates the JFrame
	 * 
	 */
	@Override
	public void actionPerformed(ActionEvent e)
	{
		update();
	}


	/**
	 * 
	 */
	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		mouseX = e.getX();
	    mouseY = e.getY();
	}




	@Override
	public void mouseMoved(MouseEvent e) {
		
		mouseX = e.getX();
		mouseY = e.getY();
		
	    
//		 mouseX = e.getX();
//	     mouseY = e.getY();
//	     key.repaint();
	}




	@Override
	public void mouseClicked(MouseEvent e) {
		
//		mouseX = e.getX();
//	    mouseY = e.getY();
	}




	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
		
	}




	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}




	/**
	 * @return the numClicks
	 */
	public int getNumClicksLeft() {
		return numClicksLeft;
	}




	/**
	 * @param numClicks the numClicks to set
	 */
	public void setNumClicksLeft(int numClicksLeft) {
		this.numClicksLeft = numClicksLeft;
	}

	/** updates the location of the key based on where the cursor is unless the key is within a 
	 * 5 pixels range of the keyhole. If near, then the key will be moved onto the keyhole, 
	 * allowing the player to click. Also checking if the player has reached the appropriate 
	 * numbers of clicks, which will cause the automatic exiting of the game once one more 
	 * interaction is performed
	 * 
	 */
	@Override
	public void update()
	{
		
		if((mouseX + keyButton.getWidth() > keyHoleButton.getX() - 5 && mouseX < keyHoleButton.getWidth() + 5))
		{
			if (mouseY + keyButton.getHeight() > keyHoleButton.getY() - 5 && mouseY < keyHoleButton.getHeight() + 5)
		{
			keyButton.setBounds((keyHoleButton.getX()+keyHoleButton.getWidth())/2, keyHoleButton.getY()+keyHoleButton.getHeight()+15, 20, 20);

		}
		}
		
		else
		{
			keyButton.setBounds(mouseX-13, mouseY-45, 20,20);
		}
		clicksLeft.setText("Clicks left: "  + Integer.toString(numClicksLeft));
		if(numClicksLeft == 0)
		{
			gameWon = true;
			numClicksLeft = 1;
			this.dispose();
			clicksLeft.setText("Clicks left: done!");
			info.setText("You've already opened this chest!");
			doneButton.setVisible(true);
			doneButton.addActionListener(new ActionListener() {
			
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					
				}
				});				
		}
	}
	/** adds the game to main so it can be run
	 * 
	 */
	public static void main(String[] args)
	{
		new ChestFrame();

	}

	public boolean isGameWon() {
		return gameWon;
	}
	public void setGameWon(boolean game) {
		gameWon = game;
	}

}

