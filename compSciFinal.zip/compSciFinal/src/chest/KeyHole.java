package chest;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JComponent;

/** creates the keyhole used in the game
 * 
 * @author Shivani Chhaya
 * @author Britney Yang
 */
public class KeyHole extends JComponent 
{
	/** the x locationof the keyhole*/
	private int keyHoleX;
	/** the y location of the keyhole*/
	private int keyHoleY;
	
	/** background image*/
	private BufferedImage bckgrd;
	/** keyhole image*/
	private BufferedImage keyHoleImage;
	
	/** assigns the background image and keyhole image to their correspondig buffered image fields
	 * 
	 */
	public KeyHole()
	{
		try 
		{
			keyHoleImage = ImageIO.read(getClass().getResourceAsStream("/pngs/keyHole.png"));
			setBckgrd(ImageIO.read(getClass().getResourceAsStream("/pngs/chest_bckg.png")));
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
				
		
	}
	
	/** allows the keyhole and its background to be visible in the JFrame
	 * 
	 */
	public void paintComponent(Graphics g)
	{
		Graphics2D g2 = (Graphics2D) g;
		
		
		g2.drawImage(keyHoleImage, keyHoleX, keyHoleY, 200, 200, null);

	}
	
	
	public BufferedImage getKeyHoleImage()
	{
		return keyHoleImage;
	}
	
	public void setKeyHoleImage(BufferedImage k)
	{
		this.keyHoleImage = k;
	}
	public int getKeyHoleX() {
		return keyHoleX;
	}
	public void setKeyHoleX(int keyHoleX) {
		this.keyHoleX = keyHoleX;
	}
	public int getKeyHoleY() {
		return keyHoleY;
	}
	public void setKeyHoleY(int keyHoleY) {
		this.keyHoleY = keyHoleY;
	}

	/**
	 * @return the bckgrd
	 */
	public BufferedImage getBckgrd() {
		return bckgrd;
	}

	/** Assigns the procvided image to the background field (bckgrd)
	 * @param bckgrd the bckgrd to set
	 */
	public void setBckgrd(BufferedImage bckgrd) {
		this.bckgrd = bckgrd;
	}
	
	

}
