package chest;

import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import pong.Updatable;

/**  Creates the key that is used within the minigame
 * 
 * @author Shivani Chhaya
 *@author Britney Yang
 */
public class Key extends JPanel implements Updatable
{
	/** x coordinate of the cursor*/
	private int mouseX;
	/** y coordinate of the cursor*/
	private int mouseY;
	/** direction and velocity horizontally*/
	private int dx;
	/** direction and velocity vertically*/
	private int dy;
	/** x coordinate of the key*/
	private int keyX;
	/** y coordinate of the key*/
	private int keyY;
	/** image of the key*/
	private BufferedImage keyImagePic;
//	private ImageIcon image = new ImageIcon();
//	private JButton keyImage;
	
	/** Assigns the image to the buffered image field 
	 * 
	 */
	 public Key()
	  {
			try
			{
				setKeyImagePic((ImageIO.read(getClass().getResourceAsStream("/pngs/key.png"))));
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
				  
	  }

	 /** creates the values for the dX, dY and the key location
	  * 
	  */
	public void setValues()
	{
		dx = 0;
		dy = 0;
		keyX = 300;
		keyY = 300;
	}
	
//	public void draw(Graphics g)
//	{
//		g.drawImage(keyImage, keyX, keyY, keyImage.getWidth(this),keyImage.getHeight(this),this);
//		
//		this.repaint();
//		this.revalidate();
//	}

	
	
//	public void paintComponent (Graphics g)
//    {
//	     super.paintComponent(g);
//     
//	     g.drawImage(keyImage, mouseX, mouseY, keyImage.getWidth(this),keyImage.getHeight(this),this);
//	     
//		this.revalidate();
//	     this.repaint();
//    }
	
	
	/**
	 * @return the mouseX
	 */
	public int getMouseX() {
		return mouseX;
	}

	/**
	 * @param mouseX the mouseX to set
	 */
	public void setMouseX(int mouseX) {
		this.mouseX = mouseX;
	}

	/**
	 * @return the mouseY
	 */
	public int getMouseY() {
		return mouseY;
	}

	/**
	 * @param mouseY the mouseY to set
	 */
	public void setMouseY(int mouseY) {
		this.mouseY = mouseY;
	}




//	/**
//	 * @return the keyImage
//	 */
//	public JButton getKeyImage() {
//		return keyImage;
//	}
//
//
//
//
//	/**
//	 * @param keyImage the keyImage to set
//	 */
//	public void setKeyImage(JButton keyImage) {
//		this.keyImage = keyImage;
//	}




	@Override
	public void update() 
	{
		
	}




	/**
	 * @return the dx
	 */
	public int getDx() {
		return dx;
	}




	/**
	 * @param dx the dx to set
	 */
	public void setDx(int dx) {
		this.dx = dx;
	}




	/**
	 * @return the dy
	 */
	public int getDy() {
		return dy;
	}




	/**
	 * @param dy the dy to set
	 */
	public void setDy(int dy) {
		this.dy = dy;
	}

	/**
	 * @return the keyX
	 */
	public int getKeyX() {
		return keyX;
	}

	/**
	 * @param keyX the keyX to set
	 */
	public void setKeyX(int keyX) {
		this.keyX = keyX;
	}

	/**
	 * @return the keyY
	 */
	public int getKeyY() {
		return keyY;
	}

	/**
	 * @param keyY the keyY to set
	 */
	public void setKeyY(int keyY) {
		this.keyY = keyY;
	}

	/**
	 * @return the keyImagePic
	 */
	public BufferedImage getKeyImagePic() {
		return keyImagePic;
	}

	/**Sets the buffered image equal to the provided image
	 * @param keyImagePic the keyImagePic to set
	 */
	public void setKeyImagePic(BufferedImage keyImagePic) {
		this.keyImagePic = keyImagePic;
	}
	
	
}
