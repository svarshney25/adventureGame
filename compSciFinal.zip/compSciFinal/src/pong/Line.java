package pong;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import javax.swing.JComponent;

/** creates the dotted line seen in the background of the pong game
 * 
 * @author Shivani Chhaya 
 * @author Britney Yang ( comments )
 *
 */
public class Line extends JComponent
{
	/** a section of the dotted line*/
	private Rectangle one;
	/** a section of the dotted line*/
	private Rectangle two;
	/** a section of the dotted line*/
	private Rectangle three;
	/** a section of the dotted line*/
	private Rectangle four;
	/** a section of the dotted line*/
	private Rectangle five;
	/** a section of the dotted line*/
	private Rectangle six;
	/** a section of the dotted line*/
	private Rectangle seven;
	/** a section of the dotted line*/
	private Rectangle eight;
	/** a section of the dotted line*/
	private Rectangle nine;
	/** a section of the dotted line*/
	private Rectangle ten;
	
	/** color of the dotted line*/
	private Color color;
	
	/** creation of the size and locations of the dotted line in order for it to 
	 * be in a straight line as well as assigning its color*/
	  
	public Line()
	{
		color = Color.white;
		this.setBounds(450,0,5,50);
		this.one = new Rectangle (450, 0, 5, 50);
		this.two = new Rectangle (450, 70, 5, 50);
		this.three = new Rectangle (450, 140, 5, 50);
		this.four = new Rectangle (450, 210, 5, 50);
		this.five = new Rectangle (450, 280, 5, 50);
		this.six = new Rectangle (450, 355, 5, 50);
		this.seven = new Rectangle (450, 420, 5, 50);
		this.eight = new Rectangle (450, 490, 5, 50);
		this.nine = new Rectangle (450, 560, 5, 50);
		this.ten = new Rectangle (450, 630, 5, 50);	
		

	}

	public void setColor( Color color )
	{
		this.color = color;
	}
	
	/** Allows the line to be visible in the JFrame
	 * 
	 */
	public void paintComponent(Graphics g)
	{
		Graphics2D g2 = (Graphics2D) g;
		
		g2.setColor(color);
		
		g2.fill(one);
		g2.fill(two);
		g2.fill(three);
		g2.fill(four);
		g2.fill(five);
		g2.fill(six);
		g2.fill(seven);
		g2.fill(eight);
		g2.fill(nine);
		g2.fill(ten);
	}

}
