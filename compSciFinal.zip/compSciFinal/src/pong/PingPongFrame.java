package pong;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;

import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.BasicStroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/** Puts together all the other classes and creates where the main game is happening
 * 
 * @author Shivani Chhaya
 *@author Britney Yang ( Comments )
 *
 */
public class PingPongFrame extends JFrame implements ActionListener
{
	/** ball used in the game*/
	private Ball ball;
	/** left paddle*/
	private Character red;
	/** right paddle*/
	private Character blue;
	/** timer for game progression and refreshing frame*/
	private Timer timer;
	/** velocity of the ball to switch between*/
	private int[] ballVelocities = {-6,6};
	/** points belonging to the left paddle*/
	private int bPoints = 0;
	/** points belonging to the right paddle */
	private int rPoints = 0;
//	private Line lines = new Line();
	/** String that stores which side is the winner*/
	private String winner = "";
	/** Label showing the number of points of the left side*/
	private JLabel bScore = new JLabel(Integer.toString(bPoints));
	/** Label showing the number of points of the right side */
	private JLabel rScore = new JLabel(Integer.toString(rPoints));
	/** Lebl that shows the winner side*/
	private JLabel wins = new JLabel(winner);
	/** Label telling player how to start*/
	private JLabel start = new JLabel("<< click SPACE to start the ball! >>");
	/** Label telling player how to reset*/
	private JLabel reset = new JLabel("<< click ENTER to reset the score! >>");
	
	/** Label indicating the end of the game*/
	private JLabel gameFinished = new JLabel("You beat the bear!");
	/** Label to finish the game*/
	private JButton choice = new JButton("Yay!");
	/** Button to play again*/
	private JButton playAgain = new JButton("I'll play again.");
	
	/** Background color*/
	private Color background = new Color(51, 76, 46);
	/** paddle color*/
	private Color cPaddle = new Color(153, 105, 0);
	/** cotted line color */
	private Color lines = new Color(32, 61, 28);

	/** true if playAgain is clicked an dfalse otherwise*/
	private boolean playAgainClicked = false;
	/** true if the game has been won and false otherwise*/
	private boolean gameWon = false;
	
	
//	private ShopFunctions shopF;
	
	/** Puts together the game into a frame with the movement of the paddle assigned to 
	 * WS and UP+DOWN and the general UI like text of scores added in. Also manages when 
	 * the player clicks the reset button and start button, setting the assets to the 
	 * proper values
	 * 
	 */
	public PingPongFrame()
	{
		this.setBounds(250,30,600,600);
		this.setLocationRelativeTo(null);
		this.getContentPane().setBackground(background);
		this.setLayout(null);
		this.setTitle("ping pong");
		this.setResizable(false);
		
//		shopF = shopFunctions;
		
		bScore.setBounds(125,50,100,100);
		bScore.setFont(new Font("Monospaced Plain", Font.PLAIN, 60));
		bScore.setForeground(Color.white);
		this.add(bScore);
		
		rScore.setBounds(425,50,100,100);
		rScore.setFont(new Font("Monospaced Plain", Font.PLAIN, 60));
		rScore.setForeground(Color.white);
		this.add(rScore);
		
		wins.setBounds(320, 230, 350,200);
		wins.setFont(new Font("Monospaced Plain", Font.PLAIN, 60));
		this.add(wins);
		wins.setVisible(false);
		

		gameFinished.setBounds(50, 450, 200, 100);
		gameFinished.setFont(new Font("Monospaced Plain", Font.PLAIN, 25));
		gameFinished.setForeground(Color.BLACK);
//		gameFinished.setVisible(false);
//		this.add(gameFinished);
		
		choice.setBounds(400,475, 100,50);
		choice.setFont(new Font("Monospaced Plain", Font.PLAIN, 25));
		choice.setBackground(lines);
		choice.setContentAreaFilled(false);
		choice.setForeground(Color.BLACK);
//		choice.setBorderPainted(true);
		
		playAgain.setBounds(325, 425, 200, 50);
		playAgain.setFont(new Font("Monospaced Plain", Font.PLAIN, 16));
		playAgain.setBackground(lines);
		playAgain.setContentAreaFilled(false);
		playAgain.setForeground(Color.BLACK);

		blue = new Character(8,225, Color.white);
		red = new Character(550,225, cPaddle);
		
		this.add(blue);
		this.add(red);
		
		timer = new Timer(10, this);
		timer.start();
		
		ball = new Ball(286,225+blue.getHeight()/2);
		this.add(ball);
		
//		lines = new Line();
//		this.add(lines);
		
		this.addKeyListener(new KeyListener() 
		{

			@Override
			public void keyTyped(KeyEvent e) 
			{
				
			}
			
			/** The movement of the left and right paddles as well as the reseting and starting of 
			 * the games based on the buttons pressed
			 * 
			 */
			@Override
			public void keyPressed(KeyEvent e) 
			{
				//check if paddles go out of frame
				if(blue.getY() + blue.getDy() <0)
				{
					blue.setLocation(blue.getX(),0);
				}
				if(blue.getY()+ blue.getHeight()+blue.getDy() > 665)
				{
					blue.setLocation(blue.getX(), 665-blue.getHeight());
				}
				if(red.getY()+red.getDy()<0)
				{
					red.setLocation(red.getX(),1);
				}
				if(red.getY() + red.getHeight() + red.getDy()> 665)
				{
					red.setLocation(red.getX(), 665-red.getHeight());
				}
				
				//get key codes				
					int code = e.getKeyCode();
					
					switch(code)
					{
					case KeyEvent.VK_SPACE:
						gameFinished.setVisible(false);
						bScore.setForeground(Color.white);
						rScore.setForeground(Color.white);
						start.setVisible(false);
						reset.setVisible(false);
						wins.setVisible(false);
						if(ball.getDx() == 0)
						{
							ball.setColor(Color.white);
							ball.setLocation(286,225+blue.getHeight()/2);
							ball.setDx(ballVelocities[(int)(Math.random()*2)]);
							ball.setDy(ballVelocities[(int)(Math.random()*2)]);
						}
						break;
					case KeyEvent.VK_W:
						blue.setDy(-15);
						break;
					case KeyEvent.VK_S:
						blue.setDy(+15);
						break;
					case KeyEvent.VK_UP:
						red.setDy(-15);
						break;
					case KeyEvent.VK_DOWN:
						red.setDy(+15);
						break;		
						
					}	
				
			}

			/** The pausing of the characters when the player is no longer pressing the key
			 * 
			 */
			@Override
			public void keyReleased(KeyEvent e) 
			{
				int code = e.getKeyCode();
				
				switch(code)
				{
				case KeyEvent.VK_W:
					blue.setDy(0);
					break;
				case KeyEvent.VK_S:
					blue.setDy(0);
					break;
				case KeyEvent.VK_UP:
					red.setDy(0);
					break;
				case KeyEvent.VK_DOWN:
					red.setDy(0);
					break;
				}	
		
			}
		});
		
		this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}
		
	
	/** Checks for things like collisons with the paddle, collisions with the side of screens 
	 * behind the paddle and to the sides, and whether or not the player has won
	 * 
	 */
	@Override
	public void actionPerformed(ActionEvent e)
	{
		Insets insets = this.getInsets();
		
		blue.update();
		red.update();
		ball.update();
		
		if(bPoints == 3 || rPoints == 3)
		{
			gameFinished.setVisible(true);
			if (bPoints == 3)
			{
//				shopF.setCoins(10);
//				System.out.println(shopF.getCoins());
//				bPoints = 0;
//				winner = "Blue wins!";
//				wins.setText(winner);
//				wins.setForeground(Color.white);
//				wins.setVisible(true);
				bPoints = 0;
				gameWon = true;
				this.add(gameFinished);
				this.add(choice);
			
				choice.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					playAgainClicked = false;

					dispose();
					reset();
					gameFinished.setBounds(50,400, 400, 200);
					gameFinished.setText("You already beat me!");
					choice.setBounds(385,475, 150,50);
					choice.setText("Fine...");
				}
				});	
			}
			
			else if(rPoints == 3)
			{

				
				gameFinished.setText("I beat you! HAHA!");
				choice.setBounds(325,500,200,50);
				choice.setText("I'm leaving.");
				choice.setFont(new Font("Monospaced Plain", Font.PLAIN, 16));
				
				gameWon = false;
				this.add(choice);
				this.add(gameFinished);
				this.add(playAgain);
				
				playAgain.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						playAgainClicked = true;
						reset();
						gameFinished.setVisible(false);
						playAgain.setVisible(false);
						choice.setVisible(false);
						
					}
					});	
				
				choice.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						playAgainClicked = false;

						dispose();
						reset();
						
						playAgain.setVisible(false);
						choice.setVisible(false);
						gameFinished.setBounds(50, 450, 250, 100);
						gameFinished.setText("Back again? Try me.");					
						
					}
					});	
			}
			//reset
//			start.setVisible(true);
//			reset.setVisible(true);
//			gameWon = true;
			
			
		}
		//check paddle collisions with frame
		if(blue.getY() + blue.getDy() <0)
		{
			blue.setLocation(blue.getX(),0);
		}
		if(blue.getY()+ blue.getHeight()+blue.getDy() > 560)
		{
			blue.setLocation(blue.getX(), 560-blue.getHeight());
		}
		if(red.getY()+red.getDy()<0)
		{
			red.setLocation(red.getX(),1);
		}
		if(red.getY() + red.getHeight() + red.getDy()> 560)
		{
			red.setLocation(red.getX(), 560-red.getHeight());
		}
		
		
		//check ball collisions with blue
		if(ball.getBounds().intersects(blue.getBounds()))
		{				
				if(blue.getDy()==0 && ball.getDx() < 0 && ball.getX() < blue.getX()+blue.getWidth() && (ball.getY()+ball.getHeight()/2 >= blue.getY() + blue.getHeight()/4 && ball.getY()+ball.getHeight()/2 <= blue.getY() + blue.getHeight() - blue.getHeight()/4))
				{
					ball.setDx(ball.getDx()*-1 );
					ball.setDy(0);
				}
				else if(ball.getDy() == 0 && ball.getDx() < 0 && (ball.getY() + ball.getHeight() > blue.getY() || ball.getY() < blue.getY() + blue.getHeight() || ball.getX() < blue.getX() + blue.getWidth()))
				{
					ball.setDx(ball.getDx()*-1);
					if(ball.getY() + ball.getHeight() > blue.getY() && blue.getDy() < 0)
					{
						ball.setDy(-6);												// if ball is moving horizontally then paddle movement will shift the dy
					}
					else if(ball.getY() < blue.getY() + blue.getHeight() && blue.getDy() > 0)
					{
						ball.setDy(+6);
					}
				}
				else if(ball.getDy() > 0 && ball.getDx() < 0 && ball.getY()+ball.getHeight()>blue.getY()) //on top of blue paddle, moving left, hits from top
				{
					//ball.setLocation(ball.getX(), ball.getY()-1);
					ball.setDx(ball.getDx()*-1);
//					if(blue.getDy()==0)
//					{
//						ball.setDy(ball.getDy()*-1);
//					}
					if(blue.getDy() > 0)
					{
						ball.setDy(ball.getDy());
					}
					else
					{
						ball.setDy(ball.getDy()*-1);
					}
					
				}
				else if(ball.getDy() < 0 && ball.getDx() < 0 && ball.getY() < blue.getY()+blue.getHeight()) //on bottom of blue paddle, moving left, hits from bottom
				{
					//ball.setLocation(ball.getX(), blue.getY()+blue.getHeight()+1);
					ball.setDx(ball.getDx()*-1);
					
//					if (blue.getDy() == 0)
//					{
//						ball.setDy(ball.getDy()*-1);
//					}
					if(blue.getDy() < 0)
					{
						ball.setDy(ball.getDy());
					}
					else 
					{
						ball.setDy(ball.getDy()*-1);
					}
					
				}
				else if(blue.getDy()==0 && ball.getDx()<0 && ball.getX() < blue.getX()+blue.getWidth())
				{
					ball.setDx(ball.getDx()*-1);
					ball.setDy(0);
				}
				else if(ball.getDx()<0 && ball.getX() < blue.getX()+blue.getWidth())  //moving left and hits from right
				{
						ball.setDx(ball.getDx()*-1);
						if(blue.getDy()==0)
						{
							ball.setDy(0);
						}
						else if(blue.getDy()>0 && ball.getDy() < 0)
						{
							ball.setDy(ball.getDy()*-1);
						}
						else if(blue.getDy() < 0 && ball.getDy() > 0)
						{
							ball.setDy(ball.getDy());
						}
					
				}
				

				ball.setColor(Color.white);
		}
	
		//check ball collisions with red
		if(ball.getBounds().intersects(red.getBounds()))
		{			
			if(red.getDy()==0 && ball.getDx() > 0 && ball.getX()+ball.getWidth() > red.getX() && (ball.getY()+ball.getHeight()/2 >= red.getY() + red.getHeight()/4 && ball.getY()+ball.getHeight()/2 <= red.getY() + red.getHeight() - red.getHeight()/4))
			{
				ball.setDx(ball.getDx()*-1);
				ball.setDy(0);
			}
			else if(ball.getDy() == 0 && ball.getDx() > 0&& (ball.getY() + ball.getHeight() > red.getY() || ball.getY() < red.getY() + red.getHeight() || ball.getX()+ball.getHeight() > red.getX()))
			{
				ball.setDx(ball.getDx()*-1);
				
				if(ball.getY() + ball.getHeight() > red.getY() && red.getDy() < 0)
				{
					ball.setDy(-6);
				}
				else if(ball.getY() < red.getY() + red.getHeight() && red.getDy() > 0)
				{
					ball.setDy(+6);
				}
			}
			else if(ball.getDy() > 0 && ball.getDx() > 0 && ball.getY()+ball.getHeight()>red.getY()) //on top of red paddle, moving right, hits from top
				{
					//ball.setLocation(ball.getX(), ball.getY()-1);
					ball.setDx(ball.getDx()*-1);
					if(red.getDy() > 0)
					{
						ball.setDy(ball.getDy());
					}
					else
					{
						ball.setDy(ball.getDy()*-1);
					}
				}
				else if(ball.getDy() < 0 && ball.getDx() > 0 && ball.getY() < red.getY()+red.getHeight()) //on bottom of red paddle, moving right, hits from bottom
				{
					//ball.setLocation(ball.getX(), red.getY()+red.getHeight()+1);
					ball.setDx(ball.getDx()*-1);
//					if(red.getDy()==0)
//					{
//						ball.setDy(ball.getDy()*-1);
//					}
					if(red.getDy() < 0)
					{
						ball.setDy(ball.getDy());
					}
					else
					{
						ball.setDy(ball.getDy()*-1);
					}
				}
				else if(ball.getDx()>0 && ball.getX()+ball.getWidth()>red.getX())  //moving right and hits from left
				{
						ball.setDx(ball.getDx()*-1);
					
						if(red.getDx()==0)
						{
							ball.setDy(0);
						}
						else if(red.getDy()>0 && ball.getDy() < 0)
						{
							ball.setDy(ball.getDy()*-1);
						}
						else if(red.getDy() < 0 && ball.getDy() > 0)
						{
							ball.setDy(ball.getDy());
						}
					
				}

				ball.setColor(cPaddle);		
		}
		
		//check ball collisions with frame
		if(ball.getX() < 0)
		{
			rPoints++;
			rScore.setText(Integer.toString(rPoints));
			rScore.setForeground(cPaddle);
			ball.setColor(Color.white);
			ball.setLocation(286,225+blue.getHeight()/2);
			ball.setDx(0);
			ball.setDy(0);
		}
		else if(ball.getX() + ball.getWidth() > (this.getWidth() - insets.left - insets.right))
		{
			bPoints++;
			bScore.setText(Integer.toString(bPoints));
			bScore.setForeground(Color.white);
			ball.setColor(Color.white);
			ball.setLocation(286,225+blue.getHeight()/2);
			ball.setDx(0);
			ball.setDy(0);
		}
		if(ball.getY() < 0)
		{
			ball.setDy(ball.getDy()*-1);
		}
		if(ball.getY() + ball.getHeight() > (this.getHeight() - insets.top - insets.bottom))
		{
			ball.setDy(ball.getDy()*-1);
		}
		
	}
	
	public void reset()
	{
		blue.setLocation(8,225);
		red.setLocation(550,225);
		bPoints= 0;
		rPoints = 0;
		bScore.setText(Integer.toString(bPoints));
		rScore.setText(Integer.toString(rPoints));
		ball.setColor(Color.white);
		ball.setLocation(286,225+blue.getHeight()/2);
		ball.setDx(0);
		ball.setDy(0);
	}
		
	public void paint(Graphics g)
	{
		
		super.paint(g);
		Graphics2D g2 = (Graphics2D) g;
		Graphics2D g3 = (Graphics2D) g;
		
		Ellipse2D.Double circle = new Ellipse2D.Double(150,150,300,300);
		
		this.revalidate();
		this.repaint();
		
		
		
	}
	
	
		
	
/** adds the pong game to the main so it can be run
 * 
 */
public static void main(String[] args)
	{
		new PingPongFrame();

	}



/**
 * @return the gameWon
 */
public boolean isGameWon() {
	return gameWon;
}



/**
 * @param gameWon the gameWon to set
 */
public void setGameWon(boolean gameWon) {
	this.gameWon = gameWon;
}


/**
 * @return the playAgainClicked
 */
public boolean isPlayAgainClicked() {
	return playAgainClicked;
}



/**
 * @param playAgainClicked the playAgainClicked to set
 */
public void setPlayAgainClicked(boolean playAgainClicked) {
	this.playAgainClicked = playAgainClicked;
}

}


