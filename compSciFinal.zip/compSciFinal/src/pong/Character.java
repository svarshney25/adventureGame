package pong;

import java.awt.Rectangle;
import java.awt.Color;
import javax.swing.JComponent;
import javax.swing.JLabel;

import java.awt.Graphics;
import java.awt.Graphics2D;

/** Creates the paddles seen in the game on opposite sides
 * 
 * @author Shivani Chhaya 
 * @author Britney Yang ( comments )
 * 
 */
public class Character extends JComponent implements Updatable
{
	/** the shape of the paddle */
	private Rectangle rect;
	/** direction and velocity the paddle moves in horizontally*/
	private int dx;
	/** direction and velocity the paddle moves in vertically*/
	private int dy;
	/** color of the paddle*/
	private Color color;
	
	
	/** assigns the paddle both of its velocities, its size, color and location/bounds on the JFrame
	 * 
	 * @param x		x value of its location
	 * @param y		y value of its locaiton
	 * @param color	color of the paddle
	 */
	public Character(int x, int y, Color color)
	{
		this.dx = 0;
		this.setDy(0);
	
		rect = new Rectangle(0,0,25,100);
		this.color = color;
		
		this.setBounds(x,y,26,101);
		
	}
	
	/** allows for the paddle to be visible in the JFrame
	 * 
	 */
	@Override
	public void paintComponent(Graphics g)
	{
		Graphics2D g2 = (Graphics2D) g;
		
		g2.setColor(color);
		g2.fill(rect);
		
	}
	
	
	
	
	public int getDx() {
		return dx;
	}
	public void setDx(int dx) {
		this.dx = dx;
	}
	
	public int getDy() {
		return dy;
	}
	
	public void setDy(int dy) {
		this.dy = dy;
	}
	
	public Color getColor() {
		return color;
	}


	/**updates the location of the paddle based on the dX and the dY 
	 * 
	 */
	@Override
	public void update()
	{
		setLocation(getX() + dx, getY() + dy);
	}

	
	
}