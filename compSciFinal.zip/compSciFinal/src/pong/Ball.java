package pong;

import javax.swing.JComponent;
import java.awt.geom.Ellipse2D;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;

/** Creates the ball used in the game
 * 
 * @author Shivani Chhaya
 * @author Britney Yang ( comments )
 */
public class Ball extends JComponent
{
	/** Creates an ellipse to represent the ball*/
	private Ellipse2D.Double ball;
	/** color of the ball */
	private Color color;
	/** direction and velocity of the ball horizontally*/
	private int dx;
	/** direction and velocity of the ball vertically*/
	private int dy;
	
	/** Assigns a dX and dY to the ball as well as it's color and position at the 
	 * center of the JFrame
	 * 
	 */
	public Ball(int x, int y)
	{
		dx = 0;
		dy = 0;
		
		color = Color.white;
		ball = new Ellipse2D.Double(0,0,15,15); //position at 0,0  puts it at center of component
		
		this.setBounds(x,y,16,16);
		
		this.setFocusable(false);
	}
	
	public void setDx(int dx)
	{
		this.dx = dx;
	}
	
	public void setDy(int dy)
	{
		this.dy = dy;
	}
	
	public int getDx()
	{
		return dx;
	}
	
	public int getDy()
	{
		return dy;
	}
	
	/** Updates the location of the ball from it's prior position by moving in the direction 
	 * and at the velocity of the provided dX and dY
	 * 
	 */
	public void update()
	{
		setLocation(this.getX() + dx, this.getY() + dy);
	}
	
	public void setColor(Color c)
	{
		this.color = c;
	}
	
	/** allows the ball to be visible on the JFrame
	 * 
	 */
	public void paintComponent(Graphics g)
	{
		Graphics2D g2 = (Graphics2D) g;
		
		g2.setColor(color);
		g2.fill(ball);
	}
}