package beachImageFinder;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import adventureGame.ImagePanel;
import imageFinder.ImageFinder;

/**
 * This class generates a minigame that allows the player to find a hidden button in an image
 * @author Shivika Varshney
 */

public class BeachImageFinder extends JFrame implements ActionListener {
	/**creates the hidden button*/
	private JButton hiddenButton;
	/**creates the welcome text*/
	private JLabel text;
	/**boolean to determine whether the game has been won*/
	private boolean gameWon;
	
	/**creates a new game, setting up the image 
	 * and the location of the button and text*/
	
	public BeachImageFinder() {
		this.setBounds(250,30,700,500);
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		this.setTitle("image finder");
		this.setResizable(false);
		
		gameWon = false;
		
		text = new JLabel("Find the hidden button and click it to earn coins!");
		
		text.setBounds(20,10,700,100);
		text.setFont(new Font("SansSerif Bold", Font.PLAIN, 20));
		text.setForeground(Color.BLACK);
		text.setVisible(true);
		this.add(text);
		
		hiddenButton = new JButton(".");
		hiddenButton.setBounds(500,405,5,5);
		hiddenButton.setOpaque(true);
		hiddenButton.setForeground(Color.RED);
		hiddenButton.setFont(new Font("SansSerif Bold", Font.PLAIN, 50));
		hiddenButton.setBackground(Color.RED);
		this.add(hiddenButton);
		
		/**The action listener checks to see if the
		 * button has been clicked and if it has, the game has been won.
		 * the frame will be disposed once done*/
		hiddenButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				gameWon = true;
				dispose();
			}
			
		});
		
		ImagePanel background = new ImagePanel(new ImageIcon("src/pngs/beachBg.png").getImage());
		this.add(background);
		
		
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	public static void main(String[] args) {
		new BeachImageFinder();
	}
	
	/** @return whether the game has been won or not*/
	public boolean isGameWon() {
		return gameWon;
	}
	public void setGameWon(boolean won) {
		gameWon = won;
	}
}
