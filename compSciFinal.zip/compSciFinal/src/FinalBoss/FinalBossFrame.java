package FinalBoss;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import TundraBoss.TundraBossFrame;

/**
 * creates the frame for the final boss
 * @author Shivani Chhaya
 * @author Shivika Varshney
 *
 */
public class FinalBossFrame extends JFrame {
	/**variable to store final boss image*/
	private BufferedImage image;
	/**holds an icon image used as a background*/
	private JLabel background;
	
	/**creates the final boss frame*/
	public FinalBossFrame() {
		this.setBounds(10,50,700,500);
		this.setLocationRelativeTo(null);
		background = new JLabel();
		
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/pngs/finalBoss.png"));

		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		background.setIcon(new ImageIcon(image));
		this.add(background);
		
		this.setVisible(true);

	}
	
	public static void main(String[] args) {
		new FinalBossFrame();
	}
}
