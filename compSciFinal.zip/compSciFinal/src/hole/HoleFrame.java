package hole;

import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import pong.Updatable;

/**
 * This class generates a minigame that allows the player to get out of the hole when it 
 * collides with it during their path
 * @author Shivani Chhaya
 * @author Shivika Varshney
 */

public class HoleFrame extends JFrame implements ActionListener, Updatable
{
	/**creates a label that displays the instructions*/
	private JLabel info = new JLabel("Click all of the hidden squares to get out of the hole!");
	/**sets up a blue square*/
	private Color blue = new Color(144, 202, 249);
	/**sets up a purple square*/
	private Color purple = new Color(186, 104, 200);
	/**sets up a red square*/
	private Color red = new Color(244, 67, 54);
	/**sets up a pink square*/
	private Color pink = new Color(240, 98, 146);
	/**creates an array of all the colors*/
	private Color[] colorList = {blue, purple, red, pink};
	/**creates a counter for the number of squares left to click*/
	private int counter = 0;
	/**boolean to determine if the game has been beat*/
	private boolean gameBeat = false;
	/**displays the number of squares left to click*/
	private JLabel counterText = new JLabel();

	/**creates a new game that sets up a 4 x 4 grid on the frame with squares.
	 * the hidden tiles are randomly filled with a color and the counter is 
	 * incremented for every hidden blue square.
	 */
	public HoleFrame()
	{
		//click all of the blue icons to get out
		this.setBounds(250,30,600,600);
		this.setLocationRelativeTo(null);
		this.setLayout(null);
		this.setTitle("hole game");
		this.setResizable(false);
			
		gameBeat = false;
		
		int x = 150;
		int y = 150;
		
		for(int i = 0; i < 4; i++, x = 150, y +=75)
		{
			for(int j = 0; j < 4; j++, x+=75)
			{
				JButton square = new JButton();
				square.setBackground(colorList[(int)(Math.random()*4)]);
				square.setContentAreaFilled(true);
				square.setBounds(x,y,50,50);
				if(square.getBackground() == blue)
				{
					counter++;
				}
				
				this.add(square);
				
				square.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						
						if(square.getBackground() == blue)
						{
							counter--;
							square.setVisible(false);
							update();
						}
						else
						{
							square.setBackground(Color.black);
						}
					}
					});
				
			}
		}
		
		info.setBounds(75, 25, 500, 100);
		info.setFont(new Font("Sans Serif Bold", Font.PLAIN, 17));
		this.add(info);
		
		counterText.setText("You have " + Integer.toString(counter) + " more squares to click!");
		counterText.setBounds(175,400,250,100);
		counterText.setFont(new Font("SansSerif Bold", Font.PLAIN, 15));
		counterText.setVisible(true);
		this.add(counterText);
	
		
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setVisible(true);
		
	}
	
			
	
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		update();

	}

	/**
	 * @return the counter
	 */
	public int getCounter() {
		return counter;
	}

	/**
	 * @param counter the counter to set
	 */
	public void setCounter(int counter) {
		this.counter = counter;
	}

	
	/**updates the text at the bottom consistently to match the number
	 * of squares left to click
	 */
	@Override
	public void update() 
	{
		counterText.setText("You have " + counter + " more squares to click!");
		if(counter == 0)
		{			
			gameBeat = true;
			dispose();
		}
	}	
	
	public static void main(String[] args)
	{
		new HoleFrame();
	}


	/**
	 * @return the gameBeat
	 */
	public boolean isGameBeat() {
		return gameBeat;
	}


	/**
	 * @param gameBeat the gameBeat to set
	 */
	public void setGameBeat(boolean gameBeat) {
		this.gameBeat = gameBeat;
	}
}
